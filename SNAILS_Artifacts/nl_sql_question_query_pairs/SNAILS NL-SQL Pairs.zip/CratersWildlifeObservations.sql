-- 1: Show the notes for gray wolf observations with Bureau of Land Management (BLM) ownership
select notes 
from VERTEBRATES
where Ownership = 'BLM' and Common_Name like 'gray wolf'
;

-- 2: How many vertebrates were observed by either Stefanic or Dennis Hauser?
select count(*) obsCount
from VERTEBRATES
where observer like 'Stefanic' or observer like 'Dennis Hauser'
;

-- 3: For each breeding code, show the breeding code definition and count of vertebrate observations for observations of the species with the Common_Name 'mule deer'.
select definition, count(*) deerCount
from breeding_codes bc
join VERTEBRATES v on bc.Breed = v.BREED
where Common_Name = 'mule deer'
group by definition
;

-- 4: Show the Common_Name and genus species for all invertebrates of class Arachnida
select Common_Name, Genus_species 
from INVERTEBRATES
where class like 'arachnida'
;

-- 5: Show all of the family values in the invertebrates table that are not in the invertebrates family table. Exclude null values and include only one entry per type.
select distinct family 
from INVERTEBRATES i
where not exists (
	select Invert_Family 
	from Invert_Family
	where Invert_Family = i.Family
) and family IS NOT NULL
;

-- 6: Which species were documented as road kill at highway mile marker 235? Include only one entry per species type.
select distinct Species 
from Roadkill
where HWY_Mile_Marker = '235'
;

-- 7: How many roadkill observations were made for each month in 2014?
select Month, count(*) roadkillCount
from Roadkill
where year = 2014
group by Month
;

-- 8: Show the comments for roadkill entries made before 1990
select comments 
from roadkill
where year < 1990
;

-- 9: How many mule deer were counted as road kill in 2015?
select count(*) deerCount
from roadkill
where species like 'mule deer' and year = 2015
;

-- 10: How many roadkill records have a date that is identical to at least on vertebrate record?
select count(*) recordCount
from Roadkill r
where exists(
	select * 
	from vertebrates
	where r.Date = Date
)
;

-- 11: What is the species, year and month of the roadkill observation with the highest number killed documented?
select top 1 species, year, month 
from Roadkill
order by number_killed desc
;

-- 12: For each habitat definition, show the count of vertebrates and the count of invertebrates records
select definition, vertHabCount, invertHabCount
from HABITAT_CODES h
join (
	select Habitat, count(*) vertHabCount
	from VERTEBRATES
	group by habitat
) v on v.Habitat = h.Code
join (
	select Habitat, count(*) invertHabCount
	from INVERTEBRATES
	group by habitat
) i on i.Habitat = h.Code
;

-- 13: Show the definition of habitats that have more than 40 invertebrate records.
select definition
from HABITAT_CODES
where code in (
	select Habitat
	from INVERTEBRATES
	group by habitat
	having count(*) > 40
)
;

-- 14: Which invertebrate records were recorded on the same day, at the same habitat, as at least one vertebrate record? Include the date, observer, and species Common_Name from the invertebrate entry.
select date, observer, Common_Name 
from INVERTEBRATES i
where exists (
	select * 
	from VERTEBRATES
	where i.date = date and i.Habitat = Habitat
)
;

-- 15: For vertebrate and invertebrate observations recorded at the same habitat on the same day, show the observer recorded on the invertebrate record as well as the observer recorded on the vertebrate record. Also include the date, and the habitat definition.
select i.Observer, v.Observer, i.date, Definition
from HABITAT_CODES h
join INVERTEBRATES i on i.Habitat = h.Code
join VERTEBRATES v on v.date = i.date and v.Habitat = i.Habitat
;

-- 16: Display the observation type and a count of invertebrate records for each observation type
select OBS_TYPE, count(*) obsCount
from INVERTEBRATES
group by OBS_TYPE
;

-- 17: Show all the different locations where the Invertebrate species Trichodes ornatus has been observed
select location 
from INVERTEBRATES
where Genus_species like 'Trichodes ornatus'
;

-- 18: Which observers have either only observed Invertebrates, or only observed Vertebrates, but not both?
select distinct observer
from INVERTEBRATES
except
select distinct observer
from VERTEBRATES
;

-- 19: What are the Universal Transverse Mercator north and east coordinates for the records documenting the invertebrate with the Common_Name 'western white'?
select UTMN, UTME 
from INVERTEBRATES
where Common_Name like 'western white'
;

-- 20: What are the common and scientific names of vertebrates observed at the coordinates Universal Transverse Mercator North = 4814897 and Universal Transverse Mercator East = 291766
select Common_Name, Scientific_Name
from VERTEBRATES
where UTMN = 4814897 and UTME = 291766
;

-- 21: Which roadkill species are not included in the Common_Name field of the invertebrates table? Include only one entry per value.
select distinct species
from Roadkill
where species not in (
	select Common_Name
	from VERTEBRATES
)
;

-- 22: What is the highest number of invertebrates  recorded in an observation for each family? Do not include NULL values in the number column.
select family, max(number) maxNum
from INVERTEBRATES 
where number IS NOT NULL
group by family
;

-- 23: How many paste are there where the species is 'deer'?
select count(*) errorCount
from Paste_Errors
where Species like 'deer'
;

-- 24: Show the orders for invertebrates in the Insecta class. Only include one row per value.
select distinct [order]
from INVERTEBRATES
where class like 'Insecta'
;

-- 25: Get a count of invertebrate observations made at the Hot springs location for each observation type
select OBS_TYPE, count(*) obsCount
from INVERTEBRATES
where location like 'Hot springs'
group by OBS_TYPE
;

-- 26: For each survey category of vertebrate records, show a count of observations made by the observer stefanic
select survey, count(*) stefCount
from VERTEBRATES
where observer like 'stefanic'
group by survey
;

-- 27: What is the scientific name of the mammal commonly known as the moose? Only include one row in the response
select Scientific_Name
from WILDLIFE_MASTERLIST
where Common_Name like 'moose'
;

-- 28: Get a count of big game roadkill for each location. The value for big game is 'yes'. 
select Location, count(*) gameCount
from roadkill
where Big_Game like 'yes'
group by Location
;

-- 29: How many vertebrate observations were made of the Mammal class?
select count(*) mammalCount
from VERTEBRATES v
join class c on c.Class = v.CLASS
where Field2 = 'Mammal'
;

-- 30: Show the species, Common_Name, scientific name, habitat definition, observer, and number observed for all vertebrates observed in numbers greater than 100
select species, Common_Name,  Scientific_Name, Definition, number
from VERTEBRATES v
join HABITAT_CODES h on v.Habitat = h.Code
where number > 100
;

-- 31: List all scientific names in the wildlife master list that do not appear in the vertebrates table
select Scientific_Name 
from WILDLIFE_MASTERLIST
where Scientific_Name not in (
	select Scientific_Name
	from VERTEBRATES
)
;

-- 32: List all Common_Names in the wildlife master list that do not appear in the invertebrates table
select Common_Name 
from WILDLIFE_MASTERLIST ml
where not exists (
	select *
	from INVERTEBRATES
	where ml.Common_Name = Common_Name
)
;

-- 33: Show the species of roadkill that were observed in 2014 but not in 2015. Include only one entry per species type.
select distinct species 
from Roadkill r
where year = 2014 and not exists (
	select species 
	from Roadkill
	where year = 2015 and r.Species = Species
)
;

-- 34: While highway marker had the most roadkill observations in 2021?
select top 1 HWY_Mile_Marker
from roadkill
where year = 2021
group by HWY_Mile_Marker
order by count(location) desc
;

-- 35: For each vertebrate observation type, show how many observations the observer named Buckley made
select OBS_TYPE, count(*) obsCount
from VERTEBRATES
where observer = 'Buckley'
group by OBS_TYPE
;

-- 36: Show the observation notes entered by observer stefanic for observations of vertebrates with the Common_Name dusky flycatcher
select notes 
from VERTEBRATES
where Observer like 'stefanic' and Common_Name like 'dusky flycatcher'
;

-- 37: Show all of the invertebrates' Common_Names, genus species, class, family, and order that were observed at the location Arco Tunnel
select Common_Name, Genus_species, class, family, [order]
from invertebrates
where location like 'Arco Tunnel'
;

-- 38: For each location that isn't listed as 'unknown', show the count of invertebrates observed at that location by the observer named Munts
select location, count(*) obsCount
from INVERTEBRATES
where location not like 'unknown' and observer like 'Munts'
group by location
;

-- 39: What are the common invertebrate names for invertebrates that were observed in the same habitat that the northern mockingbird was observed in?
select Common_Name 
from INVERTEBRATES i
where habitat in (
	select Habitat
	from VERTEBRATES
	where Common_Name like 'Northern mockingbird'
)
;

-- 40: how many habitat codes are there?
select count(*) codeCount
from HABITAT_CODES
;