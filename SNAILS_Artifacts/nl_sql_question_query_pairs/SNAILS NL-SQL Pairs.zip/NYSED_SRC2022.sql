-- 1: What are the accountability level of the indicators 'HS Grad Rate' for the multiracial subgroup for all schools with the word friendship in their name? Include the institution ID, entity name, and accountability level in the result.
select institution_id, ENTITY_NAME, LEVEL
from [Accountability_Levels]
where SUBGROUP_NAME = 'Multiracial' and INDICATOR = 'HS Grad Rate' and entity_name like '%friendship%'
;

-- 2: Show the percent not tested in 2021 on english language assessment ELA4, for each demographic subgroup at PEMBROKE INTERMEDIATE SCHOOL
select SUBGROUP_NAME, pct_not_tested
from [Annual_EM_ELA]
where entity_name = 'PEMBROKE INTERMEDIATE SCHOOL' 
    and ASSESSMENT_NAME = 'ELA4'
    and year = 2021
;

-- 3: What is the total number of new york state alternate assessment records for assessments performed in 2022 
select count(*) entryCount
from [Annual_NYSAA]
where year = 2022
;

-- 4: Show the student count, federal expenditure, and federal expenditure per student in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
select PUPIL_COUNT_TOT, FEDERAL_EXP, PER_FEDERAL_EXP
from [Expenditures_per_Pupil]
where entity_name = 'MONTESSORI MAGNET SCHOOL' and year = 2022
;

-- 5: Show the student count, federal expenditure, federal expenditure per student, subgroup name, and mean math assessment score for the MATH5 assessment in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
select PUPIL_COUNT_TOT, FEDERAL_EXP, PER_FEDERAL_EXP, SUBGROUP_NAME, MEAN_SCORE
from [Expenditures_per_Pupil] ex
join [Annual_EM_MATH] mth on ex.ENTITY_CD = mth.ENTITY_CD and ex.YEAR = mth.YEAR
where ex.entity_name = 'MONTESSORI MAGNET SCHOOL' and ASSESSMENT_NAME = 'MATH5' and ex.YEAR = 2022
;

-- 6: Show the 2022 high school participation rates and graduation rates for the subgroup 'All Students' who attended Brooklyn Collegiate. 
select rate, grad_rate
from [ACC_HS_Participation_Rate] p
join [ACC_HS_Graduation_Rate] g 
	on p.ENTITY_CD = g.ENTITY_CD 
	and p.SUBGROUP_NAME = g.SUBGROUP_NAME 
	and p.YEAR = g.YEAR 
	and p.ENTITY_NAME = g.ENTITY_NAME
	and p.INSTITUTION_ID = g.INSTITUTION_ID
where p.ENTITY_NAME = 'Brooklyn Collegiate' and p.SUBGROUP_NAME = 'All Students' and p.year = 2022
;

-- 7: What is Kenney Middle School's 2021 enrollment, absentee count, and absentee rate for the subgroup of students with disabilities?
select enrollment, absent_count, absent_rate
from [ACC_EM_Chronic_Absenteeism]
where entity_name = 'KENNEY MIDDLE SCHOOL' and year = 2021 and SUBGROUP_NAME = 'Students with disabilities'
;

-- 8: Show the annual regents exam percent of LONGWOOD HIGH SCHOOL students at each level from 1 to 5 for the Regents Common Core Algebra I subject taken in 2022. Include the subgroup name, number of students tested, and all of the appropriate percent level score columns.
select SUBGROUP_NAME, tested, PER_LEVEL1, PER_LEVEL2, PER_LEVEL3, PER_LEVEL4, PER_LEVEL5
from [Annual_Regents_Exams]
where ENTITY_NAME like '%LONGWOOD HIGH SCHOOL%'
	and year = 2022
	and subject = 'Regents Common Core Algebra I'
;

-- 9: How many public school entities are in each accountability status in the year 2022?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select overall_status, count(*) statusCount
from [Accountability_Status]
where year = 2022
and ENTITY_CD in (
	select entity_cd
	from [Institution_Grouping]
	where group_name = 'Public School'
)
group by overall_status
;

-- 10: What is the accountability status and progress status of the  bronx career and college prep HS in 2022?
select overall_status, made_progress
from [Accountability_Status]
where entity_name = 'bronx career and college prep hs' and year = 2022
;

-- 11: what are the combined subject, core and weighted, performance scores for elementary students with disabilities who attended May Moore Primary School?
select core_cohort, weighted_cohort 
from [ACC_EM_Core_and_Weighted_Performance]
where entity_name = 'May Moore Primary School'
	and subject = 'combined'
	and SUBGROUP_NAME = 'Students with Disabilities'
;

-- 12: Make a list of public elementary school entities that do not have the subgroup 'students with disabilities' in the elementary core and weighted performance data.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select distinct entity_name 
from [ACC_EM_Core_and_Weighted_Performance] p
where not exists (
	select ENTITY_CD
	from [ACC_EM_Core_and_Weighted_Performance] q
	where subgroup_name = 'Students with Disabilities' and p.ENTITY_CD = q.ENTITY_CD
)
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 13: How many public elementary school entities have the subgroup 'multiracial' included in the core and weighted performance data?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select count(distinct ENTITY_CD) schoolCount
from [ACC_EM_Core_and_Weighted_Performance]
where SUBGROUP_NAME = 'multiracial'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 14: Show the school name and english language learner count for the subgroup 'all students' for public school entities that have the word preparatory in their name.
select ENTITY_NAME, ELL_COUNT
from [ACC_EM_ELP]
where SUBGROUP_NAME = 'all students'
	and ENTITY_NAME like '%preparatory%'
;

-- 15: How many public elementary school entities have white student subgroups who are english language learners?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select count(*) schoolCount
from [ACC_EM_ELP]
where subgroup_name = 'white'
	and ell_count <> '0'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 16: What is the english language learner count, benchmark, progress rate, and success ratio for the sub group all students at 'pine bush' elementary school?
select ell_count, benchmark, progress_rate, success_ratio
from [ACC_EM_ELP]
where ENTITY_NAME = 'PINE BUSH' 
	and SUBGROUP_NAME = 'All Students'
;


-- 17: How many public elementary school entities had 0 participation in the new york state english as a second language achievement test?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select count(distinct entity_cd) noPartCount
from [ACC_EM_NYSESLAT_for_Participation]
where NYSESLAT_PART = '0'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 18: How many different new york state english as a second language achievement test elementary school subjects are there?
select count(distinct subject) subjectCount
from [ACC_EM_NYSESLAT_for_Participation]
;

-- 19: Show the names of the public elementary school entities with level 2 english learner programs that have a non-zero number of english language learners in the all students subgroup, who did not participate in the new york state english as a second language achievement test. Include only one row per school name.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select distinct entity_name
from [ACC_EM_ELP] 
where entity_cd in (
	select distinct entity_cd
	from [ACC_EM_NYSESLAT_for_Participation]
	where NYSESLAT_PART = '0'
) 
	and ELL_COUNT <> '0' 
	and SUBGROUP_NAME = 'all students' 
	and level = '2'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 20: What is the 2022 cohort size and student participation rate for all sub groups and subjects at elmwood elementary school?
select SUBGROUP_NAME, subject, cohort, rate
from [ACC_EM_Participation_Rate]
where entity_name = 'elmwood elementary school' and year = 2022
;

-- 21: How many public elementary school entities met a 95 percent participation rate in at least one subject?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select count(distinct entity_cd) schoolCount
from [ACC_EM_Participation_Rate]
where MET_95_PERCENT = 'Y'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 22: For public elementary school participation rates not equal to s, calculate the average participation rate.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT rate must be cast as a float. Exclude value 's' to enable casting.
select avg(cast(rate as float)) as avgRate
from [ACC_EM_Participation_Rate]
where rate <> 's'
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
;

-- 23: For each subject, show the average public high school entity chronic absence rate for records where the rate does not equal 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT ABSENT_RATE must be cast as a float. Exclude value 's' to enable casting.
select subject, avg(cast(absent_rate as float)) avgRate
from [ACC_EM_Chronic_Absenteeism]
where ABSENT_RATE <> 's'
and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
group by subject
;

-- 24: Show the name of the public elementary school entity that has the lowest chronic absence rate of students with disabilities. Exclude data where the rate value is 's'.
-- @HINT ABSENT_RATE must be cast as a float. Exclude value 's' to enable casting.
select top 1 entity_name
from [ACC_EM_Chronic_Absenteeism]
where SUBGROUP_NAME = 'students with disabilities' and absent_rate <> 's'
order by cast(absent_rate as float) desc
;

-- 25: show the school name, sub group name, and total enrollment at public elementary school entities that have the highest absenteeism rate in 2022. Exclude data where the absenteeism rate is 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT ABSENT_RATE must be cast as a float. Exclude value 's' to enable casting.
select a.entity_name, subgroup_name, enrollment
from [ACC_EM_Chronic_Absenteeism] a
join [Institution_Grouping] g on a.ENTITY_CD = g.ENTITY_CD
where cast(absent_rate as float) = (
	select max(cast(absent_rate as float)) 
	from [ACC_EM_Chronic_Absenteeism] 
	where absent_rate <> 's'
	and year = 2022
	)
	and absent_rate <> 's'
	and year = 2022
	and group_name = 'public school'
;

-- 26: What is the average public high school entity chronic absenteeism rate by student sub group in 2021? Do not include rows where the rate is 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT ABSENT_RATE must be cast as a float. Exclude value 's' to enable casting.
select subgroup_name, avg(cast(absent_rate as float)) avgRate
from [ACC_HS_Chronic_Absenteeism] a
join [Institution_Grouping] g on a.ENTITY_CD = g.ENTITY_CD
where absent_rate <> 's'
	and group_name = 'Public School'
group by subgroup_name
;

-- 27: What is the 2021 chronic absenteeism count and rate for the sub group 'All students' at the public high school entity with the highest enrollment? Exclude enrollment data that has the value 's'. Include the school name in the result. 
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT enrollment must be cast as a float. Exclude value 's' to enable casting.
select top 1 entity_name, absent_count, absent_rate
from [ACC_HS_Chronic_Absenteeism]
where enrollment <> 's'
	and year = 2021
	and ENTITY_CD in (
		select entity_cd
		from [Institution_Grouping]
		where group_name = 'Public School'
	)
	and SUBGROUP_NAME = 'All Students'
order by cast(enrollment as float) desc
;

-- 28: What are the core and weighted cohorts, and the core and weighted performance indexes of Economically Disadvantaged Students at Albany High School in the Math subject in 2022?
select core_cohort, weighted_cohort, core_index, weighted_index
from [ACC_HS_Core_and_Weighted_Performance]
where year = 2022
	and subject = 'MATH'
	and subgroup_name = 'Economically Disadvantaged'
	and entity_name = 'ALBANY HIGH SCHOOL'
;

-- 29: What are the names of the five public high school entity that have the highest weighted performance index score in math for the all student sub group in 2022? Exclude the value 's' from the index score.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT WEIGHTED_INDEX must be cast as a float. Exclude value 's' to enable casting.
select top 5 p.ENTITY_NAME 
from [ACC_HS_Core_and_Weighted_Performance] p
join [Institution_Grouping] g on p.ENTITY_CD = g.ENTITY_CD
where WEIGHTED_INDEX <> 's'
	and group_name = 'Public School'
	and subject = 'MATH'
	and subgroup_name = 'All Students'
	and year = 2022
order by cast(weighted_index as float) desc
;

-- 30: Show the school name and the average weighted index subject score for science for the five lowest scoring public school districts. Exclude weighted index scores with the value 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT WEIGHTED_INDEX must be cast as a float. Exclude value 's' to enable casting.
select top 5 entity_name, avg(cast(weighted_index as float)) averageScienceScore
from [ACC_HS_Core_and_Weighted_Performance]
where weighted_index <> 's'
and subject = 'SCIENCE'
and entity_cd in (
	select entity_cd
	from [Institution_Grouping]
	where GROUP_NAME = 'public school district'
)
group by entity_name
order by avg(cast(weighted_index as float)) asc
;

-- 31: What is the 2022 english language learner count, benchmark size, progress rate, success ration, and level of the english language program at Alfred E Smith Career-Tech HS for the all students subgroup?
select ELL_COUNT, BENCHMARK, PROGRESS_RATE, SUCCESS_RATIO, LEVEL
from [ACC_HS_ELP]
where ENTITY_NAME = 'ALFRED E SMITH CAREER-TECH HS'
	and SUBGROUP_NAME = 'All Students'
	and year = 2022
;

-- 32: What is the average english language learner count at public high schools for each student subgroup?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT ell_count must be cast as a float.
select subgroup_name, avg(cast(ell_count as float)) ELLAvg
from [ACC_HS_ELP]
where entity_cd in (
	select entity_cd
	from [Institution_Grouping]
	where GROUP_NAME = 'public school'
)
group by subgroup_name
;

-- 33: What is the 2022 federal expenditure per student at the public high school with the highest english language learner count in the All Students sub group in their english language program? Include the school name, language learner count, and federal expenditure per student in the result.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT ell_count must be cast as a float.
select top 1 el.ENTITY_NAME, ELL_COUNT, PER_FED_STATE_LOCAL_EXP
from [ACC_HS_ELP] el
join [Expenditures_per_Pupil] ex 
	on el.ENTITY_CD = ex.ENTITY_CD 
	and el.year = ex.year
where SUBGROUP_NAME = 'All Students'
	and ELL_COUNT <> 's'
	and ex.YEAR = 2022
	and el.entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school district'
	)
order by cast(ELL_COUNT as float) desc
;

-- 34: For each year and status type, what is the number of entities in accountability each status for the all students subgroup?
select YEAR, OVERALL_STATUS, count(*) entCount
from [Accountability_Status_by_Subgroup]
where SUBGROUP_NAME = 'All Students'
group by year, OVERALL_STATUS
;

-- 35: How many high schools (HS) had an accountability status of good standing in 2021 for the Multiracial sub group?
select count(*) HSCount
from [Accountability_Status_by_Subgroup]
where SCHOOL_TYPE = 'HS'
	and SUBGROUP_NAME = 'Multiracial'
	and year = 2021
;

-- 36: What is the overall acountability status for each school type and student subgroup in 2021 for the entity named 'albany city SD'?
select SCHOOL_TYPE, SUBGROUP_NAME, OVERALL_STATUS
from [Accountability_Status_by_Subgroup]
where year = 2021
	and ENTITY_NAME = 'ALBANY CITY SD'
;

-- 37: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each science assessment? Exclude scores with the value 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT percent tested columns must be cast as a float. Exclude value 's' to enable casting.
select ASSESSMENT_NAME, avg(cast([LEVEL1_%TESTED] as float)) L1, avg(cast([LEVEL2_%TESTED] as float)) L2, avg(cast([LEVEL3_%TESTED] as float)) L3, avg(cast([LEVEL4_%TESTED] as float)) L4
from [Annual_EM_Science]
where [LEVEL1_%TESTED] <> 's'
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school'
	)
group by ASSESSMENT_NAME
;

-- 38: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each sub group for the Science8 assessment? Exclude scores with the value 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT percent tested columns must be cast as a float. Exclude value 's' to enable casting.
select SUBGROUP_NAME, avg(cast([LEVEL1_%TESTED] as float)) L1, avg(cast([LEVEL2_%TESTED] as float)) L2, avg(cast([LEVEL3_%TESTED] as float)) L3, avg(cast([LEVEL4_%TESTED] as float)) L4
from [Annual_EM_Science]
where [LEVEL1_%TESTED] <> 's'
	and ASSESSMENT_NAME = 'Science8'
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school'
	)
group by SUBGROUP_NAME
;

-- 39: How many different subjects are present in the new york state english as a second language achievement test data?
select count(distinct subject) subjectCount
from [Annual_NYSESLAT]
;

-- 40: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the expanding level on the TS_6 subject on the new york state english as a second language achievement test in 2021?
select PER_EXP
from [Annual_NYSESLAT]
where SUBGROUP_NAME = 'Parent Not In Armed Forces'
	and SUBJECT = 'TS_6'
	and ENTITY_NAME = 'JOHANNA PERRIN MIDDLE SCHOOL'
	and year = 2021
;

-- 41: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
select PER_ENT, PER_EMER, PER_TRAN, PER_EXP
from [Annual_NYSESLAT]
where SUBGROUP_NAME = 'Parent Not In Armed Forces'
	and SUBJECT = 'TS_6'
	and ENTITY_NAME = 'JOHANNA PERRIN MIDDLE SCHOOL'
	and year = 2021
;

-- 42: For each subject, what is the average percent of students scoring at the entering level on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT per_ent must be cast as a float. Exclude value 's' to enable casting.
select subject, avg(cast(per_ent as float)) avgScore
from [Annual_NYSESLAT]
where per_ent <> 's'
	and year = 2021
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school district'
	)
group by subject
;

-- 43: For each subject, what is the average percent of students scoring at the entering level, the emerging level, the transitioning level, the expanding level, or the commanding level, on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT per_ent must be cast as a float. Exclude value 's' to enable casting.
select subject, 
	avg(cast(per_ent as float)) avgEnt,
	avg(cast(per_emer as float)) avgEmer,
	avg(cast(per_tran as float)) avgTran,
	avg(cast(per_exp as float)) avgExp,
	avg(cast(per_com as float)) avgCom
from [Annual_NYSESLAT]
where per_ent <> 's'
	and year = 2021
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school district'
	)
group by subject
;

-- 44: What is the number of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
select NUM_ENT, NUM_EMER, NUM_TRAN, NUM_EXP
from [Annual_NYSESLAT]
where SUBGROUP_NAME = 'Parent Not In Armed Forces'
	and SUBJECT = 'TS_6'
	and ENTITY_NAME = 'JOHANNA PERRIN MIDDLE SCHOOL'
	and year = 2021
;

-- 45: How many schools are a part of each board of cooperative educational services in 2020? Show the board name and the count of schools.
select BOCES_NAME, count(distinct school_name) SchoolCount
from [BOCES_and_N/RC]
where year = 2020
group by BOCES_NAME
;

-- 46: How many schools are a part of each county in 2020? Show the county name and the count of schools.
select COUNTY_NAME, count(distinct school_name) SchoolCount
from [BOCES_and_N/RC]
where year = 2020
group by COUNTY_NAME
;

-- 47: For each board of cooperative educational services in 2021, show the average federal and state and local expenditures_per_pupil. Include the board name and average expenditures in the result.
-- @HINT expense columns must be cast as floats.
select BOCES_NAME, avg(cast(PER_FEDERAL_EXP as float)) avgFedExp, avg(cast(PER_STATE_LOCAL_EXP as float)) avgLocExp
from [BOCES_and_N/RC] b
join [Expenditures_per_Pupil] e on b.ENTITY_CD = e.ENTITY_CD and b.YEAR = e.YEAR
where b.year = 2021
group by BOCES_NAME
;

-- 48: How many board of cooperative educational services are there?
select count(distinct BOCES_NAME) BOCESCount
from [BOCES_and_N/RC]
;

-- 49: Show the names of the board of cooperative educational services and the number of counties, for boards that have more than one county.
select BOCES_NAME, count(distinct COUNTY_NAME) CountyCount
from [BOCES_and_N/RC]
group by BOCES_NAME
having count(distinct COUNTY_NAME) > 1
;

-- 50: Show the number of teachers, number of inexperienced teaches, and percentage of inexperienced teaches at sheridan prep academy in 2021.
select NUM_TEACH, NUM_TEACH_INEXP, PER_TEACH_INEXP
from [Inexperienced_Teachers_and_Principals]
where entity_name = 'SHERIDAN PREP ACADEMY'
and year = 2021
;

-- 51: What are the entity codes, names and percentage inexperience teachers, of the five public schools with the highest percentage of inexperienced teachers in 2021?
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
select top 5 i.ENTITY_CD, i.ENTITY_NAME, PER_TEACH_INEXP
from [Inexperienced_Teachers_and_Principals] i
join [Institution_Grouping] g on i.ENTITY_CD = g.ENTITY_CD
where year = 2021
	and GROUP_NAME = 'public school'
order by PER_TEACH_INEXP desc
;

-- 52: What is the average percantage of inexperienced teachers for the five school districts with the highest average? Include the district name in the result.
select top 5 DISTRICT_NAME, AVG(PER_TEACH_INEXP) teachCount
from [Inexperienced_Teachers_and_Principals] i
join [BOCES_and_N/RC] b on i.ENTITY_CD = b.ENTITY_CD
group by DISTRICT_NAME
order by AVG(PER_TEACH_INEXP) desc
;

-- 53: What is the average of the total number of teachers and principals in low-poverty schools statewide?
select avg(TOT_PRINC_LOW) princLow, avg(TOT_TEACH_LOW) teachLow
from [Inexperienced_Teachers_and_Principals]
;

-- 54: In 2022, How many students in either the male or the female subgroup at Brocton Middle High School attended an out of state, four-year postsecondary institution? 
-- @HINT count columns must be cast as an integer.
select sum(cast(OUT_4_YR_CNT as int)) studentCount
from [Postsecondary_Enrollment]
where SUBGROUP_NAME in ('male', 'female')
	and ENTITY_NAME = 'BROCTON MIDDLE HIGH SCHOOL'
;

-- 55: For the 2022 subgroup 'All Students' at Oneida Senior High School, what is the total graduate count, the percent of graduates who enrolled in a new york state public two-year postsecondary institution, and the percent of graduates who enrolled in a new york state public four-year postsecondary institution?
select PER_NYS_PUB_2_YR, PER_NYS_PUB_4_YR
from [Postsecondary_Enrollment]
where year = 2022
	and ENTITY_NAME = 'ONEIDA SENIOR HIGH SCHOOL'
	and SUBGROUP_NAME = 'All Students'
;

-- 56: What is the name of the public school district that had the most teachers teaching out of certification in 2021?
-- @HINT Public school district status is indicated by the value 'public school district' in the group_name column in the Institution grouping table.
select top 1 ENTITY_NAME
from [Teachers_Teaching_Out_of_Certification]
where year = 2021
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school district'
	)
order by NUM_OUT_CERT desc
;

-- 57: In 2021, what was the number and percentage of teachers out of certification at bolton central school?
select NUM_OUT_CERT, PER_OUT_CERT
from [Teachers_Teaching_Out_of_Certification]
where ENTITY_NAME = 'BOLTON CENTRAL SCHOOL'
	and year = 2021
;

-- 58: Show the county name and total number of teachers teaching out of certification in each county.
select COUNTY_NAME, sum(NUM_OUT_CERT) OOCCount
from [Teachers_Teaching_Out_of_Certification] c
join [BOCES_and_N/RC] b on c.ENTITY_CD = b.ENTITY_CD
group by COUNTY_NAME
;

-- 59: Show the subgroup name, cohort count, the number of students with a valid score, the number of students scoring at levels 1 through 4 for the male and female subgroups at waverly high school in the 2017 cohort.
select subgroup_name, COHORT_COUNT, TEST_COUNT, LEVEL1_COUNT, LEVEL2_COUNT, LEVEL3_COUNT, LEVEL4_COUNT
from [Total_Cohort_Regents_Exams]
where ENTITY_NAME = 'WAVERLY HIGH SCHOOL'
	and COHORT = 2017
	and SUBGROUP_NAME in ('female', 'male')
	and SUBJECT = 'MATH'
;

-- 60: What is the name of the public school entity that had the highest percent of level four regents math exam scores in the 2017 student cohort and in the 'all students' sub group? Exclude score percentage values of 's'.
-- @HINT Public school district status is indicated by the value 'public school district' in the group_name column in the Institution grouping table.
-- @HINT percantage columns must be cast as an integer. Exclude value 's' to enable casting.
select TOP 1 ENTITY_NAME
from [Total_Cohort_Regents_Exams]
where COHORT = 2017
	and SUBGROUP_NAME = 'All Students'
	and SUBJECT = 'MATH'
	and [LEVEL4_%COHORT] <> 's'
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school'
	)
order by cast([LEVEL4_%COHORT] as int) desc
;

-- 61: How many different elementary school math assessment types are there?
select count(distinct ASSESSMENT_NAME) AssessmentCount
from [Annual_EM_MATH]
;

-- 62: How many  elementary students in the male sub group were given the Science4 assessment in 2021 at FORTS FERRY SCHOOL?
select total_count
from [Annual_EM_Science]
where year = 2021
	and SUBGROUP_NAME = 'male'
	and ASSESSMENT_NAME = 'Science4'
	and ENTITY_NAME = 'FORTS FERRY SCHOOL'
;

-- 63: What is the name of the public school entity that had the highest percentage of out-of-state four year postsecondary enrollments in 2022? Exclude percantage values of 's'.
-- @HINT Public school status is indicated by the value 'public school' in the group_name column in the Institution grouping table.
-- @HINT percantage columns must be cast as an integer. Exclude value 's' to enable casting.
select top 1 ENTITY_NAME
from [Postsecondary_Enrollment]
where year = 2022
	and SUBGROUP_NAME = 'All Students'
	and PER_OUT_4_YR <> 's'
	and entity_cd in (
		select entity_cd
		from [Institution_Grouping]
		where GROUP_NAME = 'public school'
	)
order by cast(PER_OUT_4_YR as int) desc
;