-- 1: How many different internal reconciliation types are there?
select count(distinct ReconType) numTypes
from oitr
;

-- 2: Show the payee names, zip, city, street, country, and states for the payees with the user department named 'General'
select PayeeName, PayeeZip, PayeeCity, PayeeStree, PayCountry, PayeeState
from OUDP departments
join OPEX paymentResultsTable on departments.Code = paymentResultsTable.department
where departments.Name = 'General'
;

-- 3: What are the account numbers that have checks for payment with more than one line? Include only one entry per account number.
select distinct AcctNum
from OCHO O
join CHO1 on O.CheckKey = CHO1.CheckKey
group by AcctNum, O.CheckKey
having count(*) > 1
;

-- 4: What are the witholding tax deduction amounts and percents for checks for payment associated with the account with account number '100-3443-7867'?
select Deduction, DdctPrcnt
from ocho
where AcctNum = '100-3443-7867'
;

-- 5: What is the card code, card name, address, and functional currency transfer amount for the incoming payments created in the year 2012 where the document summary currency code is 'EUR'
select CardCode, CardName, Address, TrsfrSumFC
from ORCT
where year(CreateDate) = 2012
	and DocCurr = 'EUR'
;

-- 6: What is the Withholding tax posted, account number, and functional currency sum for the incoming checks with the country code 'CA'
select WTOnhldPst, AcctNum, CheckSumFC
from ORCT
join RCT1 on ORCT.DocNum = RCT1.DocNum
where CountryCod = 'CA'
;

-- 7: How many incoming invoices document an applied value added tax of more than 700?
select count(*) invoiceCount
from RCT2
where vatApplied > 700
;

-- 8: For incoming payments processed with credit vouchers, show the average of the sums of the first partial payments.
select avg(FirstSum) firstPmtAvg
from ORCT
join RCT3 on ORCT.DocNum = RCT3.DocNum
;

-- 9: List the receipt number, card payment internal ID, and card account code for the credit card deposit deposited on 2012-01-31.
select RctAbs, DepNum, CardCode
from OCRH
where DeposDate = '2012-01-31'
;

-- 10: For the payment term with the term group code 'Net30', show the number of additional days, number of installments, and whether or not value added tax is applied on the first installment.
select ExtraDays, InstNum, VATFirst
from OCTG
where PymntGroup = 'Net30'
;