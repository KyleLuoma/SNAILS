-- 1: How many five year old turtles were measured?
SELECT COUNT (*) TURTLECOUNT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
WHERE [AG] = '5'
;

-- 2: How many turtles were measured at each location where turtles were measured?
SELECT [LOCATIONID], COUNT (*) TURTLECOUNT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
GROUP BY [LOCATIONID]
;

-- 3: what is the average weight of all turtles?
SELECT AVG ([WGHT]) TURTLEWEIGHT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
;

-- 4: at which locations were both snakes and turtles measured?
SELECT DISTINCT [T].[LOCATIONID]
FROM [TBLFIELDDATATURTLEMEASUREMENTS] T
JOIN [TBLFIELDDATASNAKEDATACOLLECTION] S ON [T].[LOCATIONID] = [S].[LOCATIONID]
;

-- 5: How many minnow traps are there at each location?
SELECT [LOCATIONID], COUNT (DISTINCT [TRP]) TRAPCOUNT
FROM [TBLFIELDDATAMINNOWTRAPSURVEYS]
GROUP BY [LOCATIONID]
;

-- 6: show the total number of minnows counted at each location
SELECT [LOCATIONID], SUM ([CNT]) MINNOWCOUNTSUM
FROM [TBLFIELDDATAMINNOWTRAPSURVEYS]
GROUP BY [LOCATIONID]
;

-- 7: show the total number of minnows counted at each trap by location. Each location has multiple traps.
SELECT [LOCATIONID], [TRP], SUM ([CNT]) MINNOWCOUNTSUM
FROM [TBLFIELDDATAMINNOWTRAPSURVEYS]
GROUP BY [LOCATIONID], [TRP]
;

-- 8: show how many minnows of each stage were counted at the location ASIS_HERPS_20H
SELECT [STG], SUM ([CNT]) MINNOWCOUNTSUM
FROM [TBLFIELDDATAMINNOWTRAPSURVEYS]
WHERE [LOCATIONID] = 'ASIS_HERPS_20H'
GROUP BY [STG]
;

-- 9: What is the average water temperature (celcius) at locations where amphibians were counted?
SELECT AVG ([TEMPC]) AVGTEMP
FROM [TBLFIELDDATAWATERPROPERTIES]
WHERE [LOCATIONID] IN (SELECT [LOCATIONID]
FROM [TBLFIELDDATAAMPHIBIANCALLCOUNTS])
;

-- 10: Show the average temperature, salinity, conductivity, and pH level of the water at locations corresponding to turtle observation records.
SELECT AVG ([TEMPC]) AVGTEMPC, AVG ([SLNITY]) AVGSALINITY, AVG ([CONDCTVTY]) AVGCONDUCT, AVG ([PH]) AVGPH
FROM [TBLFIELDDATAWATERPROPERTIES] W, [TBLFIELDDATATURTLETRAPSURVEYS] T
WHERE [W].[RECID] IN (SELECT [RECID]
FROM [TBLFIELDDATATURTLETRAPSURVEYS])
;

-- 11: Make a list of turtle record IDs and measurement comments where the trap survey sex data did not match the measurement sex data.
SELECT [T].[RECID], [M].[CMTS]
FROM [TBLFIELDDATATURTLETRAPSURVEYS] T
JOIN [TBLFIELDDATATURTLEMEASUREMENTS] M ON [T].[RECID] = [M].[RECID] AND [M].[SX] <> [T].[SX]
;

-- 12: show the heaviest turtle for each sex
SELECT [SX], MAX ([WGHT]) HEAVIESTWEIGHT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
GROUP BY [SX]
;

-- 13: what is the highest snake snout-to-vent length recorded?
SELECT TOP 1 [SNOUT_VNT_LEN]
FROM [TBLFIELDDATASNAKEDATACOLLECTION]
ORDER BY [SNOUT_VNT_LEN] DESC
;

-- 14: Show the average snake weight and snout-to-vent length by sex.
SELECT [SX], AVG ([WGHT]) AVGWEIGHT, AVG ([SNOUT_VNT_LEN]) AVGSVL
FROM [TBLFIELDDATASNAKEDATACOLLECTION]
GROUP BY [SX]
;

-- 15: show the average snake total length and weight by species.
SELECT [SPC_CODE], AVG ([TLENGTH]) AVGTLENGTH, AVG ([WGHT]) AVGWEIGHT
FROM [TBLFIELDDATASNAKEDATACOLLECTION]
GROUP BY [SPC_CODE]
;

-- 16: Show a count of turtle measurements made by each agency.
SELECT [AGCY/TITLE], COUNT (DISTINCT [RECID])
FROM [TBLFIELDDATATURTLEMEASUREMENTS] T
JOIN [TLINKOBSERVERS] OL ON [T].[EVTID] = [OL].[EVTID]
JOIN [OBSERVER_LU] O ON [O].[OBSINITS] = [OL].[OBSINITS]
GROUP BY [AGCY/TITLE]
;

-- 17: Make a list of all event IDs from 2004 that were observed by Allison Turner
SELECT [E].[EVTID]
FROM [TBLEVENTS] E
JOIN [TBLEVENTDATAHERPS] ED ON [E].[EVTID] = [ED].[EVTID]
JOIN [TLINKOBSERVERS] OL ON [ED].[EVTID] = [OL].[EVTID]
JOIN [OBSERVER_LU] O ON [OL].[OBSINITS] = [O].[OBSINITS]
WHERE [YR] = 2004 AND [FIRSTNM] = 'allison' AND [LSTNAME] = 'turner'
;

-- 18: Which observers participated in events where measurements of turtle were made? Show their initials, and first and last names.
SELECT DISTINCT [O].[OBSINITS], [FIRSTNM], [LSTNAME]
FROM [TLINKOBSERVERS] OL
JOIN [OBSERVER_LU] O ON [OL].[OBSINITS] = [O].[OBSINITS]
JOIN [TBLFIELDDATATURTLEMEASUREMENTS] TM ON [TM].[EVTID] = [OL].[EVTID]
;

-- 19: how many distinct species were documented on a reptile survey green card?
SELECT COUNT (DISTINCT [SPC_CODE]) SPECIESCOUNT
FROM [TBLFIELDDATAGREENCARDOBSERVATIONS]
;

-- 20: what are the Universal Transverse Mercator x and y coordinates for locations where time constrained searches were conducted? Include the location ID and x and y point coordinate averages in the result.
SELECT [L].[LOCATIONID], AVG ([UNIV_TRANS_MERC_X]) X, AVG ([UNIV_TRANS_MERC_Y]) Y
FROM [TBLFIELDDATATIMECONSTRAINEDSEARCHES] DF
JOIN [TBLLOCATIONSPOINTS] L ON [DF].[LOCATIONID] = [L].[LOCATIONID]
GROUP BY [L].[LOCATIONID]
;

-- 21: show a count of minnow measurements by stage description
SELECT [DESCRP], COUNT (*) MINNOWCOUNT
FROM [TLUSTAGE] S
JOIN [TBLFIELDDATAMINNOWTRAPSURVEYS] M ON [S].[STG] = [M].[STG]
GROUP BY [DESCRP]
;

-- 22: What is the ID and description of the occasional abundance category?
SELECT [ABNDNC_ID], [ABNDNCTXT]
FROM [TBLABUNDANCE_LU]
WHERE [ABNDNC] = 'Occasional'
;

-- 23: What are the location IDs of locations that have covers made out of wood? Only include one row per location ID.
SELECT DISTINCT [LOCATIONID]
FROM [TBLFIELDDATACOVERBOARD]
WHERE [TYP] = 'Wood'
;

-- 24: Show the board number and types for boards at site with ID 18CB1. Ignore boards with a number 0.
SELECT [BRD], [TYP]
FROM [TBLFIELDDATACOVERBOARD] CB
JOIN [TBLLOCATIONS] L ON [CB].[LOCATIONID] = [L].[LOCATIONID]
WHERE [STID] = '18CB1' AND [BRD] <> 0
;

-- 25: Show the average air temperature on cloudy days that correspond to cover board  data where the board material is wood at the site with id 30CB2
SELECT AVG ([AIRTEMP]) AS AVGTEMP
FROM [TBLFIELDDATACOVERBOARD] CB
JOIN [TBLEVENTDATAHERPS] EV ON [CB].[EVTID] = [EV].[EVTID]
JOIN [TBLLOCATIONS] L ON [CB].[LOCATIONID] = [L].[LOCATIONID]
WHERE [TYP] = 'Metal' AND [STID] = '30CB2' AND [WTHR] = 'cloudy'
;

-- 26: For each behavior type, how many records were documented for snakes captured using the coverboard method?
SELECT [BEHVR], COUNT (*) AS RECORDCOUNT
FROM [TBLFIELDDATASNAKEDATACOLLECTION]
WHERE [CAPTMTHD] = 'coverboard'
GROUP BY [BEHVR]
;

-- 27: what were the behaviors and capture methods of snakes where the record notes include the word rafters?
SELECT [BEHVR], [CAPTMTHD]
FROM [TBLFIELDDATASNAKEDATACOLLECTION]
WHERE [NTS] LIKE '%rafters%'
;

-- 28: for location points associated with records relating to cover boards, at the site with id 18CB1, what are the point IDs, snake ids, board numbers, and UTM X and Y coordinates?
SELECT [POINTID], [SNK_ID], [BRD], [UNIV_TRANS_MERC_X], [UNIV_TRANS_MERC_Y]
FROM [TBLFIELDDATACOVERBOARD] CB
JOIN [TBLLOCATIONS] L ON [CB].[LOCATIONID] = [L].[LOCATIONID]
JOIN [TBLLOCATIONSPOINTS] LP ON [L].[LOCATIONID] = [LP].[LOCATIONID]
WHERE [RECAP] = 'new' AND [STID] = '18CB1'
;

-- 29: What are the initials of observers who logged events relating to cover board observations? Include only one row per initials.
SELECT DISTINCT [O].[OBSINITS]
FROM [OBSERVER_LU] O
JOIN [TLINKOBSERVERS] TLO ON [O].[OBSINITS] = [TLO].[OBSINITS]
JOIN [TBLEVENTS] E ON [TLO].[EVTID] = [E].[EVTID]
JOIN [TBLFIELDDATACOVERBOARD] CB ON [E].[EVTID] = [CB].[EVTID]
;

-- 30: Show a count of events in the herpetological survey table, group the counts by weather condition. Also include the average air and water temperatures.
SELECT [WTHR], COUNT (*) EVENTCOUNT, AVG ([AIRTEMP]) AVGAIRTEMP, AVG ([WATERTEMP]) AVGWATERTEMP
FROM [TBLEVENTDATAHERPS]
GROUP BY [WTHR]
;

-- 31: Show the average air temperature for herpetological surveys for each observer. Group them by the initials of the observer who logged the event.
SELECT [O].[OBSINITS], AVG ([AIRTEMP]) AVGAIRTEMP
FROM [OBSERVER_LU] O
JOIN [TLINKOBSERVERS] TLO ON [O].[OBSINITS] = [TLO].[OBSINITS]
JOIN [TBLEVENTDATAHERPS] E ON [TLO].[EVTID] = [E].[EVTID]
GROUP BY [O].[OBSINITS]
;

-- 32: what is the average air temperature for each weather type for herpetological survey events?
SELECT [WTHR], AVG ([AIRTEMP]) AVGAIRTEMP
FROM [TBLEVENTDATAHERPS]
GROUP BY [WTHR]
;

-- 33: what is the description of project code WQ?
SELECT [DESCRP]
FROM [TLUPROJECT]
WHERE [PRJCT] = 'WQ'
;

-- 34: What type of park is the park with code ASIS?
SELECT [PTYPE]
FROM [TLUPARKCODE]
WHERE [PRKCD] = 'ASIS'
;

-- 35: What does the evidence code DOR mean?
SELECT [TXT]
FROM [TLUEVIDENCECODE]
WHERE [EVDNC_CD] = 'DOR'
;

-- 36: Show the habitat names and descriptions of the 'Temporary Pond' and 'Permanent Pond' micro habitats.
SELECT [HBTAT], [DESCRP]
FROM [TLUMICROHABITAT]
WHERE [HBTAT] IN ('Temporary Pond', 'Permanent Pond')
;

-- 37: How many records are logged for each turtle trap type?
SELECT [TRP_TYPE], COUNT (*) RECORDCOUNT
FROM [TBLFIELDDATATURTLETRAPSURVEYS]
GROUP BY [TRP_TYPE]
;

-- 38: Which location IDs have crab type turtle traps? Include only one row per location.
SELECT DISTINCT [T].[LOCATIONID]
FROM [TBLLOCATIONS] L
JOIN [TBLFIELDDATATURTLETRAPSURVEYS] T ON [L].[LOCATIONID] = [T].[LOCATIONID]
WHERE [TRP_TYPE] = 'crab'
;

-- 39: What are the average turtle dimensions by sex? Include carapace length and width, plastron length and width, and weight.
SELECT [SX], AVG ([CARA_LENGTH]) AVGCARLEN, AVG ([CARA_WIDTH]) AVGCARWID, AVG ([PLSTRN_LNGTH]) AVGPLASLEN, AVG ([PLSTRN_WDTH]) AVGPLASWID, AVG ([WGHT]) AVGWEIGHT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
GROUP BY [SX]
;

-- 40: how many turtle measurements were of turtles carrying eggs or young? This is indicated by the value 1.
SELECT COUNT (*) GRAVIDCOUNT
FROM [TBLFIELDDATATURTLEMEASUREMENTS]
WHERE [GRAVID] = 1
;

