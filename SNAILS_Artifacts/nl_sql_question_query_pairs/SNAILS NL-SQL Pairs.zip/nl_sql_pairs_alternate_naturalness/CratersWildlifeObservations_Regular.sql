-- 1: Show the notes for gray wolf observations with Bureau of Land Management (BLM) ownership
SELECT [NOTES]
FROM [VERTEBRATES]
WHERE [OWNERSHIP] = 'BLM' AND [COMMON_NAME] LIKE 'gray wolf'
;

-- 2: How many vertebrates were observed by either Stefanic or Dennis Hauser?
SELECT COUNT (*) OBSCOUNT
FROM [VERTEBRATES]
WHERE [OBSERVER] LIKE 'Stefanic' OR [OBSERVER] LIKE 'Dennis Hauser'
;

-- 3: For each breeding code, show the breeding code definition and count of vertebrate observations for observations of the species with the Common_Name 'mule deer'.
SELECT [DEFINITION], COUNT (*) DEERCOUNT
FROM [BREEDING_CODES] BC
JOIN [VERTEBRATES] V ON [BC].[BREED] = [V].[BREED]
WHERE [COMMON_NAME] = 'mule deer'
GROUP BY [DEFINITION]
;

-- 4: Show the Common_Name and genus species for all invertebrates of class Arachnida
SELECT [COMMON_NAME], [GENUS_SPECIES]
FROM [INVERTEBRATES]
WHERE [CLASS] LIKE 'arachnida'
;

-- 5: Show all of the family values in the invertebrates table that are not in the invertebrates family table. Exclude null values and include only one entry per type.
SELECT DISTINCT [FAMILY]
FROM [INVERTEBRATES] I
WHERE NOT EXISTS (SELECT [INVERT_FAMILY]
FROM [INVERT_FAMILY]
WHERE [INVERT_FAMILY] = [I].[FAMILY]) AND [FAMILY] IS NOT NULL
;

-- 6: Which species were documented as road kill at highway mile marker 235? Include only one entry per species type.
SELECT DISTINCT [SPECIES]
FROM [ROADKILL]
WHERE [HWY_MILE_MARKER] = '235'
;

-- 7: How many roadkill observations were made for each month in 2014?
SELECT [MONTH], COUNT (*) ROADKILLCOUNT
FROM [ROADKILL]
WHERE [YEAR] = 2014
GROUP BY [MONTH]
;

-- 8: Show the comments for roadkill entries made before 1990
SELECT [COMMENTS]
FROM [ROADKILL]
WHERE [YEAR] < 1990
;

-- 9: How many mule deer were counted as road kill in 2015?
SELECT COUNT (*) DEERCOUNT
FROM [ROADKILL]
WHERE [SPECIES] LIKE 'mule deer' AND [YEAR] = 2015
;

-- 10: How many roadkill records have a date that is identical to at least on vertebrate record?
SELECT COUNT (*) RECORDCOUNT
FROM [ROADKILL] R
WHERE EXISTS (SELECT *
FROM [VERTEBRATES]
WHERE [R].[DATE] = [DATE])
;

-- 11: What is the species, year and month of the roadkill observation with the highest number killed documented?
SELECT TOP 1 [SPECIES], [YEAR], [MONTH]
FROM [ROADKILL]
ORDER BY [NUMBER_KILLED] DESC
;

-- 12: For each habitat definition, show the count of vertebrates and the count of invertebrates records
SELECT [DEFINITION], [VERTHABCOUNT], [INVERTHABCOUNT]
FROM [HABITAT_CODES] H
JOIN (SELECT [HABITAT], COUNT (*) VERTHABCOUNT
FROM [VERTEBRATES]
GROUP BY [HABITAT]) V ON [V].[HABITAT] = [H].[CODE]
JOIN (SELECT [HABITAT], COUNT (*) INVERTHABCOUNT
FROM [INVERTEBRATES]
GROUP BY [HABITAT]) I ON [I].[HABITAT] = [H].[CODE]
;

-- 13: Show the definition of habitats that have more than 40 invertebrate records.
SELECT [DEFINITION]
FROM [HABITAT_CODES]
WHERE [CODE] IN (SELECT [HABITAT]
FROM [INVERTEBRATES]
GROUP BY [HABITAT]
HAVING COUNT (*) > 40)
;

-- 14: Which invertebrate records were recorded on the same day, at the same habitat, as at least one vertebrate record? Include the date, observer, and species Common_Name from the invertebrate entry.
SELECT [DATE], [OBSERVER], [COMMON_NAME]
FROM [INVERTEBRATES] I
WHERE EXISTS (SELECT *
FROM [VERTEBRATES]
WHERE [I].[DATE] = [DATE] AND [I].[HABITAT] = [HABITAT])
;

-- 15: For vertebrate and invertebrate observations recorded at the same habitat on the same day, show the observer recorded on the invertebrate record as well as the observer recorded on the vertebrate record. Also include the date, and the habitat definition.
SELECT [I].[OBSERVER], [V].[OBSERVER], [I].[DATE], [DEFINITION]
FROM [HABITAT_CODES] H
JOIN [INVERTEBRATES] I ON [I].[HABITAT] = [H].[CODE]
JOIN [VERTEBRATES] V ON [V].[DATE] = [I].[DATE] AND [V].[HABITAT] = [I].[HABITAT]
;

-- 16: Display the observation type and a count of invertebrate records for each observation type
SELECT [OBS_TYPE], COUNT (*) OBSCOUNT
FROM [INVERTEBRATES]
GROUP BY [OBS_TYPE]
;

-- 17: Show all the different locations where the Invertebrate species Trichodes ornatus has been observed
SELECT [LOCATION]
FROM [INVERTEBRATES]
WHERE [GENUS_SPECIES] LIKE 'Trichodes ornatus'
;

-- 18: Which observers have either only observed Invertebrates, or only observed Vertebrates, but not both?
SELECT DISTINCT [OBSERVER]
FROM [INVERTEBRATES] EXCEPT SELECT DISTINCT [OBSERVER]
FROM [VERTEBRATES]
;

-- 19: What are the Universal Transverse Mercator north and east coordinates for the records documenting the invertebrate with the Common_Name 'western white'?
SELECT [UNIVERSALTRANSVERSEMERCATORNORTH], [UNIVERSALTRANSVERSEMERCATOREAST]
FROM [INVERTEBRATES]
WHERE [COMMON_NAME] LIKE 'western white'
;

-- 20: What are the common and scientific names of vertebrates observed at the coordinates Universal Transverse Mercator North = 4814897 and Universal Transverse Mercator East = 291766
SELECT [COMMON_NAME], [SCIENTIFIC_NAME]
FROM [VERTEBRATES]
WHERE [UNIVERSALTRANSVERSEMERCATORNORTH] = 4814897 AND [UNIVERSALTRANSVERSEMERCATOREAST] = 291766
;

-- 21: Which roadkill species are not included in the Common_Name field of the invertebrates table? Include only one entry per value.
SELECT DISTINCT [SPECIES]
FROM [ROADKILL]
WHERE [SPECIES] NOT IN (SELECT [COMMON_NAME]
FROM [VERTEBRATES])
;

-- 22: What is the highest number of invertebrates  recorded in an observation for each family? Do not include NULL values in the number column.
SELECT [FAMILY], MAX ([NUMBER]) MAXNUM
FROM [INVERTEBRATES]
WHERE [NUMBER] IS NOT NULL
GROUP BY [FAMILY]
;

-- 23: How many paste are there where the species is 'deer'?
SELECT COUNT (*) ERRORCOUNT
FROM [PASTE_ERRORS]
WHERE [SPECIES] LIKE 'deer'
;

-- 24: Show the orders for invertebrates in the Insecta class. Only include one row per value.
SELECT DISTINCT [ORDER]
FROM [INVERTEBRATES]
WHERE [CLASS] LIKE 'Insecta'
;

-- 25: Get a count of invertebrate observations made at the Hot springs location for each observation type
SELECT [OBS_TYPE], COUNT (*) OBSCOUNT
FROM [INVERTEBRATES]
WHERE [LOCATION] LIKE 'Hot springs'
GROUP BY [OBS_TYPE]
;

-- 26: For each survey category of vertebrate records, show a count of observations made by the observer stefanic
SELECT [SURVEY], COUNT (*) STEFCOUNT
FROM [VERTEBRATES]
WHERE [OBSERVER] LIKE 'stefanic'
GROUP BY [SURVEY]
;

-- 27: What is the scientific name of the mammal commonly known as the moose? Only include one row in the response
SELECT [SCIENTIFIC_NAME]
FROM [WILDLIFE_MASTERLIST]
WHERE [COMMON_NAME] LIKE 'moose'
;

-- 28: Get a count of big game roadkill for each location. The value for big game is 'yes'.
SELECT [LOCATION], COUNT (*) GAMECOUNT
FROM [ROADKILL]
WHERE [BIG_GAME] LIKE 'yes'
GROUP BY [LOCATION]
;

-- 29: How many vertebrate observations were made of the Mammal class?
SELECT COUNT (*) MAMMALCOUNT
FROM [VERTEBRATES] V
JOIN [CLASS] C ON [C].[CLASS] = [V].[CLASS]
WHERE [DATAFIELD2] = 'Mammal'
;

-- 30: Show the species, Common_Name, scientific name, habitat definition, observer, and number observed for all vertebrates observed in numbers greater than 100
SELECT [SPECIES], [COMMON_NAME], [SCIENTIFIC_NAME], [DEFINITION], [NUMBER]
FROM [VERTEBRATES] V
JOIN [HABITAT_CODES] H ON [V].[HABITAT] = [H].[CODE]
WHERE [NUMBER] > 100
;

-- 31: List all scientific names in the wildlife master list that do not appear in the vertebrates table
SELECT [SCIENTIFIC_NAME]
FROM [WILDLIFE_MASTERLIST]
WHERE [SCIENTIFIC_NAME] NOT IN (SELECT [SCIENTIFIC_NAME]
FROM [VERTEBRATES])
;

-- 32: List all Common_Names in the wildlife master list that do not appear in the invertebrates table
SELECT [COMMON_NAME]
FROM [WILDLIFE_MASTERLIST] ML
WHERE NOT EXISTS (SELECT *
FROM [INVERTEBRATES]
WHERE [ML].[COMMON_NAME] = [COMMON_NAME])
;

-- 33: Show the species of roadkill that were observed in 2014 but not in 2015. Include only one entry per species type.
SELECT DISTINCT [SPECIES]
FROM [ROADKILL] R
WHERE [YEAR] = 2014 AND NOT EXISTS (SELECT [SPECIES]
FROM [ROADKILL]
WHERE [YEAR] = 2015 AND [R].[SPECIES] = [SPECIES])
;

-- 34: While highway marker had the most roadkill observations in 2021?
SELECT TOP 1 [HWY_MILE_MARKER]
FROM [ROADKILL]
WHERE [YEAR] = 2021
GROUP BY [HWY_MILE_MARKER]
ORDER BY COUNT ([LOCATION]) DESC
;

-- 35: For each vertebrate observation type, show how many observations the observer named Buckley made
SELECT [OBS_TYPE], COUNT (*) OBSCOUNT
FROM [VERTEBRATES]
WHERE [OBSERVER] = 'Buckley'
GROUP BY [OBS_TYPE]
;

-- 36: Show the observation notes entered by observer stefanic for observations of vertebrates with the Common_Name dusky flycatcher
SELECT [NOTES]
FROM [VERTEBRATES]
WHERE [OBSERVER] LIKE 'stefanic' AND [COMMON_NAME] LIKE 'dusky flycatcher'
;

-- 37: Show all of the invertebrates' Common_Names, genus species, class, family, and order that were observed at the location Arco Tunnel
SELECT [COMMON_NAME], [GENUS_SPECIES], [CLASS], [FAMILY], [ORDER]
FROM [INVERTEBRATES]
WHERE [LOCATION] LIKE 'Arco Tunnel'
;

-- 38: For each location that isn't listed as 'unknown', show the count of invertebrates observed at that location by the observer named Munts
SELECT [LOCATION], COUNT (*) OBSCOUNT
FROM [INVERTEBRATES]
WHERE [LOCATION] NOT LIKE 'unknown' AND [OBSERVER] LIKE 'Munts'
GROUP BY [LOCATION]
;

-- 39: What are the common invertebrate names for invertebrates that were observed in the same habitat that the northern mockingbird was observed in?
SELECT [COMMON_NAME]
FROM [INVERTEBRATES] I
WHERE [HABITAT] IN (SELECT [HABITAT]
FROM [VERTEBRATES]
WHERE [COMMON_NAME] LIKE 'Northern mockingbird')
;

-- 40: how many habitat codes are there?
SELECT COUNT (*) CODECOUNT
FROM [HABITAT_CODES]
;

