-- 1: What are the accountability level of the indicators 'HS Grad Rate' for the multiracial subgroup for all schools with the word friendship in their name? Include the institution ID, entity name, and accountability level in the result.
SELECT [INSTITUTION_ID], [ENTITY_NAME], [LEVEL]
FROM [ACCOUNTABILITY_LEVELS]
WHERE [SUBGROUP_NAME] = 'Multiracial' AND [INDICATOR] = 'HS Grad Rate' AND [ENTITY_NAME] LIKE '%friendship%'
;

-- 2: Show the percent not tested in 2021 on english language assessment ELA4, for each demographic subgroup at PEMBROKE INTERMEDIATE SCHOOL
SELECT [SUBGROUP_NAME], [PERCENT_NOT_TESTED]
FROM [ANNUAL_ELEMENTARY_ENGLISH_LANGUAGE_ARTS]
WHERE [ENTITY_NAME] = 'PEMBROKE INTERMEDIATE SCHOOL' AND [ASSESSMENT_NAME] = 'ELA4' AND [YEAR] = 2021
;

-- 3: What is the total number of new york state alternate assessment records for assessments performed in 2022
SELECT COUNT (*) ENTRYCOUNT
FROM [ANNUAL_NEW_YORK_STATE_ALTERNATE_ASSESSMENT]
WHERE [YEAR] = 2022
;

-- 4: Show the student count, federal expenditure, and federal expenditure per student in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT [TOTAL_PUPIL_COUNT], [FEDERAL_EXPENDITURES], [PER_PUPIL_EXPENDITURE_FEDERAL_FUNDS]
FROM [EXPENDITURES_PER_PUPIL]
WHERE [ENTITY_NAME] = 'MONTESSORI MAGNET SCHOOL' AND [YEAR] = 2022
;

-- 5: Show the student count, federal expenditure, federal expenditure per student, subgroup name, and mean math assessment score for the MATH5 assessment in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT [TOTAL_PUPIL_COUNT], [FEDERAL_EXPENDITURES], [PER_PUPIL_EXPENDITURE_FEDERAL_FUNDS], [SUBGROUP_NAME], [MEAN_STUDENT_SCORE]
FROM [EXPENDITURES_PER_PUPIL] EX
JOIN [ANNUAL_ELEMENTARY_MATH] MTH ON [EX].[ENTITY_CODE] = [MTH].[ENTITY_CODE] AND [EX].[YEAR] = [MTH].[YEAR]
WHERE [EX].[ENTITY_NAME] = 'MONTESSORI MAGNET SCHOOL' AND [ASSESSMENT_NAME] = 'MATH5' AND [EX].[YEAR] = 2022
;

-- 6: Show the 2022 high school participation rates and graduation rates for the subgroup 'All Students' who attended Brooklyn Collegiate.
SELECT [RATE], [GRADUATION_RATE]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_PARTICIPATION_RATE] P
JOIN [ACCOUNTABILITY_HIGH_SCHOOL_GRADUATION_RATE] G ON [P].[ENTITY_CODE] = [G].[ENTITY_CODE] AND [P].[SUBGROUP_NAME] = [G].[SUBGROUP_NAME] AND [P].[YEAR] = [G].[YEAR] AND [P].[ENTITY_NAME] = [G].[ENTITY_NAME] AND [P].[INSTITUTION_ID] = [G].[INSTITUTION_ID]
WHERE [P].[ENTITY_NAME] = 'Brooklyn Collegiate' AND [P].[SUBGROUP_NAME] = 'All Students' AND [P].[YEAR] = 2022
;

-- 7: What is Kenney Middle School's 2021 enrollment, absentee count, and absentee rate for the subgroup of students with disabilities?
SELECT [ENROLLMENT], [ABSENT_STUDENT_COUNT], [CHRONIC_ABSENTEEISM_RATE]
FROM [ACCOUNTABILITY_ELEMENTARY_CHRONIC_ABSENTEEISM]
WHERE [ENTITY_NAME] = 'KENNEY MIDDLE SCHOOL' AND [YEAR] = 2021 AND [SUBGROUP_NAME] = 'Students with disabilities'
;

-- 8: Show the annual regents exam percent of LONGWOOD HIGH SCHOOL students at each level from 1 to 5 for the Regents Common Core Algebra I subject taken in 2022. Include the subgroup name, number of students tested, and all of the appropriate percent level score columns.
SELECT [SUBGROUP_NAME], [TESTED], [PERCENT_STUDENTS_SCORING_LEVEL1], [PERCENT_STUDENTS_SCORING_LEVEL2], [PERCENT_STUDENTS_SCORING_LEVEL3], [PERCENT_STUDENTS_SCORING_LEVEL4], [PERCENT_STUDENTS_SCORING_LEVEL5]
FROM [ANNUAL_REGENTS_EXAMS]
WHERE [ENTITY_NAME] LIKE '%LONGWOOD HIGH SCHOOL%' AND [YEAR] = 2022 AND [SUBJECT] = 'Regents Common Core Algebra I'
;

-- 9: How many public school entities are in each accountability status in the year 2022?
SELECT [OVERALL_STATUS], COUNT (*) STATUSCOUNT
FROM [ACCOUNTABILITY_STATUS]
WHERE [YEAR] = 2022 AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
GROUP BY [OVERALL_STATUS]
;

-- 10: What is the accountability status and progress status of the  bronx career and college prep HS in 2022?
SELECT [OVERALL_STATUS], [MADE_PROGRESS]
FROM [ACCOUNTABILITY_STATUS]
WHERE [ENTITY_NAME] = 'bronx career and college prep hs' AND [YEAR] = 2022
;

-- 11: what are the combined subject, core and weighted, performance scores for elementary students with disabilities who attended May Moore Primary School?
SELECT [CORE_COHORT], [WEIGHTED_COHORT]
FROM [ACCOUNTABILITY_ELEMENTARY_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [ENTITY_NAME] = 'May Moore Primary School' AND [SUBJECT] = 'combined' AND [SUBGROUP_NAME] = 'Students with Disabilities'
;

-- 12: Make a list of public elementary school entities that do not have the subgroup 'students with disabilities' in the elementary core and weighted performance data.
SELECT DISTINCT [ENTITY_NAME]
FROM [ACCOUNTABILITY_ELEMENTARY_CORE_AND_WEIGHTED_PERFORMANCE] P
WHERE NOT EXISTS (SELECT [ENTITY_CODE]
FROM [ACCOUNTABILITY_ELEMENTARY_CORE_AND_WEIGHTED_PERFORMANCE] Q
WHERE [SUBGROUP_NAME] = 'Students with Disabilities' AND [P].[ENTITY_CODE] = [Q].[ENTITY_CODE]) AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 13: How many public elementary school entities have the subgroup 'multiracial' included in the core and weighted performance data?
SELECT COUNT (DISTINCT [ENTITY_CODE]) SCHOOLCOUNT
FROM [ACCOUNTABILITY_ELEMENTARY_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [SUBGROUP_NAME] = 'multiracial' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 14: Show the school name and english language learner count for the subgroup 'all students' for public school entities that have the word preparatory in their name.
SELECT [ENTITY_NAME], [ENGLISH_LANGUAGE_LEARNER_COUNT]
FROM [ACCOUNTABILITY_ELEMENTARY_ENGLISH_LANGUAGE_PROGRAM]
WHERE [SUBGROUP_NAME] = 'all students' AND [ENTITY_NAME] LIKE '%preparatory%'
;

-- 15: How many public elementary school entities have white student subgroups who are english language learners?
SELECT COUNT (*) SCHOOLCOUNT
FROM [ACCOUNTABILITY_ELEMENTARY_ENGLISH_LANGUAGE_PROGRAM]
WHERE [SUBGROUP_NAME] = 'white' AND [ENGLISH_LANGUAGE_LEARNER_COUNT] <> '0' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 16: What is the english language learner count, benchmark, progress rate, and success ratio for the sub group all students at 'pine bush' elementary school?
SELECT [ENGLISH_LANGUAGE_LEARNER_COUNT], [BENCHMARK], [PROGRESS_RATE], [SUCCESS_RATIO]
FROM [ACCOUNTABILITY_ELEMENTARY_ENGLISH_LANGUAGE_PROGRAM]
WHERE [ENTITY_NAME] = 'PINE BUSH' AND [SUBGROUP_NAME] = 'All Students'
;

-- 17: How many public elementary school entities had 0 participation in the new york state english as a second language achievement test?
SELECT COUNT (DISTINCT [ENTITY_CODE]) NOPARTCOUNT
FROM [ACCOUNTABILITY_ELEMENTARY_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST_PARTICIPATION]
WHERE [NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST_PARTICIPATION] = '0' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 18: How many different new york state english as a second language achievement test elementary school subjects are there?
SELECT COUNT (DISTINCT [SUBJECT]) SUBJECTCOUNT
FROM [ACCOUNTABILITY_ELEMENTARY_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST_PARTICIPATION]
;

-- 19: Show the names of the public elementary school entities with level 2 english learner programs that have a non-zero number of english language learners in the all students subgroup, who did not participate in the new york state english as a second language achievement test. Include only one row per school name.
SELECT DISTINCT [ENTITY_NAME]
FROM [ACCOUNTABILITY_ELEMENTARY_ENGLISH_LANGUAGE_PROGRAM]
WHERE [ENTITY_CODE] IN (SELECT DISTINCT [ENTITY_CODE]
FROM [ACCOUNTABILITY_ELEMENTARY_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST_PARTICIPATION]
WHERE [NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST_PARTICIPATION] = '0') AND [ENGLISH_LANGUAGE_LEARNER_COUNT] <> '0' AND [SUBGROUP_NAME] = 'all students' AND [LEVEL] = '2' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 20: What is the 2022 cohort size and student participation rate for all sub groups and subjects at elmwood elementary school?
SELECT [SUBGROUP_NAME], [SUBJECT], [COHORT], [RATE]
FROM [ACCOUNTABILITY_ELEMENTARY_PARTICIPATION_RATE]
WHERE [ENTITY_NAME] = 'elmwood elementary school' AND [YEAR] = 2022
;

-- 21: How many public elementary school entities met a 95 percent participation rate in at least one subject?
SELECT COUNT (DISTINCT [ENTITY_CODE]) SCHOOLCOUNT
FROM [ACCOUNTABILITY_ELEMENTARY_PARTICIPATION_RATE]
WHERE [MET_95_PERCENT] = 'Y' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 22: For public elementary school participation rates not equal to s, calculate the average participation rate.
SELECT AVG (CAST ([RATE] AS FLOAT)) AS AVGRATE
FROM [ACCOUNTABILITY_ELEMENTARY_PARTICIPATION_RATE]
WHERE [RATE] <> 's' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
;

-- 23: For each subject, show the average public high school entity chronic absence rate for records where the rate does not equal 's'.
SELECT [SUBJECT], AVG (CAST ([CHRONIC_ABSENTEEISM_RATE] AS FLOAT)) AVGRATE
FROM [ACCOUNTABILITY_ELEMENTARY_CHRONIC_ABSENTEEISM]
WHERE [CHRONIC_ABSENTEEISM_RATE] <> 's' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School')
GROUP BY [SUBJECT]
;

-- 24: Show the name of the public elementary school entity that has the lowest chronic absence rate of students with disabilities. Exclude data where the rate value is 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [ACCOUNTABILITY_ELEMENTARY_CHRONIC_ABSENTEEISM]
WHERE [SUBGROUP_NAME] = 'students with disabilities' AND [CHRONIC_ABSENTEEISM_RATE] <> 's'
ORDER BY CAST ([CHRONIC_ABSENTEEISM_RATE] AS FLOAT) DESC
;

-- 25: show the school name, sub group name, and total enrollment at public elementary school entities that have the highest absenteeism rate in 2022. Exclude data where the absenteeism rate is 's'.
SELECT [A].[ENTITY_NAME], [SUBGROUP_NAME], [ENROLLMENT]
FROM [ACCOUNTABILITY_ELEMENTARY_CHRONIC_ABSENTEEISM] A
JOIN [INSTITUTION_GROUPING] G ON [A].[ENTITY_CODE] = [G].[ENTITY_CODE]
WHERE CAST ([CHRONIC_ABSENTEEISM_RATE] AS FLOAT) = (SELECT MAX (CAST ([CHRONIC_ABSENTEEISM_RATE] AS FLOAT))
FROM [ACCOUNTABILITY_ELEMENTARY_CHRONIC_ABSENTEEISM]
WHERE [CHRONIC_ABSENTEEISM_RATE] <> 's' AND [YEAR] = 2022) AND [CHRONIC_ABSENTEEISM_RATE] <> 's' AND [YEAR] = 2022 AND [GROUP_NAME] = 'public school'
;

-- 26: What is the average public high school entity chronic absenteeism rate by student sub group in 2021? Do not include rows where the rate is 's'.
SELECT [SUBGROUP_NAME], AVG (CAST ([CHRONIC_ABSENTEEISM_RATE] AS FLOAT)) AVGRATE
FROM [ACCOUNTABILITY_HIGH_SCHOOL_CHRONIC_ABSENTEEISM] A
JOIN [INSTITUTION_GROUPING] G ON [A].[ENTITY_CODE] = [G].[ENTITY_CODE]
WHERE [CHRONIC_ABSENTEEISM_RATE] <> 's' AND [GROUP_NAME] = 'Public School'
GROUP BY [SUBGROUP_NAME]
;

-- 27: What is the 2021 chronic absenteeism count and rate for the sub group 'All students' at the public high school entity with the highest enrollment? Exclude enrollment data that has the value 's'. Include the school name in the result.
SELECT TOP 1 [ENTITY_NAME], [ABSENT_STUDENT_COUNT], [CHRONIC_ABSENTEEISM_RATE]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_CHRONIC_ABSENTEEISM]
WHERE [ENROLLMENT] <> 's' AND [YEAR] = 2021 AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'Public School') AND [SUBGROUP_NAME] = 'All Students'
ORDER BY CAST ([ENROLLMENT] AS FLOAT) DESC
;

-- 28: What are the core and weighted cohorts, and the core and weighted performance indexes of Economically Disadvantaged Students at Albany High School in the Math subject in 2022?
SELECT [CORE_COHORT], [WEIGHTED_COHORT], [CORE_INDEX], [WEIGHTED_INDEX]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_CORE_WEIGHTED_PERFORMANCE]
WHERE [YEAR] = 2022 AND [SUBJECT] = 'MATH' AND [SUBGROUP_NAME] = 'Economically Disadvantaged' AND [ENTITY_NAME] = 'ALBANY HIGH SCHOOL'
;

-- 29: What are the names of the five public high school entity that have the highest weighted performance index score in math for the all student sub group in 2022? Exclude the value 's' from the index score.
SELECT TOP 5 [P].[ENTITY_NAME]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_CORE_WEIGHTED_PERFORMANCE] P
JOIN [INSTITUTION_GROUPING] G ON [P].[ENTITY_CODE] = [G].[ENTITY_CODE]
WHERE [WEIGHTED_INDEX] <> 's' AND [GROUP_NAME] = 'Public School' AND [SUBJECT] = 'MATH' AND [SUBGROUP_NAME] = 'All Students' AND [YEAR] = 2022
ORDER BY CAST ([WEIGHTED_INDEX] AS FLOAT) DESC
;

-- 30: Show the school name and the average weighted index subject score for science for the five lowest scoring public school districts. Exclude weighted index scores with the value 's'.
SELECT TOP 5 [ENTITY_NAME], AVG (CAST ([WEIGHTED_INDEX] AS FLOAT)) AVERAGESCIENCESCORE
FROM [ACCOUNTABILITY_HIGH_SCHOOL_CORE_WEIGHTED_PERFORMANCE]
WHERE [WEIGHTED_INDEX] <> 's' AND [SUBJECT] = 'SCIENCE' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school district')
GROUP BY [ENTITY_NAME]
ORDER BY AVG (CAST ([WEIGHTED_INDEX] AS FLOAT)) ASC
;

-- 31: What is the 2022 english language learner count, benchmark size, progress rate, success ration, and level of the english language program at Alfred E Smith Career-Tech HS for the all students subgroup?
SELECT [ENGLISH_LANGUAGE_LEARNER_COUNT], [BENCHMARK], [PROGRESS_RATE], [SUCCESS_RATIO], [LEVEL]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_ENGLISH_LANGUAGE_PROGRAM]
WHERE [ENTITY_NAME] = 'ALFRED E SMITH CAREER-TECH HS' AND [SUBGROUP_NAME] = 'All Students' AND [YEAR] = 2022
;

-- 32: What is the average english language learner count at public high schools for each student subgroup?
SELECT [SUBGROUP_NAME], AVG (CAST ([ENGLISH_LANGUAGE_LEARNER_COUNT] AS FLOAT)) ELLAVG
FROM [ACCOUNTABILITY_HIGH_SCHOOL_ENGLISH_LANGUAGE_PROGRAM]
WHERE [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school')
GROUP BY [SUBGROUP_NAME]
;

-- 33: What is the 2022 federal expenditure per student at the public high school with the highest english language learner count in the All Students sub group in their english language program? Include the school name, language learner count, and federal expenditure per student in the result.
SELECT TOP 1 [EL].[ENTITY_NAME], [ENGLISH_LANGUAGE_LEARNER_COUNT], [PER_PUPIL_EXPENDITURES_FEDERAL_STATE_LOCAL_FUNDS]
FROM [ACCOUNTABILITY_HIGH_SCHOOL_ENGLISH_LANGUAGE_PROGRAM] EL
JOIN [EXPENDITURES_PER_PUPIL] EX ON [EL].[ENTITY_CODE] = [EX].[ENTITY_CODE] AND [EL].[YEAR] = [EX].[YEAR]
WHERE [SUBGROUP_NAME] = 'All Students' AND [ENGLISH_LANGUAGE_LEARNER_COUNT] <> 's' AND [EX].[YEAR] = 2022 AND [EL].[ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school district')
ORDER BY CAST ([ENGLISH_LANGUAGE_LEARNER_COUNT] AS FLOAT) DESC
;

-- 34: For each year and status type, what is the number of entities in accountability each status for the all students subgroup?
SELECT [YEAR], [OVERALL_STATUS], COUNT (*) ENTCOUNT
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [SUBGROUP_NAME] = 'All Students'
GROUP BY [YEAR], [OVERALL_STATUS]
;

-- 35: How many high schools (HS) had an accountability status of good standing in 2021 for the Multiracial sub group?
SELECT COUNT (*) HSCOUNT
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [SCHOOL_TYPE] = 'HS' AND [SUBGROUP_NAME] = 'Multiracial' AND [YEAR] = 2021
;

-- 36: What is the overall acountability status for each school type and student subgroup in 2021 for the entity named 'albany city SD'?
SELECT [SCHOOL_TYPE], [SUBGROUP_NAME], [OVERALL_STATUS]
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [YEAR] = 2021 AND [ENTITY_NAME] = 'ALBANY CITY SD'
;

-- 37: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each science assessment? Exclude scores with the value 's'.
SELECT [ASSESSMENT_NAME], AVG (CAST ([LEVEL1_%TESTED] AS FLOAT)) L1, AVG (CAST ([LEVEL2_%TESTED] AS FLOAT)) L2, AVG (CAST ([PERCENT_OF_TESTED_STUDENTS_SCORING_AT_LEVEL_3] AS FLOAT)) L3, AVG (CAST ([LEVEL4_%TESTED] AS FLOAT)) L4
FROM [ANNUAL_ELEMENTARY_SCIENCE]
WHERE [LEVEL1_%TESTED] <> 's' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school')
GROUP BY [ASSESSMENT_NAME]
;

-- 38: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each sub group for the Science8 assessment? Exclude scores with the value 's'.
SELECT [SUBGROUP_NAME], AVG (CAST ([LEVEL1_%TESTED] AS FLOAT)) L1, AVG (CAST ([LEVEL2_%TESTED] AS FLOAT)) L2, AVG (CAST ([PERCENT_OF_TESTED_STUDENTS_SCORING_AT_LEVEL_3] AS FLOAT)) L3, AVG (CAST ([LEVEL4_%TESTED] AS FLOAT)) L4
FROM [ANNUAL_ELEMENTARY_SCIENCE]
WHERE [LEVEL1_%TESTED] <> 's' AND [ASSESSMENT_NAME] = 'Science8' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school')
GROUP BY [SUBGROUP_NAME]
;

-- 39: How many different subjects are present in the new york state english as a second language achievement test data?
SELECT COUNT (DISTINCT [SUBJECT]) SUBJECTCOUNT
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
;

-- 40: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the expanding level on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [PERCENT_OF_STUDENTS_SCORING_EXPANDING_LEVEL]
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
WHERE [SUBGROUP_NAME] = 'Parent Not In Armed Forces' AND [SUBJECT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YEAR] = 2021
;

-- 41: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [PERCENT_OF_STUDENTS_SCORING_AT_ENTERING_LEVEL], [PERCENT_OF_STUDENTS_SCORING_EMERGING_LEVEL], [PERCENT_OF_STUDENTS_SCORING_AT_TRANSITIONING_LEVEL], [PERCENT_OF_STUDENTS_SCORING_EXPANDING_LEVEL]
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
WHERE [SUBGROUP_NAME] = 'Parent Not In Armed Forces' AND [SUBJECT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YEAR] = 2021
;

-- 42: For each subject, what is the average percent of students scoring at the entering level on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT [SUBJECT], AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_AT_ENTERING_LEVEL] AS FLOAT)) AVGSCORE
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
WHERE [PERCENT_OF_STUDENTS_SCORING_AT_ENTERING_LEVEL] <> 's' AND [YEAR] = 2021 AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school district')
GROUP BY [SUBJECT]
;

-- 43: For each subject, what is the average percent of students scoring at the entering level, the emerging level, the transitioning level, the expanding level, or the commanding level, on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT [SUBJECT], AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_AT_ENTERING_LEVEL] AS FLOAT)) AVGENT, AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_EMERGING_LEVEL] AS FLOAT)) AVGEMER, AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_AT_TRANSITIONING_LEVEL] AS FLOAT)) AVGTRAN, AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_EXPANDING_LEVEL] AS FLOAT)) AVGEXP, AVG (CAST ([PERCENT_OF_STUDENTS_SCORING_AT_COMMANDING_LEVEL] AS FLOAT)) AVGCOM
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
WHERE [PERCENT_OF_STUDENTS_SCORING_AT_ENTERING_LEVEL] <> 's' AND [YEAR] = 2021 AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school district')
GROUP BY [SUBJECT]
;

-- 44: What is the number of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [NUMBER_OF_STUDENTS_SCORING_ENTERING_LEVEL], [NUMBER_OF_STUDENTS_SCORING_AT_EMERGING_LEVEL], [NUMBER_OF_STUDENTS_SCORING_AT_TRANSITIONING_LEVEL], [NUMBER_OF_STUDENTS_SCORING_EXPANDING_LEVEL]
FROM [ANNUAL_NEW_YORK_STATE_ENGLISH_AS_A_SECOND_LANGUAGE_TEST]
WHERE [SUBGROUP_NAME] = 'Parent Not In Armed Forces' AND [SUBJECT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YEAR] = 2021
;

-- 45: How many schools are a part of each board of cooperative educational services in 2020? Show the board name and the count of schools.
SELECT [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME], COUNT (DISTINCT [SCHOOL_NAME]) SCHOOLCOUNT
FROM [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES]
WHERE [YEAR] = 2020
GROUP BY [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME]
;

-- 46: How many schools are a part of each county in 2020? Show the county name and the count of schools.
SELECT [COUNTY_NAME], COUNT (DISTINCT [SCHOOL_NAME]) SCHOOLCOUNT
FROM [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES]
WHERE [YEAR] = 2020
GROUP BY [COUNTY_NAME]
;

-- 47: For each board of cooperative educational services in 2021, show the average federal and state and local expenditures_per_pupil. Include the board name and average expenditures in the result.
SELECT [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME], AVG (CAST ([PER_PUPIL_EXPENDITURE_FEDERAL_FUNDS] AS FLOAT)) AVGFEDEXP, AVG (CAST ([PER_PUPIL_EXPENDITURES_STATE_LOCAL_FUNDS] AS FLOAT)) AVGLOCEXP
FROM [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES] B
JOIN [EXPENDITURES_PER_PUPIL] E ON [B].[ENTITY_CODE] = [E].[ENTITY_CODE] AND [B].[YEAR] = [E].[YEAR]
WHERE [B].[YEAR] = 2021
GROUP BY [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME]
;

-- 48: How many board of cooperative educational services are there?
SELECT COUNT (DISTINCT [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME]) BOCESCOUNT
FROM [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES]
;

-- 49: Show the names of the board of cooperative educational services and the number of counties, for boards that have more than one county.
SELECT [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME], COUNT (DISTINCT [COUNTY_NAME]) COUNTYCOUNT
FROM [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES]
GROUP BY [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES_NAME]
HAVING COUNT (DISTINCT [COUNTY_NAME]) > 1
;

-- 50: Show the number of teachers, number of inexperienced teaches, and percentage of inexperienced teaches at sheridan prep academy in 2021.
SELECT [NUM_TEACH], [NUMBER_OF_TEACHERS_WITH_LESS_THAN_FOUR_YEARS_EXPERIENCE], [PERCENT_TEACHERS_LESS_THAN_FOUR_YEARS_EXPERIENCE]
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS]
WHERE [ENTITY_NAME] = 'SHERIDAN PREP ACADEMY' AND [YEAR] = 2021
;

-- 51: What are the entity codes, names and percentage inexperience teachers, of the five public schools with the highest percentage of inexperienced teachers in 2021?
SELECT TOP 5 [I].[ENTITY_CODE], [I].[ENTITY_NAME], [PERCENT_TEACHERS_LESS_THAN_FOUR_YEARS_EXPERIENCE]
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS] I
JOIN [INSTITUTION_GROUPING] G ON [I].[ENTITY_CODE] = [G].[ENTITY_CODE]
WHERE [YEAR] = 2021 AND [GROUP_NAME] = 'public school'
ORDER BY [PERCENT_TEACHERS_LESS_THAN_FOUR_YEARS_EXPERIENCE] DESC
;

-- 52: What is the average percantage of inexperienced teachers for the five school districts with the highest average? Include the district name in the result.
SELECT TOP 5 [DISTRICT_NAME], AVG ([PERCENT_TEACHERS_LESS_THAN_FOUR_YEARS_EXPERIENCE]) TEACHCOUNT
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS] I
JOIN [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES] B ON [I].[ENTITY_CODE] = [B].[ENTITY_CODE]
GROUP BY [DISTRICT_NAME]
ORDER BY AVG ([PERCENT_TEACHERS_LESS_THAN_FOUR_YEARS_EXPERIENCE]) DESC
;

-- 53: What is the average of the total number of teachers and principals in low-poverty schools statewide?
SELECT AVG ([TOTAL_PRINCIPALS_LOW_POVERTY]) PRINCLOW, AVG ([TOTAL_TEACHERS_LOW_POVERTY]) TEACHLOW
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS]
;

-- 54: In 2022, How many students in either the male or the female subgroup at Brocton Middle High School attended an out of state, four-year postsecondary institution?
SELECT SUM (CAST ([OUT_OF_STATE_FOUR_YEAR_COUNT] AS INT)) STUDENTCOUNT
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [SUBGROUP_NAME] IN ('male', 'female') AND [ENTITY_NAME] = 'BROCTON MIDDLE HIGH SCHOOL'
;

-- 55: For the 2022 subgroup 'All Students' at Oneida Senior High School, what is the total graduate count, the percent of graduates who enrolled in a new york state public two-year postsecondary institution, and the percent of graduates who enrolled in a new york state public four-year postsecondary institution?
SELECT [PERCENT_OF_HIGH_SCHOOL_GRADUATES_ENROLLED_AT_NYS_PUBLIC_2_YEAR_INSTITUTION], [PERCENT_OF_HIGH_SCHOOL_GRADUATES_ENROLLED_AT_NYS_PUBLIC_4_YEAR_INSTITUTION]
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [YEAR] = 2022 AND [ENTITY_NAME] = 'ONEIDA SENIOR HIGH SCHOOL' AND [SUBGROUP_NAME] = 'All Students'
;

-- 56: What is the name of the public school district that had the most teachers teaching out of certification in 2021?
SELECT TOP 1 [ENTITY_NAME]
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION]
WHERE [YEAR] = 2021 AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school district')
ORDER BY [NUMBER_OF_TEACHERS_OUT_OF_CERTIFICATION] DESC
;

-- 57: In 2021, what was the number and percentage of teachers out of certification at bolton central school?
SELECT [NUMBER_OF_TEACHERS_OUT_OF_CERTIFICATION], [PERCENT_OF_TEACHERS_TEACHING_OUT_OF_SUBJECT_FIELD_CERTIFICATION]
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION]
WHERE [ENTITY_NAME] = 'BOLTON CENTRAL SCHOOL' AND [YEAR] = 2021
;

-- 58: Show the county name and total number of teachers teaching out of certification in each county.
SELECT [COUNTY_NAME], SUM ([NUMBER_OF_TEACHERS_OUT_OF_CERTIFICATION]) OOCCOUNT
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION] C
JOIN [BOARD_OF_COOPERATIVE_EDUCATIONAL_SERVICES] B ON [C].[ENTITY_CODE] = [B].[ENTITY_CODE]
GROUP BY [COUNTY_NAME]
;

-- 59: Show the subgroup name, cohort count, the number of students with a valid score, the number of students scoring at levels 1 through 4 for the male and female subgroups at waverly high school in the 2017 cohort.
SELECT [SUBGROUP_NAME], [COHORT_COUNT], [TEST_COUNT], [NUMBER_OF_STUDENTS_SCORING_LEVEL_1], [NUMBER_OF_STUDENTS_SCORING_LEVEL_2], [NUMBER_OF_STUDENTS_SCORING_LEVEL_3], [NUMBER_OF_STUDENTS_SCORING_LEVEL_4]
FROM [TOTAL_COHORT_REGENTS_EXAMS]
WHERE [ENTITY_NAME] = 'WAVERLY HIGH SCHOOL' AND [COHORT] = 2017 AND [SUBGROUP_NAME] IN ('female', 'male') AND [SUBJECT] = 'MATH'
;

-- 60: What is the name of the public school entity that had the highest percent of level four regents math exam scores in the 2017 student cohort and in the 'all students' sub group? Exclude score percentage values of 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [TOTAL_COHORT_REGENTS_EXAMS]
WHERE [COHORT] = 2017 AND [SUBGROUP_NAME] = 'All Students' AND [SUBJECT] = 'MATH' AND [PERCENT_OF_STUDENTS_IN_TOTAL_COHORT_SCORING_AT_LEVEL_4] <> 's' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school')
ORDER BY CAST ([PERCENT_OF_STUDENTS_IN_TOTAL_COHORT_SCORING_AT_LEVEL_4] AS INT) DESC
;

-- 61: How many different elementary school math assessment types are there?
SELECT COUNT (DISTINCT [ASSESSMENT_NAME]) ASSESSMENTCOUNT
FROM [ANNUAL_ELEMENTARY_MATH]
;

-- 62: How many  elementary students in the male sub group were given the Science4 assessment in 2021 at FORTS FERRY SCHOOL?
SELECT [TOTAL_COUNT]
FROM [ANNUAL_ELEMENTARY_SCIENCE]
WHERE [YEAR] = 2021 AND [SUBGROUP_NAME] = 'male' AND [ASSESSMENT_NAME] = 'Science4' AND [ENTITY_NAME] = 'FORTS FERRY SCHOOL'
;

-- 63: What is the name of the public school entity that had the highest percentage of out-of-state four year postsecondary enrollments in 2022? Exclude percantage values of 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [YEAR] = 2022 AND [SUBGROUP_NAME] = 'All Students' AND [PERCENT_OF_HIGH_SCHOOL_GRADUATES_ENROLLED_OUT_OF_STATE_FOUR_YEAR_POSTSECONDARY_INSTITUTION] <> 's' AND [ENTITY_CODE] IN (SELECT [ENTITY_CODE]
FROM [INSTITUTION_GROUPING]
WHERE [GROUP_NAME] = 'public school')
ORDER BY CAST ([PERCENT_OF_HIGH_SCHOOL_GRADUATES_ENROLLED_OUT_OF_STATE_FOUR_YEAR_POSTSECONDARY_INSTITUTION] AS INT) DESC
;

