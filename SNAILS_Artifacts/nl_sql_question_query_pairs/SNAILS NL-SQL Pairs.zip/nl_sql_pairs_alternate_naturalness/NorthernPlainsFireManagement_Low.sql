-- 1: How many events were logged in each year?
SELECT YEAR ([EVT_DT]) EVENTSYEAR, COUNT (*) EVENTCOUNT
FROM [TBL_EVENTS]
GROUP BY YEAR ([EVT_DT])
;

-- 2: What is the average midpoint diameter of deadwood in decay stage 2a?
SELECT AVG ([MIDPTDIAM]) AVGDIAMETER
FROM [TBL_DEADWOOD]
WHERE [DECY] = '2a'
;

-- 3: What are the directions to the Maddron Bald Trail?
SELECT [DIRCTNS]
FROM [TBL_LOCATIONS]
WHERE [TRL] = 'maddron bald trail'
;

-- 4: Show the site description of locations at plots that were in events in 2001
SELECT [SITEDESC]
FROM [TBL_LOCATIONS] L
JOIN [TBL_EVENTS] E ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE YEAR ([EVT_DT]) = 2001
;

-- 5: Show the genus, species, and common name of plant species observed in nested subpluts of event 30. Include only one row per type
SELECT DISTINCT [GENS], [SPEC], [CMN_NAME]
FROM [TBL_NESTS] N
JOIN [TLU_PLANTSPECIES] S ON [N].[SP_CODE] = [S].[SPCODE]
WHERE [EVT_ID] = 30
;

-- 6: What is the average diamater of overstory of the montana species observed in events 15 and 16
SELECT AVG ([DIAMBRSTHT]) AVGDIAMETER
FROM [TBL_EVENTS] E
JOIN [TBL_OVERSTORY] O ON [E].[EVT_ID] = [O].[EVT_ID]
JOIN [TLU_PLANTSPECIES] S ON [O].[SP_CODE] = [S].[SPCODE]
WHERE [SPEC] = 'montana' AND [E].[EVT_ID] IN (15, 16)
;

-- 7: Show all the diamater class 1, 2, 3 and 4 entries for sapplings with species code Abiefra
SELECT [SP_CODE], [DIAMCLASS1], [DIAMCLASS2], [DIAMCLASS3], [DIAMCLASS4]
FROM [TBL_SAPLINGS]
WHERE [SP_CODE] = 'Abiefra'
;

-- 8: What is the average seedling density of the Acer genus?
SELECT AVG ([DNSTY]) AVGSEEDLINGDENSITY
FROM [TBL_SEEDLINGS] S
JOIN [TLU_PLANTSPECIES] SP ON [S].[SP_CODE] = [SP].[SPCODE]
WHERE [GENS] = 'Acer'
;

-- 9: For each location ID, show the average seedling density of the Acer genus.
SELECT [LOC_ID], AVG ([DNSTY]) AVGSEEDLINGDENSITY
FROM [TBL_SEEDLINGS] S
JOIN [TLU_PLANTSPECIES] SP ON [S].[SP_CODE] = [SP].[SPCODE]
JOIN [TBL_EVENTS] E ON [E].[EVT_ID] = [S].[EVT_ID]
WHERE [GENS] = 'Acer'
GROUP BY [LOC_ID]
;

-- 10: What are the average north and east universal transvserse mercator coordinates of Sevier County TN?
SELECT AVG ([UTMEAST]) ECENTROID, AVG ([UTMNORTH]) NCENTROID
FROM [TLU_PLACENAMES]
WHERE [CNTY] = 'Sevier' AND [STAT] = 'TN'
;

-- 11: What are the X and Y coordinates, and the species code, of the tree with tag ID 144
SELECT [XCOORD], [YCOORD], [SP_CODE]
FROM [TBL_TREE_TAGS]
WHERE [TREE_TAG_ID] = 144
;

-- 12: For each tree condition, show the number of trees for trees with a tag number (not tag ID) greater than 220.
SELECT [TREECOND], COUNT (*) TREECOUNT
FROM [TBL_TREE_TAGS] TT
JOIN [TBL_OVERSTORY] O ON [O].[TRTAG] = [TT].[TREE_TAG_ID]
WHERE [TG] > 220
GROUP BY [TREECOND]
;

-- 13: Show the tree condition description and the total count of overstory in each condition category.
SELECT [TREECOND_TEXT], COUNT (*) TREECOUNT
FROM [TLU_TREE_COND] TC
JOIN [TBL_OVERSTORY] O ON [O].[TREECOND] = [TC].[TREECOND_NUM]
GROUP BY [TREECOND_TEXT]
;

-- 14: What is the species code and diameter at breast height of the witness tree that is furthest from the marking stake? Exclude location ID 4 from the result.
SELECT TOP 1 [WITNESS_SPCODE], [WTNSS_DIAM_BRST_HT]
FROM [TBL_WITNESSTREES]
WHERE [LOC_ID] <> 4
ORDER BY [WTNSS_STK] DESC
;

-- 15: How many overstory's have a codominant canopy position?
SELECT COUNT (*) OVERSTORYCOUNT
FROM [TLU_CAN_POS] C
JOIN [TBL_OVERSTORY] O ON [C].[CANPOS_NUMBER] = [O].[CANOPYPOS]
WHERE [CANPOS_NAME] = 'codominant'
;

-- 16: For each canopy position name, show how many overstory were classified for each position for the species with the common name 'Red Maple'
SELECT [CANPOS_NAME], COUNT (*) OVERSTORYCOUNT
FROM [TLU_CAN_POS] C
JOIN [TBL_OVERSTORY] O ON [C].[CANPOS_NUMBER] = [O].[CANOPYPOS]
JOIN [TLU_PLANTSPECIES] S ON [S].[SPCODE] = [O].[SP_CODE]
WHERE [CMN_NAME] = 'Red maple'
GROUP BY [CANPOS_NAME]
;

-- 17: For all of the locations with a Midslope topographical position, show the site description, slope, aspect, slope shape, and elevation
SELECT [SITEDESC], [SLOP], [ASPCT], [SLOP_SH], [ELEV]
FROM [TBL_LOCATIONS] L
JOIN [TLU_TOPO_POSITION] P ON [L].[TOPO_POSITION] = [P].[IDENTF]
WHERE [TOPOPOSITION] = 'Midslope'
;

-- 18: What is the species code and cover class text description of the nested subplot with ID 48?
SELECT [SP_CODE], [COVERCLASS_TXT]
FROM [TBL_NESTS] N
JOIN [TLU_COVER_CLS] CC ON [N].[COVR] = [CC].[COVERCLASS_NUM]
WHERE [NST_ID] = 48
;

-- 19: For each decay stage, show the description and the count of dead wood observations
SELECT [DECAYSTAGE_DESCR], COUNT (*) DEADWOODCOUNT
FROM [TLU_DECAYSTAGE] DC
JOIN [TBL_DEADWOOD] DW ON [DC].[DCYSTG_ID] = [DW].[DECY]
GROUP BY [DECAYSTAGE_DESCR]
;

-- 20: How many decay stages are there?
SELECT COUNT (*)
FROM [TLU_DECAYSTAGE]
;

-- 21: Show the length and midpoint diameter of dead wood in the decay stage that has 'log is flat' in the description?
SELECT [LEN], [MIDPTDIAM]
FROM [TBL_DEADWOOD] DW
JOIN [TLU_DECAYSTAGE] DC ON [DW].[DECY] = [DC].[DCYSTG_ID]
WHERE [DECAYSTAGE_DESCR] LIKE '%log is flat%'
;

-- 22: Show the genus of plant species observed in nested subplots where their presence description included the phrase 'species occurred in rest of plot'.
SELECT [GENS]
FROM [TLU_PLANTSPECIES] SP
JOIN [TBL_NESTS] N ON [N].[SP_CODE] = [SP].[SPCODE]
JOIN [TLU_R1_RESTOFPLOT] R ON [N].[PRES_CLS_SPEC_R1] = [R].[PRES_NUM]
WHERE [PRES_TEXT] LIKE '%species occurred in rest of plot%'
;

-- 23: How many plant species have the term 'native' in their notes? Show a count of these species by their genus. Only include the five highest results.
SELECT TOP 5 [GENS], COUNT (*) SPECIESCOUNT
FROM [TLU_PLANTSPECIES]
WHERE [SPECNOTES] LIKE '%native%'
GROUP BY [GENS]
ORDER BY COUNT (*) DESC
;

-- 24: Show the database title, file name, release notes, author email, and organization name, for the application release that occurred in 2015
SELECT [DB_TITLE], [FILE_NM], [RLS_NOTES], [AUTHR_EML], [AUTHOR_ORG_NAME]
FROM [TSYS_APP_RELEASES]
WHERE YEAR ([RLS_DATE]) = 2015
;

-- 25: How many different slope shapes are there in the lookup table?
SELECT COUNT (*)
FROM [TLU_SLOPE_SHAPE]
;

-- 26: For events that occurred in 1999, show the average seedling density by location ID.
SELECT [LOC_ID], AVG ([DNSTY]) SEEDLINGDENSITY
FROM [TBL_SEEDLINGS] S
JOIN [TBL_EVENTS] E ON [S].[EVT_ID] = [E].[EVT_ID]
WHERE YEAR ([EVT_DT]) = 1999
GROUP BY [LOC_ID]
;

-- 27: What is the average diameter of the fraseri overstory species measurement in each month with an event that measured one?
SELECT MONTH ([E].[EVT_DT]) MON, AVG ([DIAMBRSTHT]) AVGFRASERIDIAM
FROM [TBL_OVERSTORY] O
JOIN [TBL_EVENTS] E ON [E].[EVT_ID] = [O].[EVT_ID]
JOIN [TLU_PLANTSPECIES] S ON [O].[SP_CODE] = [S].[SPCODE]
WHERE [S].[SPEC] = 'fraseri'
GROUP BY MONTH ([E].[EVT_DT])
;

-- 28: Show a count of roads and trails by layer.
SELECT [LAYR], COUNT (*)
FROM [TLU_ROADS_AND_TRAILS]
GROUP BY [LAYR]
;

-- 29: Show a count of roads and trails by layer for entries that have the word Balsam in their valid name.
SELECT [LAYR], COUNT (*)
FROM [TLU_ROADS_AND_TRAILS]
WHERE [VLD_NM] LIKE '%Balsam%'
GROUP BY [LAYR]
;

-- 30: How many places are in each state?
SELECT [STAT], COUNT (*) PLACECOUNT
FROM [TLU_PLACENAMES]
GROUP BY [STAT]
;

-- 31: What is the name, county, state, and E and N coordinates of the northmost place?
SELECT TOP 1 [NAM], [CNTY], [STAT], [UTMEAST], [UTMNORTH]
FROM [TLU_PLACENAMES]
ORDER BY [UTMNORTH] DESC
;

-- 32: For each first presence description text entry, show the number of nested subplots in the event with id 30.
SELECT [PRES_TEXT], COUNT (*) NESTCOUNT
FROM [TLU_PRESENCE] P
JOIN [TBL_NESTS] N ON [P].[PRES_NUM] = [N].[PRES_FRST]
WHERE [EVT_ID] = 30
GROUP BY [PRES_TEXT]
;

-- 33: What is the distance between the highest and lowest X coordinate locations, and the distance between highest and lowest Y coordinate locations?
SELECT MAX ([X_COORD]) - MIN ([X_COORD]) XDIST, MAX ([Y_COORD]) - MIN ([Y_COORD]) YDIST
FROM [TBL_LOCATIONS]
;

-- 34: What is the Genus, species, and common name of the species with the highest seedling density?
SELECT TOP 1 [GENS], [SPEC], [CMN_NAME]
FROM [TBL_SEEDLINGS] S
JOIN [TLU_PLANTSPECIES] SP ON [S].[SP_CODE] = [SP].[SPCODE]
ORDER BY [DNSTY] DESC
;

-- 35: Which month has the highest average seedling density?
SELECT TOP 1 MONTH ([EVT_DT])
FROM [TBL_SEEDLINGS] S
JOIN [TBL_EVENTS] E ON [S].[EVT_ID] = [E].[EVT_ID]
GROUP BY MONTH ([EVT_DT])
ORDER BY AVG ([DNSTY]) DESC
;

-- 36: How many of each tree species have tree tags at location with ID 2? Show the counts by common species name.
SELECT [CMN_NAME], COUNT (*) TAGCOUNT
FROM [TBL_TREE_TAGS] TG
JOIN [TLU_PLANTSPECIES] SP ON [TG].[SP_CODE] = [SP].[SPCODE]
WHERE [LOC_ID] = 2
GROUP BY [CMN_NAME]
;

-- 37: How many of each tree species have tree tags at locations abobe 4000 feet? Show the counts by genus and common species name.
SELECT [GENS], [CMN_NAME], COUNT (*) TAGCOUNT
FROM [TBL_TREE_TAGS] TG
JOIN [TLU_PLANTSPECIES] SP ON [TG].[SP_CODE] = [SP].[SPCODE]
JOIN [TBL_LOCATIONS] L ON [TG].[LOC_ID] = [L].[LOC_ID]
WHERE [ELEV] > 4000
GROUP BY [GENS], [CMN_NAME]
;

-- 38: Show the ecology notes, coordinate units, coordinate system, and datum for the location on plot A14_1
SELECT [ECO_NOTES], [COORD_UNITS], [COORD_SYSTEM], [DTM]
FROM [TBL_LOCATIONS]
WHERE [PLT_ID] = 'A14_1'
;

-- 39: What are the location notes for the location that has the phrase 'probably post logging' in the other disturbance entry?
SELECT [LOC_NOTES]
FROM [TBL_LOCATIONS]
WHERE [OTH_DISTURB] LIKE '%probably post logging%'
;

-- 40: How many events had both overstory and deadwood entries?
SELECT COUNT (DISTINCT [EVT_ID]) EVENTCOUNT
FROM [TBL_DEADWOOD] D
WHERE [D].[EVT_ID] IN (SELECT [EVT_ID]
FROM [TBL_OVERSTORY])
;

