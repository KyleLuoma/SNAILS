-- 1: How many stations are there?
SELECT COUNT (*) AS STATION_COUNT
FROM [T_STNS]
;

-- 2: How many islands are there?
SELECT COUNT (DISTINCT [ISL])
FROM [T_LOCS]
;

-- 3: How many sites does each island have?
SELECT [ISL], COUNT (DISTINCT [ST_ID]) AS SITE_COUNT
FROM [T_LOCS]
GROUP BY [ISL]
;

-- 4: How many events have a half meter density count greater than 8?
SELECT COUNT (*) DENSITYCOUNT
FROM [T_DS]
WHERE [HLF_M] > 8
;

-- 5: Get a count of events by station
SELECT [ST_ID], COUNT (*) EVENT_COUNT
FROM [T_EV]
GROUP BY [ST_ID]
;

-- 6: How many contacts are there from each organization?
SELECT [ORG], COUNT (*) PERSON_COUNT
FROM [TLU_CTC]
GROUP BY [ORG]
;

-- 7: Show all of the zip codes for the city of Hilo.
SELECT DISTINCT [Z_CD]
FROM [TLU_CTC]
WHERE [CY] = 'Hilo'
;

-- 8: Make a list of events that are repeat samples that were verified by Lauren Smith, and that includes the event id, station id, and the start date,.
SELECT [EV_ID], [ST_ID], [ST_DT]
FROM [T_EV]
WHERE [RP_SMP] = 1 AND [VFD_BY] = 'Lauren Smith'
;

-- 9: how many observations were made in the forest bird habitat?
SELECT COUNT (*) OBSCOUNT
FROM [T_OBS] O
JOIN [TLU_SPC] S ON [O].[SP_ID] = [S].[SP_ID]
WHERE [HB] = 'Forest Bird'
;

-- 10: Show a count of observations by species habitat
SELECT [HB], COUNT (*) OBSCOUNT
FROM [TLU_SPC] S
JOIN [T_OBS] O ON [O].[SP_ID] = [S].[SP_ID]
GROUP BY [HB]
;

-- 11: Make a list of event ids for events that have more than 7 observations.
SELECT [E].[EV_ID]
FROM [T_EV] E
JOIN [T_OBS] O ON [E].[EV_ID] = [O].[EV_ID]
GROUP BY [E].[EV_ID]
HAVING COUNT (*) > 7
;

-- 12: What is the scientific and common name of the three most frequently observed bird species?
SELECT TOP 3 [SCI_NM], [CM_NM]
FROM [T_OBS] O
JOIN [TLU_SPC] S ON [O].[SP_ID] = [S].[SP_ID]
GROUP BY [SCI_NM], [CM_NM]
ORDER BY COUNT (*) DESC
;

-- 13: What is the most common understory composition and canopy composition combination of events entered by Caitlin Jensen?
SELECT TOP 1 [CN_CMP], [US_CMP]
FROM [T_HAB] H
JOIN [T_EV] E ON [H].[EV_ID] = [E].[EV_ID]
WHERE [E_BY] = 'caitlin jensen'
GROUP BY [CN_CMP], [US_CMP]
ORDER BY COUNT (*) DESC
;

-- 14: What are the weather conditions (cloud cover, rain, wind, and gusts) for events entered by Cari Squibb and updated by Seth Judge?
SELECT [CL], [R], [W], [G]
FROM [T_EV] E
JOIN [T_EV_DT] ED ON [E].[EV_ID] = [ED].[EV_ID]
WHERE [U_BY] = 'Seth Judge' AND [E_BY] = 'Cari Squibb'
;

-- 15: How many observations had more than 15 detections?
SELECT COUNT (*) OBSCOUNT
FROM (SELECT [OBS_ID]
FROM [T_DET] D
GROUP BY [OBS_ID]
HAVING COUNT ([DT_ID]) > 15) T
;

-- 16: What is the average detection distance for all detections?
SELECT AVG ([DST]) AVGDIST
FROM [T_DET]
;

-- 17: What is the common name of the species observed and detected from the farthest distance?
SELECT TOP 1 [CM_NM]
FROM [TLU_SPC] S
JOIN [T_OBS] O ON [S].[SP_ID] = [O].[SP_ID]
JOIN [T_DET] T ON [T].[OBS_ID] = [O].[OBS_ID]
ORDER BY [DST] DESC
;

-- 18: what are the common names and alternate names for birds of the family Laridae?
SELECT [CM_NM], [ALTNM]
FROM [TLU_SPC] S
JOIN [XREF_SPC_ALTNM] A ON [S].[SP_ID] = [A].[SP_ID]
WHERE [FM] = 'laridae'
;

-- 19: what are all of the different sources of species information?
SELECT DISTINCT [SRC]
FROM [TLU_SPC]
;

-- 20: What is the station name of the station currently located at UTM coordinates X 272454 Y 2141631
SELECT [ST]
FROM [T_STNS]
JOIN [T_ST_UTMS] ON [T_STNS].[ST_ID] = [T_ST_UTMS].[ST_ID]
WHERE [X_FIN] = 272454 AND [Y_FIN] = 2141631
;

-- 21: what is Patrick Hart's position and organization?
SELECT [P_TITL], [ORG]
FROM [TLU_CTC]
WHERE [F_NM] = 'Patrick' AND [L_NM] = 'Hart'
;

-- 22: What are the names of the sites on each island?
SELECT DISTINCT [ISL], [ST_NM]
FROM [T_LOCS]
JOIN [T_STS] ON [T_LOCS].[ST_ID] = [T_STS].[ST_ID]
;

-- 23: Which island has the location called Northwest Kahuku?
SELECT [ISL]
FROM [T_LOCS]
WHERE [LC_NM] = 'Northwest Kahuku'
;

-- 24: what are the family, scientific and common names of all of the bird species that occupy Forest Bird habitats?
SELECT DISTINCT [FM], [SCI_NM], [CM_NM]
FROM [TLU_SPC]
WHERE [HB] = 'Forest Bird'
;

-- 25: How many station locations are documented using WGS84 and how many are documented using NAD83 datums?
SELECT DISTINCT [DT], COUNT (*) STATIONCOUNT
FROM [T_ST_UTMS]
WHERE [DT] IN ('WGS84', 'NAD83')
GROUP BY [DT]
;

-- 26: How many observations were made on days when there were no clouds in the sky?
SELECT COUNT (*) OBS_COUNT
FROM [T_OBS] OBS
JOIN [T_EV_DT] DET ON [OBS].[EV_ID] = [DET].[EV_ID]
WHERE [CL] = 0
;

-- 27: how many events occurred on the most windy days?
SELECT COUNT (*) WINDY_DAY_COUNT
FROM [T_EV_DT]
WHERE [W] IN (SELECT MAX ([W])
FROM [T_EV_DT])
;

-- 28: How many stations does each island have?
SELECT [ISL], COUNT (*) AS STATION_COUNT
FROM [T_LOCS] LOC
JOIN [T_TRAN] TRANS ON [LOC].[L_ID] = [TRANS].[L_ID]
JOIN [T_STNS] STA ON [TRANS].[TR_ID] = [STA].[TR_ID]
GROUP BY [ISL]
;

-- 29: Which island has the fewest stations, and how many stations does it have?
SELECT TOP 1 [ISL], COUNT (*) AS STATION_COUNT
FROM [T_LOCS] LOC
JOIN [T_TRAN] TRANS ON [LOC].[L_ID] = [TRANS].[L_ID]
JOIN [T_STNS] STA ON [TRANS].[TR_ID] = [STA].[TR_ID]
GROUP BY [ISL]
ORDER BY [STATION_COUNT] ASC
;

-- 30: List the distinct family and species code of all bird observed during events logged when it was raining (denoted by the value 1).
SELECT DISTINCT [FM], [SP_CD]
FROM [TLU_SPC] S
JOIN [T_OBS] O ON [S].[SP_ID] = [O].[SP_ID]
JOIN [T_EV] E ON [O].[EV_ID] = [E].[EV_ID]
JOIN [T_EV_DT] ED ON [E].[EV_ID] = [ED].[EV_ID]
WHERE [R] = 1
;

-- 31: What species has Patrick Hart observed? List all of them by their scientific and common names. Don't include duplicate rows.
SELECT DISTINCT [SCI_NM], [CM_NM]
FROM [TLU_SPC] SPC
JOIN [T_OBS] OBS ON [SPC].[SP_ID] = [OBS].[SP_ID]
JOIN [XREF_EV_CTC] XCON ON [XCON].[EV_ID] = [OBS].[EV_ID]
JOIN [TLU_CTC] CON ON [XCON].[C_ID] = [CON].[C_ID]
WHERE [L_NM] = 'Hart' AND [F_NM] = 'Patrick'
ORDER BY [SCI_NM]
;

-- 32: At stations 2 and 3, show the station name and common names of each species observed at each station, and include the total count of observations per species.
SELECT [ST], [CM_NM], COUNT (*) NUMOBSERVATIONS
FROM [T_STNS] T_S
JOIN [T_EV] T_E ON [T_E].[ST_ID] = [T_S].[ST_ID]
JOIN [T_OBS] T_O ON [T_O].[EV_ID] = [T_E].[EV_ID]
JOIN [TLU_SPC] T_SP ON [T_O].[SP_ID] = [T_SP].[SP_ID]
WHERE [ST] = '2' OR [ST] = '3'
GROUP BY [ST], [CM_NM]
ORDER BY [ST]
;

-- 33: How many events does each station have? Show them in the descending order of event counts. Include the station name and the event count in the output.
SELECT [ST], COUNT (*) AS EVENT_COUNT
FROM [T_STNS] TS
JOIN [T_EV] TE ON [TS].[ST_ID] = [TE].[ST_ID]
GROUP BY [TS].[ST]
ORDER BY [EVENT_COUNT] DESC
;

-- 34: What is the northmost station's station name and position?
SELECT TOP 1 [LT_F], [LN_FINAL], [ST]
FROM [T_STNS]
ORDER BY [LT_F] DESC
;

-- 35: How many stations has the Hawaii Amakihi been observed at?
SELECT COUNT (DISTINCT [T_STNS].[ST_ID]) AS STATION_COUNT
FROM [T_STNS]
JOIN [T_EV] ON [T_STNS].[ST_ID] = [T_EV].[ST_ID]
JOIN [T_OBS] ON [T_OBS].[EV_ID] = [T_EV].[EV_ID]
JOIN [TLU_SPC] ON [TLU_SPC].[SP_ID] = [T_OBS].[SP_ID]
WHERE [CM_NM] = 'Hawaii Amakihi'
;

-- 36: What percent of stations has the bird with the common name Hawaii Amakihi been observed at?
SELECT 100 * (SUM ([SIGHTED]) / COUNT (DISTINCT [ST_ID])) AS PERC_STATIONS
FROM (SELECT DISTINCT [T_STNS].[ST_ID], CASE WHEN [TLU_SPC].[CM_NM] = 'Hawaii Amakihi' THEN 1.0 ELSE 0.0 END AS SIGHTED
FROM [T_STNS]
JOIN [T_EV] ON [T_STNS].[ST_ID] = [T_EV].[ST_ID]
JOIN [T_OBS] ON [T_OBS].[EV_ID] = [T_EV].[EV_ID]
JOIN [TLU_SPC] ON [TLU_SPC].[SP_ID] = [T_OBS].[SP_ID]) SIGHTINGS
;

-- 37: Show the first name, last name, and number of logged events for members of the national park service.
SELECT [L_NM], [F_NM], COUNT (*) NUM_EVENTS
FROM [TLU_CTC] TLC
JOIN [XREF_EV_CTC] XREC ON [TLC].[C_ID] = [XREC].[C_ID]
WHERE [ORG] = 'National Park Service'
GROUP BY [L_NM], [F_NM], [ORG]
ORDER BY [L_NM] DESC
;

-- 38: What is the average canopy height of each species' habitats? Include the common name and scientfic name of each species. Ensure the average has decimal precision.
SELECT [SCI_NM], [CM_NM], AVG (CAST ([CN_HT] AS FLOAT)) AS AVG_CANOPY_HEIGHT
FROM [T_HAB] HAB
JOIN [T_EV] EV ON [HAB].[EV_ID] = [EV].[EV_ID]
JOIN [T_OBS] OBS ON [OBS].[EV_ID] = [EV].[EV_ID]
JOIN [TLU_SPC] SPEC ON [SPEC].[SP_ID] = [OBS].[SP_ID]
GROUP BY [SCI_NM], [CM_NM]
ORDER BY [SCI_NM]
;

-- 39: Create a list of species sightings at each station. Include the island, site name, location name, transect and transect type, station, the station's latitude, the event id of the observations, the last names of those who observed as well as their notes, the family, scientific name, common name, and alternate name of each bird observed.
SELECT [ISL], [ST_NM], [LC_NM], [TR], [TR_TP], [ST], [LT_F], [TE].[EV_ID], [L_NM], [EV_NT], [FM], [SCI_NM], [CM_NM], [ALTNM]
FROM [T_LOCS] TL
JOIN [T_STS] TS ON [TL].[ST_ID] = [TS].[ST_ID]
JOIN [T_TRAN] TR ON [TR].[L_ID] = [TL].[L_ID]
JOIN [T_STNS] ST ON [ST].[TR_ID] = [TR].[TR_ID]
JOIN [T_EV] TE ON [TE].[ST_ID] = [ST].[ST_ID]
JOIN [XREF_EV_CTC] EC ON [EC].[EV_ID] = [TE].[EV_ID]
JOIN [TLU_CTC] CON ON [EC].[C_ID] = [CON].[C_ID]
JOIN [T_OBS] OBS ON [TE].[EV_ID] = [OBS].[EV_ID]
JOIN [TLU_SPC] SPC ON [OBS].[SP_ID] = [SPC].[SP_ID]
JOIN [XREF_SPC_ALTNM] SPC_ALT ON [SPC].[SP_ID] = [SPC_ALT].[SP_ID]
;

-- 40: Which island has the most sightings of the bird with the common name Pacific Kingfisher?
SELECT TOP 1 [ISL], COUNT (*) AS KINGFISHER_COUNT
FROM [T_LOCS] TL
JOIN [T_TRAN] TR ON [TR].[L_ID] = [TL].[L_ID]
JOIN [T_STNS] ST ON [ST].[TR_ID] = [TR].[TR_ID]
JOIN [T_EV] TE ON [TE].[ST_ID] = [ST].[ST_ID]
JOIN [XREF_EV_CTC] EC ON [EC].[EV_ID] = [TE].[EV_ID]
JOIN [TLU_CTC] CON ON [EC].[C_ID] = [CON].[C_ID]
JOIN [T_OBS] OBS ON [TE].[EV_ID] = [OBS].[EV_ID]
JOIN [TLU_SPC] SPC ON [OBS].[SP_ID] = [SPC].[SP_ID]
WHERE [CM_NM] = 'Pacific Kingfisher'
GROUP BY [ISL]
ORDER BY [KINGFISHER_COUNT]
;

