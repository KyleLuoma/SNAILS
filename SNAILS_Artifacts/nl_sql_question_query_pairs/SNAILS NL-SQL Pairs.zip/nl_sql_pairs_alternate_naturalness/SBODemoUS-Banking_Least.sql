-- 1: How many different internal reconciliation types are there?
SELECT COUNT (DISTINCT [RCTYPE]) NUMTYPES
FROM [OITR]
;

-- 2: Show the payee names, zip, city, street, country, and states for the payees with the user department named 'General'
SELECT [PY_NM], [P_ZP], [PCTY], [PSTREE], [PCNT], [PY_S]
FROM [OUDP] DEPARTMENTS
JOIN [OPEX] PAYMENTRESULTSTABLE ON [DEPARTMENTS].[CD] = [PAYMENTRESULTSTABLE].[DEPT]
WHERE [DEPARTMENTS].[NM] = 'General'
;

-- 3: What are the account numbers that have checks for payment with more than one line? Include only one entry per account number.
SELECT DISTINCT [ACCNUM]
FROM [OCHO] O
JOIN [CHO1] ON [O].[CK] = [CHO1].[CK]
GROUP BY [ACCNUM], [O].[CK]
HAVING COUNT (*) > 1
;

-- 4: What are the witholding tax deduction amounts and percents for checks for payment associated with the account with account number '100-3443-7867'?
SELECT [DED], [DDCTPRCNT]
FROM [OCHO]
WHERE [ACCNUM] = '100-3443-7867'
;

-- 5: What is the card code, card name, address, and functional currency transfer amount for the incoming payments created in the year 2012 where the document summary currency code is 'EUR'
SELECT [CRD_C], [CD_NM], [ADDR], [TRSFRSUMFC]
FROM [ORCT]
WHERE YEAR ([CRTDT]) = 2012 AND [DCR] = 'EUR'
;

-- 6: What is the Withholding tax posted, account number, and functional currency sum for the incoming checks with the country code 'CA'
SELECT [WTONHLDPST], [ACCNUM], [CK_SM_FC]
FROM [ORCT]
JOIN [RCT1] ON [ORCT].[D_NUM] = [RCT1].[D_NUM]
WHERE [CCOD] = 'CA'
;

-- 7: How many incoming invoices document an applied value added tax of more than 700?
SELECT COUNT (*) INVOICECOUNT
FROM [RCT2]
WHERE [VATAPP] > 700
;

-- 8: For incoming payments processed with credit vouchers, show the average of the sums of the first partial payments.
SELECT AVG ([FSUM]) FIRSTPMTAVG
FROM [ORCT]
JOIN [RCT3] ON [ORCT].[D_NUM] = [RCT3].[D_NUM]
;

-- 9: List the receipt number, card payment internal ID, and card account code for the credit card deposit deposited on 2012-01-31.
SELECT [RCTABS], [DPN], [CRD_C]
FROM [OCRH]
WHERE [DP_DT] = '2012-01-31'
;

-- 10: For the payment term with the term group code 'Net30', show the number of additional days, number of installments, and whether or not value added tax is applied on the first installment.
SELECT [ED], [I_NUM], [VATF]
FROM [OCTG]
WHERE [PYGP] = 'Net30'
;

