-- 1: Show the parameter names and parameter parameters for the parameters with the description 'Electronic documents'
SELECT [PARAMETER_NAME], [PARAMETER_PARAMETERS]
FROM [ELECTRONIC_COMMUNICATION_TYPES_PROTOCOLS]
JOIN [ELECTRONIC_COMMUNICATION_PARAMETERS] ON [ELECTRONIC_COMMUNICATION_TYPES_PROTOCOLS].[CODE] = [ELECTRONIC_COMMUNICATION_PARAMETERS].[CODE]
WHERE [DESCRIPTION] = 'Electronic documents'
;

-- 2: Get the field and object type xpaths for the mapping determinations associated with parameters with the description 'PEPPOL'.
SELECT [OBJECT_TYPE_XPATH], [FIELDXPATH]
FROM [IMPORT_MAPPING_DETERMINATION]
JOIN [ELECTRONIC_COMMUNICATION_TYPES_PROTOCOLS] ON [IMPORT_MAPPING_DETERMINATION].[CODE] = [ELECTRONIC_COMMUNICATION_TYPES_PROTOCOLS].[CODE]
WHERE [DESCRIPTION] = 'PEPPOL'
;

-- 3: How many queries are there in each category?
SELECT [QUERY_CATEGORY], COUNT (*) QCOUNT
FROM [QUERIES_TABLE_MAIN]
GROUP BY [QUERY_CATEGORY]
;

-- 4: Display the group description, log instance, the updated date, and the created date of the query group with the code 'Group4'
SELECT [AUTHORIZED_GROUP_DESCRIPTION], [LOGINSTANCE], [UPDATEDATE], [CREATEDATE]
FROM [QUERY_AUTHORIZATION_GROUPS]
WHERE [AUTHORIZED_GROUP_CODE] = 'Group4'
;

-- 5: What is the widest document width for documents with a grid size of 10?
SELECT TOP 1 [WIDTH]
FROM [DOCUMENT_TABLE]
WHERE [GRIDSIZE] = 10
ORDER BY [WIDTH] DESC
;

-- 6: What are the type codes and screen fonts for documents that use the email font 'Tahoma'?
SELECT [TYPECODE], [SCREENFONT]
FROM [DOCUMENT_TABLE]
WHERE [EMAILFONT] = 'Tahoma'
;

-- 7: Show the document code, and the document type code of the document types with 'Service Call' in the type name
SELECT [DOCUMENT_CODE], [CODE]
FROM [DOCUMENT_TABLE]
JOIN [DOCUMENT_TYPE_LIST] ON [DOCUMENT_TABLE].[DOCUMENT_CODE] = [DOCUMENT_TYPE_LIST].[STANDARD_REPORT]
WHERE [NAME] LIKE '%Service Call%'
;

-- 8: Show the document code and document name name, and count of reporting elements for each document with the type code 'WTR1'
SELECT [DOCUMENT_TABLE].[DOCUMENT_CODE], [REPORT_NAME], COUNT (*) ELMTCT
FROM [DOCUMENT_TABLE]
JOIN [REPORTING_ELEMENT_TABLE] ON [DOCUMENT_TABLE].[DOCUMENT_CODE] = [REPORTING_ELEMENT_TABLE].[DOCUMENT_CODE]
WHERE [TYPECODE] = 'WTR1'
GROUP BY [DOCUMENT_TABLE].[DOCUMENT_CODE], [REPORT_NAME]
;

-- 9: Show the Action for extension error, and the number of repetetive areas for documents that require conversion font for email (indicated by 'Y' value).
SELECT [ACTION_TAKEN_ON_EXT_ERROR], [NUMBER_OF_REPETITIVE_AREAS]
FROM [DOCUMENT_TABLE]
WHERE [CONVERT_FONT_FOR_EMAIL] = 'Y'
;

-- 10: What are the background, foreground, bold, and border red / green / blue values for the reporting elements with a height less than 5 and greater than 0?
SELECT [BACKGROUND_RED], [BACKGROUND_GREEN], [BACKGROUND_BLUE], [TEXT_RED], [TEXT_GREEN], [TEXT_BLUE], [BOLD_RED], [BOLD_BLUE], [BOLD_GREEN], [BORDER_RED], [BORDER_BLUE], [BORDER_GREEN]
FROM [REPORTING_ELEMENT_TABLE]
WHERE [HEIGHT] < 5 AND [HEIGHT] > 0
;

