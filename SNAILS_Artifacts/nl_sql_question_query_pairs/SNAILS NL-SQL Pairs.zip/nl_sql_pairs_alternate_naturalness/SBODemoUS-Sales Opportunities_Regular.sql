-- 1: Show the average potential max sales opportunity amount in local currency for each card group
SELECT [CARDGROUP], AVG ([LOCAL_POTENTIAL_AMOUNT]) AVGMAX
FROM [OPPORTUNITY_TABLE]
GROUP BY [CARDGROUP]
;

-- 2: What is the percent profit, gross profit total (local), gross profit total (system) for sales opportunities with the status 'W'?
SELECT [GROSS_PROFIT_PERCENTAGE], [GROSS_PROFIT_TOTAL_LOCAL], [GROSS_PROFIT_TOTAL_SYSTEM]
FROM [OPPORTUNITY_TABLE]
WHERE [STATUS] = 'W'
;

-- 3: For each sales opportunity, show sequence number and, carde code, the average percentage rate of all the rows associated with the opportunity
SELECT [OPPORTUNITY_TABLE].[RELATED_OPPORTUNITY], [CARDCODE], AVG ([PERCENTAGE_RATE]) AVGPERC
FROM [OPPORTUNITY_TABLE]
JOIN [OPPORTUNITY_ROWS] ON [OPPORTUNITY_TABLE].[RELATED_OPPORTUNITY] = [OPPORTUNITY_ROWS].[RELATED_OPPORTUNITY]
GROUP BY [OPPORTUNITY_TABLE].[RELATED_OPPORTUNITY], [CARDCODE]
;

-- 4: For row-level sales opportunity data, show the weighted amount in both system and local currency for rows with the close date occuring in 2014.
SELECT [WEIGHTED_AMOUNT_LC_DOCUMENT], [WT_AMOUNT_FUNCTIONAL_CURRENCY]
FROM [OPPORTUNITY_ROWS]
WHERE YEAR ([CLOSEDATE]) = 2014
;

-- 5: Show the cost center code, name, balance, and dimension code for cost centers that are active (Y value) and valid in 2021.
SELECT [COST_CENTER_CODE], [CENTER_NAME], [BALANCE], [DATASOURCE]
FROM [COST_CENTER_TABLE]
WHERE [ACTIVE] = 'Y' AND YEAR ([VALIDFROM]) = 2021
;

-- 6: For each card associated with a sales opportunity, Show the carde name, the sum of the real total amount (both local and system), the sum of the real closing gross profit (local and system), and the average closing percentage.
SELECT [CARDNAME], SUM ([TOTAL_AMOUNT_LOCAL]) TOTAL_AMOUNT_LOCAL, SUM ([TOTAL_AMOUNT_SYSTEM]) TOTAL_AMOUNT_SYSTEM, SUM ([CLOSING_GROSS_PROFIT_SYSTEM]) REALPROFSYS, SUM ([CLOSING_GROSS_PROFIT_LOCAL]) REALPROFLOC, AVG ([CLOSING_PERCENTAGE])
FROM [OPPORTUNITY_TABLE]
GROUP BY [CARDNAME]
;

-- 7: What are the open and close dates for sales opportunity rows that have a closing percentage of six or less?
SELECT [OPENDATE], [CLOSEDATE]
FROM [OPPORTUNITY_ROWS]
WHERE [PERCENTAGE_RATE] < = 6
;

-- 8: Show the newest sales opportunity start date for each opportunity status code
SELECT [STATUS], MAX ([OPENDATE]) MAXDATE
FROM [OPPORTUNITY_TABLE]
GROUP BY [STATUS]
;

-- 9: What is the dimension code of the cost center named 'General Center 3'?
SELECT [DIMENSION_CODE]
FROM [COST_CENTER_TABLE]
WHERE [CENTER_NAME] = 'General Center 3'
;

-- 10: Show the sales opportunity average gross profit in local currency by year created
SELECT YEAR ([CREATEDATE]) YEARCREATED, AVG ([GROSS_PROFIT_TOTAL_LOCAL]) AVGLOCPROFIT
FROM [OPPORTUNITY_TABLE]
GROUP BY YEAR ([CREATEDATE])
;

