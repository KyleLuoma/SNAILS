-- 1: How many stations are there?
select count(*) as station_count 
from tbl_stations
;

-- 2: How many islands are there?
select count(distinct Island) from tbl_locations
;

-- 3: How many sites does each island have?
select Island, count(distinct site_id) as site_count
from tbl_locations
group by Island
;

-- 4: How many events have a half meter density count greater than 8?
select count(*) densityCount
from tbl_Density
where Half_meter > 8
;

-- 5: Get a count of events by station
select station_id, count(*) event_count
from tbl_events
group by station_id
;

-- 6: How many contacts are there from each organization?
select organization, count(*) person_count
from tlu_contacts
group by organization
;

-- 7: Show all of the zip codes for the city of Hilo.
select distinct zip_code 
from tlu_contacts
where city = 'Hilo'
;

-- 8: Make a list of events that are repeat samples that were verified by Lauren Smith, and that includes the event id, station id, and the start date,.
select event_id, station_id, start_date 
from tbl_events
where repeat_sample = 1 and verified_by = 'Lauren Smith'
;

-- 9: how many observations were made in the forest bird habitat?
select count(*) obsCount
from tbl_observations o
join tlu_species s on o.Species_ID = s.Species_ID
where habitat = 'Forest Bird'
;

-- 10: Show a count of observations by species habitat
select habitat, count(*) obsCount
from tlu_species s
join tbl_observations o on o.Species_ID = s.Species_ID
group by habitat
;

-- 11: Make a list of event ids for events that have more than 7 observations.
select e.event_id
from tbl_events e
join tbl_observations o on e.Event_ID = o.Event_ID
group by e.event_id
having count(*) > 7
;

-- 12: What is the scientific and common name of the three most frequently observed bird species?
select top 3 scientific_name, common_name
from tbl_observations o
join tlu_species s on o.Species_ID = s.Species_ID
group by scientific_name, common_name
order by count(*) desc
;

-- 13: What is the most common understory composition and canopy composition combination of events entered by Caitlin Jensen?
select top 1 canopy_comp, understory_comp
from tbl_habitat h
join tbl_events e on h.event_id = e.event_id
where entered_by = 'caitlin jensen'
group by canopy_comp, understory_comp
order by count(*) desc
;


-- 14: What are the weather conditions (cloud cover, rain, wind, and gusts) for events entered by Cari Squibb and updated by Seth Judge?
select cloud, rain, wind, gust 
from tbl_events e
join tbl_Event_Details ed on e.Event_ID = ed.Event_ID
where updated_by = 'Seth Judge' and entered_by = 'Cari Squibb'
;

-- 15: How many observations had more than 15 detections?
select count(*) obsCount
from (
	select observation_id 
	from tbl_detections d
	group by Observation_ID
	having count(Detection_ID) > 15
) t
;

-- 16: What is the average detection distance for all detections?
select avg(distance) avgdist
from tbl_detections
;

-- 17: What is the common name of the species observed and detected from the farthest distance?
select top 1 common_name
from tlu_species s
join tbl_observations o on s.species_id = o.species_id
join tbl_detections t on t.observation_id = o.observation_id
order by distance desc
;


-- 18: what are the common names and alternate names for birds of the family Laridae?
select common_name, alternate_name
from tlu_species s
join xref_species_alternate_names a on s.species_id = a.species_id
where family = 'laridae'
;

-- 19: what are all of the different sources of species information?
select distinct source
from tlu_species
;



-- 20: What is the station name of the station currently located at UTM coordinates X 272454 Y 2141631
select Station 
from tbl_stations 
join tbl_Stations_UTMs on tbl_stations.Station_ID = tbl_stations_utms.Station_ID
where X_final = 272454 and Y_final = 2141631
;

-- 21: what is Patrick Hart's position and organization?
select position_title, organization
from tlu_contacts
where First_Name = 'Patrick' and Last_Name = 'Hart'
;

-- 22: What are the names of the sites on each island?
select distinct Island, Site_name
from tbl_locations
join tbl_sites on tbl_locations.site_id = tbl_sites.site_id
;

-- 23: Which island has the location called Northwest Kahuku?
select Island
from tbl_locations
where loc_name = 'Northwest Kahuku'
;

-- 24: what are the family, scientific and common names of all of the bird species that occupy Forest Bird habitats?
select distinct family, scientific_name, common_name 
from tlu_species
where habitat = 'Forest Bird'
;

-- 25: How many station locations are documented using WGS84 and how many are documented using NAD83 datums?
select distinct datum, count(*) stationCount
from tbl_stations_utms
where datum in ('WGS84', 'NAD83')
group by datum
;

-- 26: How many observations were made on days when there were no clouds in the sky?
select count(*) obs_count
from tbl_observations obs
join tbl_event_details det on obs.Event_ID = det.Event_ID
where Cloud = 0
;

-- 27: how many events occurred on the most windy days?
select count(*) windy_day_count
from tbl_event_details
where wind in (
	select max(wind) from tbl_event_details
)
;

-- 28: How many stations does each island have?
select Island, count(*) as station_count
from tbl_locations loc
join tbl_transect trans on loc.location_id = trans.location_id
join tbl_stations sta on trans.transect_id = sta.Transect_ID
group by Island
;

-- 29: Which island has the fewest stations, and how many stations does it have?
select top 1 Island, count(*) as station_count
from tbl_locations loc
join tbl_transect trans on loc.location_id = trans.location_id
join tbl_stations sta on trans.transect_id = sta.Transect_ID
group by Island
order by station_count asc
;

-- 30: List the distinct family and species code of all bird observed during events logged when it was raining (denoted by the value 1).
select distinct family, species_code
from tlu_species s
join tbl_observations o on s.species_id = o.species_id
join tbl_events e on o.event_id = e.event_id
join tbl_event_details ed on e.event_id = ed.event_id
where rain = 1
;


-- 31: What species has Patrick Hart observed? List all of them by their scientific and common names. Don't include duplicate rows.
select distinct scientific_name, common_name
from tlu_species spc
join tbl_observations obs on spc.Species_ID = obs.species_id
join xref_event_contacts xcon on xcon.Event_ID = obs.event_id
join tlu_contacts con on xcon.Contact_ID = con.Contact_ID
where last_name = 'Hart' and first_name = 'Patrick'
order by Scientific_Name
;


-- 32: At stations 2 and 3, show the station name and common names of each species observed at each station, and include the total count of observations per species. 
select Station, Common_Name, count(*) NumObservations
from tbl_Stations t_s 
join tbl_Events t_e on t_e.Station_ID = t_s.Station_ID
join tbl_Observations t_o on t_o.Event_ID = t_e.Event_ID
join tlu_Species t_sp on t_o.Species_ID = t_sp.Species_iD
where Station = '2' or Station = '3'
group by Station, Common_Name
order by Station
;

-- 33: How many events does each station have? Show them in the descending order of event counts. Include the station name and the event count in the output.
select station, count(*) as event_count
from tbl_stations ts
join tbl_events te on ts.station_id = te.station_id
group by ts.station
order by event_count desc
;

-- 34: What is the northmost station's station name and position?
select top 1 lat_final, long_final, Station 
from tbl_stations
order by lat_final desc
;

-- 35: How many stations has the Hawaii Amakihi been observed at?
select count(distinct tbl_stations.station_id) as station_count
from tbl_stations
join tbl_events on tbl_stations.station_id = tbl_events.station_id
join tbl_observations on tbl_observations.event_id = tbl_events.event_id
join tlu_species on tlu_species.species_id = tbl_observations.species_id
where common_name = 'Hawaii Amakihi'
;

-- 36: What percent of stations has the bird with the common name Hawaii Amakihi been observed at?
select 100 * (sum(sighted) / count(distinct station_id)) as perc_stations from (
	select distinct tbl_stations.station_id, case 
			when tlu_species.common_name = 'Hawaii Amakihi' then 1.0 else 0.0
			end as sighted
	from tbl_stations
	join tbl_events on tbl_stations.station_id = tbl_events.station_id
	join tbl_observations on tbl_observations.event_id = tbl_events.event_id
	join tlu_species on tlu_species.species_id = tbl_observations.species_id
) sightings
;

-- 37: Show the first name, last name, and number of logged events for members of the national park service.
select last_name, first_name, count(*) num_events
from tlu_contacts tlc
join xref_event_contacts xrec on tlc.Contact_ID = xrec.Contact_ID
where organization = 'National Park Service'
group by last_name, first_name, organization
order by last_name desc
;


-- 38: What is the average canopy height of each species' habitats? Include the common name and scientfic name of each species. Ensure the average has decimal precision.
select Scientific_Name, Common_Name, avg(cast(canopy_height as float)) as avg_canopy_height
from tbl_habitat hab
join tbl_events ev on hab.Event_ID = ev.Event_ID
join tbl_Observations obs on obs.Event_ID = ev.Event_ID
join tlu_species spec on spec.species_id = obs.species_id
group by Scientific_Name, common_name
order by Scientific_Name
;


-- 39: Create a list of species sightings at each station. Include the island, site name, location name, transect and transect type, station, the station's latitude, the event id of the observations, the last names of those who observed as well as their notes, the family, scientific name, common name, and alternate name of each bird observed.
select island, site_name, Loc_Name, transect, transect_type, Station, lat_final, te.event_id, last_name, event_notes, family, Scientific_Name, Common_Name, Alternate_Name
from tbl_locations tl
join tbl_sites ts on tl.Site_ID = ts.Site_ID
join tbl_transect tr on tr.Location_ID = tl.Location_ID
join tbl_stations st on st.Transect_ID = tr.Transect_ID
join tbl_events te on te.station_id = st.station_id
join xref_Event_Contacts ec on ec.Event_ID = te.Event_ID
join tlu_Contacts con on ec.Contact_ID = con.Contact_ID
join tbl_Observations obs on te.Event_ID = obs.Event_ID
join tlu_species spc on obs.Species_ID = spc.Species_ID
join xref_Species_Alternate_Names spc_alt on spc.Species_ID = spc_alt.Species_ID
; 

-- 40: Which island has the most sightings of the bird with the common name Pacific Kingfisher?
select top 1 island, count(*) as kingfisher_count
from tbl_locations tl
join tbl_transect tr on tr.Location_ID = tl.Location_ID
join tbl_stations st on st.Transect_ID = tr.Transect_ID
join tbl_events te on te.station_id = st.station_id
join xref_Event_Contacts ec on ec.Event_ID = te.Event_ID
join tlu_Contacts con on ec.Contact_ID = con.Contact_ID
join tbl_Observations obs on te.Event_ID = obs.Event_ID
join tlu_species spc on obs.Species_ID = spc.Species_ID
where common_name = 'Pacific Kingfisher'
group by island
order by kingfisher_count
;