-- 1: How many five year old turtles were measured?
SELECT COUNT (*) TURTLECOUNT
FROM `TFD_TRTLMSR`
WHERE `AG` = '5'
;

-- 2: How many turtles were measured at each location where turtles were measured?
SELECT `LID`, COUNT (*) TURTLECOUNT
FROM `TFD_TRTLMSR`
GROUP BY `LID`
;

-- 3: what is the average weight of all turtles?
SELECT AVG (`WT`) TURTLEWEIGHT
FROM `TFD_TRTLMSR`
;

-- 4: at which locations were both snakes and turtles measured?
SELECT DISTINCT `T`.`LID`
FROM `TFD_TRTLMSR` T
JOIN `TFDSC` S ON `T`.`LID` = `S`.`LID`
;

-- 5: How many minnow traps are there at each location?
SELECT `LID`, COUNT (DISTINCT `TR`) TRAPCOUNT
FROM `TFDMINTRAPSURVEYS`
GROUP BY `LID`
;

-- 6: show the total number of minnows counted at each location
SELECT `LID`, SUM (`CT`) MINNOWCOUNTSUM
FROM `TFDMINTRAPSURVEYS`
GROUP BY `LID`
;

-- 7: show the total number of minnows counted at each trap by location. Each location has multiple traps.
SELECT `LID`, `TR`, SUM (`CT`) MINNOWCOUNTSUM
FROM `TFDMINTRAPSURVEYS`
GROUP BY `LID`, `TR`
;

-- 8: show how many minnows of each stage were counted at the location ASIS_HERPS_20H
SELECT `SG`, SUM (`CT`) MINNOWCOUNTSUM
FROM `TFDMINTRAPSURVEYS`
WHERE `LID` = 'ASIS_HERPS_20H'
GROUP BY `SG`
;

-- 9: What is the average water temperature (celcius) at locations where amphibians were counted?
SELECT AVG (`TC`) AVGTEMP
FROM `FDWP`
WHERE `LID` IN (SELECT `LID`
FROM `FLDDATAAMPHCALLCNTS`)
;

-- 10: Show the average temperature, salinity, conductivity, and pH level of the water at locations corresponding to turtle observation records.
SELECT AVG (`TC`) AVGTEMPC, AVG (`SLT`) AVGSALINITY, AVG (`CNDCTY`) AVGCONDUCT, AVG (`PH`) AVGPH
FROM `FDWP` W, `FLDDATATTLTRPSRVYS` T
WHERE `W`.`RC_ID` IN (SELECT `RC_ID`
FROM `FLDDATATTLTRPSRVYS`)
;

-- 11: Make a list of turtle record IDs and measurement comments where the trap survey sex data did not match the measurement sex data.
SELECT `T`.`RC_ID`, `M`.`CMT`
FROM `FLDDATATTLTRPSRVYS` T
JOIN `TFD_TRTLMSR` M ON `T`.`RC_ID` = `M`.`RC_ID` AND `M`.`SX` <> `T`.`SX`
;

-- 12: show the heaviest turtle for each sex
SELECT `SX`, MAX (`WT`) HEAVIESTWEIGHT
FROM `TFD_TRTLMSR`
GROUP BY `SX`
;

-- 13: what is the highest snake snout-to-vent length recorded?
SELECT `SVL`
FROM `TFDSC`
ORDER BY `SVL` DESC LIMIT 1
;

-- 14: Show the average snake weight and snout-to-vent length by sex.
SELECT `SX`, AVG (`WT`) AVGWEIGHT, AVG (`SVL`) AVGSVL
FROM `TFDSC`
GROUP BY `SX`
;

-- 15: show the average snake total length and weight by species.
SELECT `SPC_C`, AVG (`TLN`) AVGTLENGTH, AVG (`WT`) AVGWEIGHT
FROM `TFDSC`
GROUP BY `SPC_C`
;

-- 16: Show a count of turtle measurements made by each agency.
SELECT `A/T`, COUNT (DISTINCT `RC_ID`)
FROM `TFD_TRTLMSR` T
JOIN `TLNKOBS` OL ON `T`.`EID` = `OL`.`EID`
JOIN `OBS_LU` O ON `O`.`OI` = `OL`.`OI`
GROUP BY `A/T`
;

-- 17: Make a list of all event IDs from 2004 that were observed by Allison Turner
SELECT `E`.`EID`
FROM `EVS` E
JOIN `TBLEVTDATAHRPS` ED ON `E`.`EID` = `ED`.`EID`
JOIN `TLNKOBS` OL ON `ED`.`EID` = `OL`.`EID`
JOIN `OBS_LU` O ON `OL`.`OI` = `O`.`OI`
WHERE `Y` = 2004 AND `FNAME` = 'allison' AND `LNAME` = 'turner'
;

-- 18: Which observers participated in events where measurements of turtle were made? Show their initials, and first and last names.
SELECT DISTINCT `O`.`OI`, `FNAME`, `LNAME`
FROM `TLNKOBS` OL
JOIN `OBS_LU` O ON `OL`.`OI` = `O`.`OI`
JOIN `TFD_TRTLMSR` TM ON `TM`.`EID` = `OL`.`EID`
;

-- 19: how many distinct species were documented on a reptile survey green card?
SELECT COUNT (DISTINCT `SPC_C`) SPECIESCOUNT
FROM `FDGCO`
;

-- 20: what are the Universal Transverse Mercator x and y coordinates for locations where time constrained searches were conducted? Include the location ID and x and y point coordinate averages in the result.
SELECT `L`.`LID`, AVG (`UTMX`) X, AVG (`UTMY`) Y
FROM `FDTS` DF
JOIN `LCTNPTS` L ON `DF`.`LID` = `L`.`LID`
GROUP BY `L`.`LID`
;

-- 21: show a count of minnow measurements by stage description
SELECT `DESC`, COUNT (*) MINNOWCOUNT
FROM `TS` S
JOIN `TFDMINTRAPSURVEYS` M ON `S`.`SG` = `M`.`SG`
GROUP BY `DESC`
;

-- 22: What is the ID and description of the occasional abundance category?
SELECT `ABDID`, `ABDTXT`
FROM `ABD_LU`
WHERE `ABD` = 'Occasional'
;

-- 23: What are the location IDs of locations that have covers made out of wood? Only include one row per location ID.
SELECT DISTINCT `LID`
FROM `FLDDTCVRBRD`
WHERE `T` = 'Wood'
;

-- 24: Show the board number and types for boards at site with ID 18CB1. Ignore boards with a number 0.
SELECT `BD`, `T`
FROM `FLDDTCVRBRD` CB
JOIN `LOCS` L ON `CB`.`LID` = `L`.`LID`
WHERE `SID` = '18CB1' AND `BD` <> 0
;

-- 25: Show the average air temperature on cloudy days that correspond to cover board  data where the board material is wood at the site with id 30CB2
SELECT AVG (`ATP`) AS AVGTEMP
FROM `FLDDTCVRBRD` CB
JOIN `TBLEVTDATAHRPS` EV ON `CB`.`EID` = `EV`.`EID`
JOIN `LOCS` L ON `CB`.`LID` = `L`.`LID`
WHERE `T` = 'Metal' AND `SID` = '30CB2' AND `WTH` = 'cloudy'
;

-- 26: For each behavior type, how many records were documented for snakes captured using the coverboard method?
SELECT `BHVR`, COUNT (*) AS RECORDCOUNT
FROM `TFDSC`
WHERE `CPMTHD` = 'coverboard'
GROUP BY `BHVR`
;

-- 27: what were the behaviors and capture methods of snakes where the record notes include the word rafters?
SELECT `BHVR`, `CPMTHD`
FROM `TFDSC`
WHERE `NT` LIKE '%rafters%'
;

-- 28: for location points associated with records relating to cover boards, at the site with id 18CB1, what are the point IDs, snake ids, board numbers, and UTM X and Y coordinates?
SELECT `PID`, `SNID`, `BD`, `UTMX`, `UTMY`
FROM `FLDDTCVRBRD` CB
JOIN `LOCS` L ON `CB`.`LID` = `L`.`LID`
JOIN `LCTNPTS` LP ON `L`.`LID` = `LP`.`LID`
WHERE `RCP` = 'new' AND `SID` = '18CB1'
;

-- 29: What are the initials of observers who logged events relating to cover board observations? Include only one row per initials.
SELECT DISTINCT `O`.`OI`
FROM `OBS_LU` O
JOIN `TLNKOBS` TLO ON `O`.`OI` = `TLO`.`OI`
JOIN `EVS` E ON `TLO`.`EID` = `E`.`EID`
JOIN `FLDDTCVRBRD` CB ON `E`.`EID` = `CB`.`EID`
;

-- 30: Show a count of events in the herpetological survey table, group the counts by weather condition. Also include the average air and water temperatures.
SELECT `WTH`, COUNT (*) EVENTCOUNT, AVG (`ATP`) AVGAIRTEMP, AVG (`WTTP`) AVGWATERTEMP
FROM `TBLEVTDATAHRPS`
GROUP BY `WTH`
;

-- 31: Show the average air temperature for herpetological surveys for each observer. Group them by the initials of the observer who logged the event.
SELECT `O`.`OI`, AVG (`ATP`) AVGAIRTEMP
FROM `OBS_LU` O
JOIN `TLNKOBS` TLO ON `O`.`OI` = `TLO`.`OI`
JOIN `TBLEVTDATAHRPS` E ON `TLO`.`EID` = `E`.`EID`
GROUP BY `O`.`OI`
;

-- 32: what is the average air temperature for each weather type for herpetological survey events?
SELECT `WTH`, AVG (`ATP`) AVGAIRTEMP
FROM `TBLEVTDATAHRPS`
GROUP BY `WTH`
;

-- 33: what is the description of project code WQ?
SELECT `DESC`
FROM `TLUPROJ`
WHERE `PJT` = 'WQ'
;

-- 34: What type of park is the park with code ASIS?
SELECT `P_TP`
FROM `TPC`
WHERE `P_CD` = 'ASIS'
;

-- 35: What does the evidence code DOR mean?
SELECT `TX`
FROM `TEC`
WHERE `EVCD` = 'DOR'
;

-- 36: Show the habitat names and descriptions of the 'Temporary Pond' and 'Permanent Pond' micro habitats.
SELECT `HBT`, `DESC`
FROM `TLUMH`
WHERE `HBT` IN ('Temporary Pond', 'Permanent Pond')
;

-- 37: How many records are logged for each turtle trap type?
SELECT `TT`, COUNT (*) RECORDCOUNT
FROM `FLDDATATTLTRPSRVYS`
GROUP BY `TT`
;

-- 38: Which location IDs have crab type turtle traps? Include only one row per location.
SELECT DISTINCT `T`.`LID`
FROM `LOCS` L
JOIN `FLDDATATTLTRPSRVYS` T ON `L`.`LID` = `T`.`LID`
WHERE `TT` = 'crab'
;

-- 39: What are the average turtle dimensions by sex? Include carapace length and width, plastron length and width, and weight.
SELECT `SX`, AVG (`CL`) AVGCARLEN, AVG (`CW`) AVGCARWID, AVG (`PLL`) AVGPLASLEN, AVG (`PW`) AVGPLASWID, AVG (`WT`) AVGWEIGHT
FROM `TFD_TRTLMSR`
GROUP BY `SX`
;

-- 40: how many turtle measurements were of turtles carrying eggs or young? This is indicated by the value 1.
SELECT COUNT (*) GRAVIDCOUNT
FROM `TFD_TRTLMSR`
WHERE `GVD` = 1
;

