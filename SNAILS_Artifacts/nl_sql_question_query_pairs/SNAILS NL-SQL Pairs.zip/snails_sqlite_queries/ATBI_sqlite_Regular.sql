-- 1: What tree species have been observed within nested subplots? Show the species code, genus, sub genus, and common name.
SELECT DISTINCT `COMMONNAME`, `SPECIES_CODE`, `GENUS`, `SUBGENUS`
FROM `TABLE_NESTS`
JOIN `PLANT_SPECIES_LOOKUP` ON `TABLE_NESTS`.`SPECIES_CODE` = `PLANT_SPECIES_LOOKUP`.`SPECIESCODE`
ORDER BY `COMMONNAME`
;

-- 2: Are there any tree species that have not been observed within nested subplots? What are their common names?
SELECT DISTINCT `COMMONNAME`
FROM `PLANT_SPECIES_LOOKUP`
WHERE `SPECIESCODE` NOT IN (SELECT DISTINCT `SPECIES_CODE`
FROM `TABLE_NESTS`)
;

-- 3: What are the five most common geni observed in nested subplots and how many nested subplotes have they been observed in?
SELECT `GENUS`, COUNT (*) AS NESTCOUNT
FROM `PLANT_SPECIES_LOOKUP`
JOIN `TABLE_NESTS` ON `PLANT_SPECIES_LOOKUP`.`SPECIESCODE` = `TABLE_NESTS`.`SPECIES_CODE`
GROUP BY `GENUS`
ORDER BY `NESTCOUNT` DESC LIMIT 5
;

-- 4: Show me the different decay stages and their descriptions
SELECT *
FROM `DECAYSTAGE_LOOKUP`
;

-- 5: How many events observed at least some stage of decay?
SELECT COUNT (DISTINCT `EVENT_ID`)
FROM `TABLE_DEADWOOD`
;

-- 6: How many different decayed logs were found in each event where decay was observed?
SELECT `EVENT_ID`, COUNT (*)
FROM `TABLE_DEADWOOD`
GROUP BY `EVENT_ID`
;

-- 7: For the event that observed the most decayed logs, how many of each stage of decay were observed? Show the description of each decay stage in the result.
SELECT `DECAY_STAGE_DESCRIPTION`, COUNT (*) AS NUMLOGS
FROM `TABLE_DEADWOOD`
JOIN `DECAYSTAGE_LOOKUP` ON `TABLE_DEADWOOD`.`DECAY` = `DECAYSTAGE_LOOKUP`.`DECAYSTAGE_ID`
WHERE `EVENT_ID` IN (SELECT `EVENT_ID`
FROM `TABLE_DEADWOOD`
GROUP BY `EVENT_ID`
ORDER BY COUNT (*) DESC LIMIT 1)
GROUP BY `DECAY_STAGE_DESCRIPTION`
;

-- 8: Show me the events where both nested subplots and decayed logs were observed. Include the number of decayed logs, and the number of nested subplots were observed.
SELECT `E`.`EVENT_ID`, `DEADWOOD_COUNT`, `NEST_COUNT`
FROM `TABLE_EVENTS` AS E
JOIN (SELECT `EVENT_ID`, COUNT (*) AS DEADWOOD_COUNT
FROM `TABLE_DEADWOOD`
GROUP BY `EVENT_ID`) AS DW ON `E`.`EVENT_ID` = `DW`.`EVENT_ID`
JOIN (SELECT `EVENT_ID`, COUNT (*) AS NEST_COUNT
FROM `TABLE_NESTS`
GROUP BY `EVENT_ID`) AS NE ON `E`.`EVENT_ID` = `NE`.`EVENT_ID`
ORDER BY `DEADWOOD_COUNT` DESC
;

-- 9: Get the Plot ID, x and y coordinates, and directions for the location with the event that has the most nested subplot observations
SELECT `PLOT_ID`, `X_COORDINATE`, `Y_COORDINATE`, `DIRECTIONS`
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_EVENTS` E ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE `E`.`EVENT_ID` IN (SELECT `EVENT_ID`
FROM `TABLE_NESTS`
GROUP BY `EVENT_ID`
ORDER BY COUNT (*) LIMIT 1)
;

-- 10: What is the average diameter at breast height for  trees of the Acer genus?
SELECT AVG (`DIAMETER_BREAST_HEIGHT`) AVGDBH
FROM `TABLE_OVERSTORY` O
JOIN `PLANT_SPECIES_LOOKUP` P ON `O`.`SPECIES_CODE` = `P`.`SPECIESCODE`
WHERE `GENUS` = 'Acer'
;

-- 11: What is the canopy position name and the count of trees for each canopy position
SELECT `CANOPY_POSITION_NAME`, COUNT (*) AS TREECOUNT
FROM `CANPOY_POSITION_LOOKUP` P
JOIN `TABLE_OVERSTORY` O ON `P`.`CANOPYPOSITIONNUMBER` = `O`.`CANOPY_POSITION`
GROUP BY `CANOPY_POSITION_NAME`
;

-- 12: Create a list of trees where their condition is 'down'. Include the tree tag number, and species common name.
SELECT `COMMONNAME`, `TREETAG`
FROM `PLANT_SPECIES_LOOKUP` S
JOIN `TABLE_OVERSTORY` O ON `S`.`SPECIESCODE` = `O`.`SPECIES_CODE`
JOIN `TREE_CONDITION_LOOKUP` C ON `O`.`TREE_CONDITION` = `C`.`TREE_CONDITION_IDENTIFIER`
WHERE `TREE_CONDITION_DESCRIPTION` = 'down'
;

-- 13: Get a count of saplings entries for each species code for species with more than 20 saplings entries
SELECT `SPECIES_CODE`, COUNT (*) AS SAPLINGCOUNT
FROM `TABLE_SAPLINGS`
GROUP BY `SPECIES_CODE`
HAVING COUNT (*) > 20
;

-- 14: How many saplings records are there that have an entry higher than 10 in the diameter class 3 field?
SELECT COUNT (*) AS SAPLINGCOUNT
FROM `TABLE_SAPLINGS`
WHERE `DIAMETER_CLASS3` > 10
;

-- 15: What is the highest seedling density for each species code?
SELECT `SPECIES_CODE`, MAX (`DENSITY`) SEEDLINGDENSITY
FROM `TABLE_SEEDLINGS`
GROUP BY `SPECIES_CODE`
;

-- 16: How many events recorded seedling density data?
SELECT COUNT (DISTINCT `EVENT_ID`) EVENTCOUNT
FROM `TABLE_SEEDLINGS`
;

-- 17: What are the directions to the plot where the tree with tag number 6 is located?
SELECT `DIRECTIONS`
FROM `TABLE_TREE_TAGS` T
JOIN `TABLE_LOCATIONS` L ON `T`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE `TREE_TAG_IDENTIFIER` = 6
;

-- 18: Show the description and location notes for locations higher than 4000 feet in elevation
SELECT `SITEDESCRIPTION`, `LOCATION_NOTES`
FROM `TABLE_LOCATIONS`
WHERE `ELEVATION` > 4000
;

-- 19: For each event ID, show the count of nested sub plots for each cover class text description.
SELECT `EVENT_ID`, `COVERCLASS_TEXT`, COUNT (*) NESTCOUNT
FROM `COVER_CLASS_LOOKUP` CC
JOIN `TABLE_NESTS` N ON `CC`.`COVER_CLASS_NUMBER` = `N`.`COVER`
GROUP BY `EVENT_ID`, `COVERCLASS_TEXT`
;

-- 20: Show the azimuth and distance from the witness tree stake to the tree for trees with a diameter at breast height of less than 30
SELECT `WITNESS_AZIMUTH`, `WITNESS_STAKE`
FROM `TABLE_WITNESSTREES`
WHERE `DIAMETER_BREAST_HEIGHT_WITNESS_TREE` < 30
;

-- 21: For each genus and species, get the total number of witness trees observed.
SELECT `GENUS`, `SPECIES`, COUNT (*) TREECOUNT
FROM `PLANT_SPECIES_LOOKUP` S
JOIN `TABLE_WITNESSTREES` W ON `S`.`SPECIESCODE` = `W`.`WITNESS_SPECIES_CODE`
GROUP BY `GENUS`, `SPECIES`
;

-- 22: What are the listed and valid names of the trail adjacent to the location associated with event id 2?
SELECT `LISTEDNAME`, `VALIDNAME`
FROM `ROADS_AND_TRAILS_LOOKUP` RT
JOIN `TABLE_LOCATIONS` L ON `L`.`TRAIL` = `RT`.`LISTEDNAME`
JOIN `TABLE_EVENTS` E ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE `E`.`EVENT_ID` = 2
;

-- 23: Show a count of tree tags by state and county.
SELECT `STATE`, `COUNTY`, COUNT (*) TAGCOUNT
FROM `PLACE_NAMES_LOOKUP` PN
JOIN `TABLE_LOCATIONS` L ON `PN`.`IDENTIFIER` = `L`.`PLACENAMEID`
JOIN `TABLE_TREE_TAGS` TG ON `L`.`LOCATION_ID` = `TG`.`LOCATION_ID`
GROUP BY `STATE`, `COUNTY`
;

-- 24: What are the East and North Universal Transverse Mercator coordinates for the locations in Blount county? Include the location name.
SELECT `NAME`, `UNIVERSAL_TRANSVERSE_MERCATOR_EASTING_COORDINATE`, `UNIVERSAL_TRANSVERSE_MERCATOR_NORTHING_COORDINATE`
FROM `PLACE_NAMES_LOOKUP`
WHERE `COUNTY` = 'Blount'
;

-- 25: Show the topographic position description from the topographic position lookup table for the location with X coordinate 269647 and Y coordinate 3943851
SELECT `T`.`TOPOGRAPHICAL_POSITION`
FROM `TOPOGRAPHIC_POSITION_LOOKUP` T
JOIN `TABLE_LOCATIONS` L ON `L`.`TOPOGRAPHIC_POSITION` = `T`.`IDENTIFIER`
WHERE `X_COORDINATE` = 269647 AND `Y_COORDINATE` = 3943851
;

-- 26: what is the condition number for the 'Dead' condition text entry?
SELECT `CONDITION_NUMBER`
FROM `LIVE_DEAD_LOOKUP`
WHERE `CONDITION_TEXT` = 'Dead'
;

-- 27: What is the text entry for presence number 3?
SELECT `PRESENCE_DESCRIPTION`
FROM `PRESENCE_LOOKUP`
WHERE `PRESENCE_NUMBER` = 3
;

-- 28: What is the default datum for this project?
SELECT `DATUM`
FROM `APPLICATION_TABLE`
;

-- 29: Make a list of genus, species, and common name, for overstory (trees) in Swain county. Include only one row per distinct combination.
SELECT DISTINCT `GENUS`, `SPECIES`, `COMMONNAME`
FROM `PLANT_SPECIES_LOOKUP` SP
JOIN `TABLE_OVERSTORY` OS ON `SP`.`SPECIESCODE` = `OS`.`SPECIES_CODE`
JOIN `TABLE_TREE_TAGS` TT ON `TT`.`TREE_TAG_IDENTIFIER` = `OS`.`TREETAG`
JOIN `TABLE_LOCATIONS` L ON `L`.`LOCATION_ID` = `TT`.`LOCATION_ID`
JOIN `PLACE_NAMES_LOOKUP` PN ON `PN`.`IDENTIFIER` = `L`.`PLACENAMEID`
WHERE `COUNTY` = 'Swain'
;

-- 30: Which tree species were recorded as mature overstory but not as saplings? Include the species name and common name.
SELECT `SPECIES`, `COMMONNAME`
FROM `PLANT_SPECIES_LOOKUP` SP
WHERE EXISTS (SELECT `OVERSTORY_ID`
FROM `TABLE_OVERSTORY`
WHERE `SPECIES_CODE` = `SP`.`SPECIESCODE`) AND NOT EXISTS (SELECT `SEEDLINGS_ID`
FROM `TABLE_SEEDLINGS`
WHERE `SPECIES_CODE` = `SP`.`SPECIESCODE`)
;

-- 31: What are the x an y coordinates for the tree with tag 652?
SELECT `XCOORDINATE`, `YCOORDINATE`
FROM `TABLE_TREE_TAGS`
WHERE `TAG` = 652
;

-- 32: For each cover class text description, how many nested subplots records are there?
SELECT `COVERCLASS_TEXT`, COUNT (*) NESTEDSUBPLOTCOUNT
FROM `TABLE_NESTS` N
JOIN `COVER_CLASS_LOOKUP` R2 ON `N`.`COVER_CLASS_R2` = `R2`.`COVER_CLASS_NUMBER`
GROUP BY `COVERCLASS_TEXT`
;

-- 33: For each presence class text description, how many nested subplots records are there where the presence class is the presence class of species in the firsted nested corner within a module?
SELECT `PRESENCE_DESCRIPTION`, COUNT (*) NESTEDSUBPLOTCOUNT
FROM `TABLE_NESTS` N
JOIN `PRESENCE_LOOKUP` P ON `N`.`PRESENCE_FIRST` = `P`.`PRESENCE_NUMBER`
GROUP BY `PRESENCE_DESCRIPTION`
;

-- 34: What is the highest midpoint diameter (in meters) for each type of deadwood decay?
SELECT `DECAY`, MAX (`MIDPOINT_DIAMETER`) MAXMPD
FROM `TABLE_DEADWOOD`
GROUP BY `DECAY`
;

-- 35: What is the longest length for each type of deadwood decay?
SELECT `DECAY`, MAX (`LENGTH`) MAXLENGTH
FROM `TABLE_DEADWOOD`
GROUP BY `DECAY`
;

-- 36: What is the decay stage description for the decay stage associated with the lowest recorded midpoint diameter (in meters)?
SELECT `DECAY_STAGE_DESCRIPTION`
FROM `DECAYSTAGE_LOOKUP` DS
WHERE `DS`.`DECAYSTAGE_ID` IN (SELECT `DECAY`
FROM `TABLE_DEADWOOD`
ORDER BY `MIDPOINT_DIAMETER` ASC LIMIT 1)
;

-- 37: What is the decay stage description for the decay stage associated with the shortest recorded length?
SELECT `DECAY_STAGE_DESCRIPTION`
FROM `DECAYSTAGE_LOOKUP` DS
WHERE `DS`.`DECAYSTAGE_ID` IN (SELECT `DECAY`
FROM `TABLE_DEADWOOD`
ORDER BY `LENGTH` ASC LIMIT 1)
;

-- 38: Show the site description, slope, aspect, location notes, and accuracy notes, for locations with a convex slope shape.
SELECT `SITEDESCRIPTION`, `SLOPE`, `ASPECT`, `LOCATION_NOTES`, `ACCURACY_NOTES`
FROM `TABLE_LOCATIONS`
WHERE `SLOPE_SHAPE` = 'convex'
;

-- 39: What is the quad name for the location with a topographic position of 7?
SELECT `QUADRANT_NAME`
FROM `TABLE_LOCATIONS`
WHERE `TOPOGRAPHIC_POSITION` = 7
;

-- 40: For each tree condition text description, show a count of the number of sapling records.
SELECT `TREE_CONDITION_DESCRIPTION`, COUNT (*) SAPLINGCOUNT
FROM `TABLE_SAPLINGS` S
JOIN `TREE_CONDITION_LOOKUP` C ON `S`.`CONDITION` = `C`.`TREE_CONDITION_IDENTIFIER`
GROUP BY `TREE_CONDITION_DESCRIPTION`
;

