-- 1: Show the notes for gray wolf observations with Bureau of Land Management (BLM) ownership
SELECT `NTS`
FROM `VRTS`
WHERE `OWN` = 'BLM' AND `C_NM` LIKE 'gray wolf'
;

-- 2: How many vertebrates were observed by either Stefanic or Dennis Hauser?
SELECT COUNT (*) OBSCOUNT
FROM `VRTS`
WHERE `OBSR` LIKE 'Stefanic' OR `OBSR` LIKE 'Dennis Hauser'
;

-- 3: For each breeding code, show the breeding code definition and count of vertebrate observations for observations of the species with the Common_Name 'mule deer'.
SELECT `DEF`, COUNT (*) DEERCOUNT
FROM `BDCDS` BC
JOIN `VRTS` V ON `BC`.`BD` = `V`.`BD`
WHERE `C_NM` = 'mule deer'
GROUP BY `DEF`
;

-- 4: Show the Common_Name and genus species for all invertebrates of class Arachnida
SELECT `C_NM`, `G_SP`
FROM `INV`
WHERE `CLS` LIKE 'arachnida'
;

-- 5: Show all of the family values in the invertebrates table that are not in the invertebrates family table. Exclude null values and include only one entry per type.
SELECT DISTINCT `FAM`
FROM `INV` I
WHERE NOT EXISTS (SELECT `INVFAM`
FROM `INVFAM`
WHERE `INVFAM` = `I`.`FAM`) AND `FAM` IS NOT NULL
;

-- 6: Which species were documented as road kill at highway mile marker 235? Include only one entry per species type.
SELECT DISTINCT `SP`
FROM `RKL`
WHERE `HMM` = '235'
;

-- 7: How many roadkill observations were made for each month in 2014?
SELECT `MTH`, COUNT (*) ROADKILLCOUNT
FROM `RKL`
WHERE `YR` = 2014
GROUP BY `MTH`
;

-- 8: Show the comments for roadkill entries made before 1990
SELECT `CMTS`
FROM `RKL`
WHERE `YR` < 1990
;

-- 9: How many mule deer were counted as road kill in 2015?
SELECT COUNT (*) DEERCOUNT
FROM `RKL`
WHERE `SP` LIKE 'mule deer' AND `YR` = 2015
;

-- 10: How many roadkill records have a date that is identical to at least on vertebrate record?
SELECT COUNT (*) RECORDCOUNT
FROM `RKL` R
WHERE EXISTS (SELECT *
FROM `VRTS`
WHERE `R`.`DT` = `DT`)
;

-- 11: What is the species, year and month of the roadkill observation with the highest number killed documented?
SELECT `SP`, `YR`, `MTH`
FROM `RKL`
ORDER BY `N_KLD` DESC LIMIT 1
;

-- 12: For each habitat definition, show the count of vertebrates and the count of invertebrates records
SELECT `DEF`, `VERTHABCOUNT`, `INVERTHABCOUNT`
FROM `HBC` H
JOIN (SELECT `HBT`, COUNT (*) VERTHABCOUNT
FROM `VRTS`
GROUP BY `HBT`) V ON `V`.`HBT` = `H`.`CD`
JOIN (SELECT `HBT`, COUNT (*) INVERTHABCOUNT
FROM `INV`
GROUP BY `HBT`) I ON `I`.`HBT` = `H`.`CD`
;

-- 13: Show the definition of habitats that have more than 40 invertebrate records.
SELECT `DEF`
FROM `HBC`
WHERE `CD` IN (SELECT `HBT`
FROM `INV`
GROUP BY `HBT`
HAVING COUNT (*) > 40)
;

-- 14: Which invertebrate records were recorded on the same day, at the same habitat, as at least one vertebrate record? Include the date, observer, and species Common_Name from the invertebrate entry.
SELECT `DT`, `OBSR`, `C_NM`
FROM `INV` I
WHERE EXISTS (SELECT *
FROM `VRTS`
WHERE `I`.`DT` = `DT` AND `I`.`HBT` = `HBT`)
;

-- 15: For vertebrate and invertebrate observations recorded at the same habitat on the same day, show the observer recorded on the invertebrate record as well as the observer recorded on the vertebrate record. Also include the date, and the habitat definition.
SELECT `I`.`OBSR`, `V`.`OBSR`, `I`.`DT`, `DEF`
FROM `HBC` H
JOIN `INV` I ON `I`.`HBT` = `H`.`CD`
JOIN `VRTS` V ON `V`.`DT` = `I`.`DT` AND `V`.`HBT` = `I`.`HBT`
;

-- 16: Display the observation type and a count of invertebrate records for each observation type
SELECT `OT`, COUNT (*) OBSCOUNT
FROM `INV`
GROUP BY `OT`
;

-- 17: Show all the different locations where the Invertebrate species Trichodes ornatus has been observed
SELECT `LOC`
FROM `INV`
WHERE `G_SP` LIKE 'Trichodes ornatus'
;

-- 18: Which observers have either only observed Invertebrates, or only observed Vertebrates, but not both?
SELECT DISTINCT `OBSR`
FROM `INV` EXCEPT SELECT DISTINCT `OBSR`
FROM `VRTS`
;

-- 19: What are the Universal Transverse Mercator north and east coordinates for the records documenting the invertebrate with the Common_Name 'western white'?
SELECT `UTMN`, `UTME`
FROM `INV`
WHERE `C_NM` LIKE 'western white'
;

-- 20: What are the common and scientific names of vertebrates observed at the coordinates Universal Transverse Mercator North = 4814897 and Universal Transverse Mercator East = 291766
SELECT `C_NM`, `SCI_NM`
FROM `VRTS`
WHERE `UTMN` = 4814897 AND `UTME` = 291766
;

-- 21: Which roadkill species are not included in the Common_Name field of the invertebrates table? Include only one entry per value.
SELECT DISTINCT `SP`
FROM `RKL`
WHERE `SP` NOT IN (SELECT `C_NM`
FROM `VRTS`)
;

-- 22: What is the highest number of invertebrates  recorded in an observation for each family? Do not include NULL values in the number column.
SELECT `FAM`, MAX (`NBR`) MAXNUM
FROM `INV`
WHERE `NBR` IS NOT NULL
GROUP BY `FAM`
;

-- 23: How many paste are there where the species is 'deer'?
SELECT COUNT (*) ERRORCOUNT
FROM `P_ERR`
WHERE `SP` LIKE 'deer'
;

-- 24: Show the orders for invertebrates in the Insecta class. Only include one row per value.
SELECT DISTINCT `ORD`
FROM `INV`
WHERE `CLS` LIKE 'Insecta'
;

-- 25: Get a count of invertebrate observations made at the Hot springs location for each observation type
SELECT `OT`, COUNT (*) OBSCOUNT
FROM `INV`
WHERE `LOC` LIKE 'Hot springs'
GROUP BY `OT`
;

-- 26: For each survey category of vertebrate records, show a count of observations made by the observer stefanic
SELECT `SVY`, COUNT (*) STEFCOUNT
FROM `VRTS`
WHERE `OBSR` LIKE 'stefanic'
GROUP BY `SVY`
;

-- 27: What is the scientific name of the mammal commonly known as the moose? Only include one row in the response
SELECT `SCI_NM`
FROM `WMLST`
WHERE `C_NM` LIKE 'moose'
;

-- 28: Get a count of big game roadkill for each location. The value for big game is 'yes'.
SELECT `LOC`, COUNT (*) GAMECOUNT
FROM `RKL`
WHERE `BG` LIKE 'yes'
GROUP BY `LOC`
;

-- 29: How many vertebrate observations were made of the Mammal class?
SELECT COUNT (*) MAMMALCOUNT
FROM `VRTS` V
JOIN `CLS` C ON `C`.`CLS` = `V`.`CLS`
WHERE `F2` = 'Mammal'
;

-- 30: Show the species, Common_Name, scientific name, habitat definition, observer, and number observed for all vertebrates observed in numbers greater than 100
SELECT `SP`, `C_NM`, `SCI_NM`, `DEF`, `NBR`
FROM `VRTS` V
JOIN `HBC` H ON `V`.`HBT` = `H`.`CD`
WHERE `NBR` > 100
;

-- 31: List all scientific names in the wildlife master list that do not appear in the vertebrates table
SELECT `SCI_NM`
FROM `WMLST`
WHERE `SCI_NM` NOT IN (SELECT `SCI_NM`
FROM `VRTS`)
;

-- 32: List all Common_Names in the wildlife master list that do not appear in the invertebrates table
SELECT `C_NM`
FROM `WMLST` ML
WHERE NOT EXISTS (SELECT *
FROM `INV`
WHERE `ML`.`C_NM` = `C_NM`)
;

-- 33: Show the species of roadkill that were observed in 2014 but not in 2015. Include only one entry per species type.
SELECT DISTINCT `SP`
FROM `RKL` R
WHERE `YR` = 2014 AND NOT EXISTS (SELECT `SP`
FROM `RKL`
WHERE `YR` = 2015 AND `R`.`SP` = `SP`)
;

-- 34: While highway marker had the most roadkill observations in 2021?
SELECT `HMM`
FROM `RKL`
WHERE `YR` = 2021
GROUP BY `HMM`
ORDER BY COUNT (`LOC`) DESC LIMIT 1
;

-- 35: For each vertebrate observation type, show how many observations the observer named Buckley made
SELECT `OT`, COUNT (*) OBSCOUNT
FROM `VRTS`
WHERE `OBSR` = 'Buckley'
GROUP BY `OT`
;

-- 36: Show the observation notes entered by observer stefanic for observations of vertebrates with the Common_Name dusky flycatcher
SELECT `NTS`
FROM `VRTS`
WHERE `OBSR` LIKE 'stefanic' AND `C_NM` LIKE 'dusky flycatcher'
;

-- 37: Show all of the invertebrates' Common_Names, genus species, class, family, and order that were observed at the location Arco Tunnel
SELECT `C_NM`, `G_SP`, `CLS`, `FAM`, `ORD`
FROM `INV`
WHERE `LOC` LIKE 'Arco Tunnel'
;

-- 38: For each location that isn't listed as 'unknown', show the count of invertebrates observed at that location by the observer named Munts
SELECT `LOC`, COUNT (*) OBSCOUNT
FROM `INV`
WHERE `LOC` NOT LIKE 'unknown' AND `OBSR` LIKE 'Munts'
GROUP BY `LOC`
;

-- 39: What are the common invertebrate names for invertebrates that were observed in the same habitat that the northern mockingbird was observed in?
SELECT `C_NM`
FROM `INV` I
WHERE `HBT` IN (SELECT `HBT`
FROM `VRTS`
WHERE `C_NM` LIKE 'Northern mockingbird')
;

-- 40: how many habitat codes are there?
SELECT COUNT (*) CODECOUNT
FROM `HBC`
;

