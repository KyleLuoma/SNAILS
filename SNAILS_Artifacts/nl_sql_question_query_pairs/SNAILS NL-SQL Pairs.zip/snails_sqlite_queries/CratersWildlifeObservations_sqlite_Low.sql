-- 1: Show the notes for gray wolf observations with Bureau of Land Management (BLM) ownership
SELECT `NOTS`
FROM `VRTBRTS`
WHERE `OWNRSHP` = 'BLM' AND `CMN_NAME` LIKE 'gray wolf'
;

-- 2: How many vertebrates were observed by either Stefanic or Dennis Hauser?
SELECT COUNT (*) OBSCOUNT
FROM `VRTBRTS`
WHERE `OBSRVR` LIKE 'Stefanic' OR `OBSRVR` LIKE 'Dennis Hauser'
;

-- 3: For each breeding code, show the breeding code definition and count of vertebrate observations for observations of the species with the Common_Name 'mule deer'.
SELECT `DEFN`, COUNT (*) DEERCOUNT
FROM `BRDNG_CDS` BC
JOIN `VRTBRTS` V ON `BC`.`BRD` = `V`.`BRD`
WHERE `CMN_NAME` = 'mule deer'
GROUP BY `DEFN`
;

-- 4: Show the Common_Name and genus species for all invertebrates of class Arachnida
SELECT `CMN_NAME`, `GNS_SPCS`
FROM `INVTS`
WHERE `CLS` LIKE 'arachnida'
;

-- 5: Show all of the family values in the invertebrates table that are not in the invertebrates family table. Exclude null values and include only one entry per type.
SELECT DISTINCT `FAMLY`
FROM `INVTS` I
WHERE NOT EXISTS (SELECT `INVERT_FAMILY`
FROM `INVERT_FAMILY`
WHERE `INVERT_FAMILY` = `I`.`FAMLY`) AND `FAMLY` IS NOT NULL
;

-- 6: Which species were documented as road kill at highway mile marker 235? Include only one entry per species type.
SELECT DISTINCT `SPECS`
FROM `RDKILL`
WHERE `HWY_MILE_MARKER` = '235'
;

-- 7: How many roadkill observations were made for each month in 2014?
SELECT `MNTH`, COUNT (*) ROADKILLCOUNT
FROM `RDKILL`
WHERE `YR` = 2014
GROUP BY `MNTH`
;

-- 8: Show the comments for roadkill entries made before 1990
SELECT `COMMTS`
FROM `RDKILL`
WHERE `YR` < 1990
;

-- 9: How many mule deer were counted as road kill in 2015?
SELECT COUNT (*) DEERCOUNT
FROM `RDKILL`
WHERE `SPECS` LIKE 'mule deer' AND `YR` = 2015
;

-- 10: How many roadkill records have a date that is identical to at least on vertebrate record?
SELECT COUNT (*) RECORDCOUNT
FROM `RDKILL` R
WHERE EXISTS (SELECT *
FROM `VRTBRTS`
WHERE `R`.`DT` = `DT`)
;

-- 11: What is the species, year and month of the roadkill observation with the highest number killed documented?
SELECT `SPECS`, `YR`, `MNTH`
FROM `RDKILL`
ORDER BY `NUM_KILLED` DESC LIMIT 1
;

-- 12: For each habitat definition, show the count of vertebrates and the count of invertebrates records
SELECT `DEFN`, `VERTHABCOUNT`, `INVERTHABCOUNT`
FROM `HBT_CD` H
JOIN (SELECT `HBTAT`, COUNT (*) VERTHABCOUNT
FROM `VRTBRTS`
GROUP BY `HBTAT`) V ON `V`.`HBTAT` = `H`.`CD`
JOIN (SELECT `HBTAT`, COUNT (*) INVERTHABCOUNT
FROM `INVTS`
GROUP BY `HBTAT`) I ON `I`.`HBTAT` = `H`.`CD`
;

-- 13: Show the definition of habitats that have more than 40 invertebrate records.
SELECT `DEFN`
FROM `HBT_CD`
WHERE `CD` IN (SELECT `HBTAT`
FROM `INVTS`
GROUP BY `HBTAT`
HAVING COUNT (*) > 40)
;

-- 14: Which invertebrate records were recorded on the same day, at the same habitat, as at least one vertebrate record? Include the date, observer, and species Common_Name from the invertebrate entry.
SELECT `DT`, `OBSRVR`, `CMN_NAME`
FROM `INVTS` I
WHERE EXISTS (SELECT *
FROM `VRTBRTS`
WHERE `I`.`DT` = `DT` AND `I`.`HBTAT` = `HBTAT`)
;

-- 15: For vertebrate and invertebrate observations recorded at the same habitat on the same day, show the observer recorded on the invertebrate record as well as the observer recorded on the vertebrate record. Also include the date, and the habitat definition.
SELECT `I`.`OBSRVR`, `V`.`OBSRVR`, `I`.`DT`, `DEFN`
FROM `HBT_CD` H
JOIN `INVTS` I ON `I`.`HBTAT` = `H`.`CD`
JOIN `VRTBRTS` V ON `V`.`DT` = `I`.`DT` AND `V`.`HBTAT` = `I`.`HBTAT`
;

-- 16: Display the observation type and a count of invertebrate records for each observation type
SELECT `OBS_TYPE`, COUNT (*) OBSCOUNT
FROM `INVTS`
GROUP BY `OBS_TYPE`
;

-- 17: Show all the different locations where the Invertebrate species Trichodes ornatus has been observed
SELECT `LCTN`
FROM `INVTS`
WHERE `GNS_SPCS` LIKE 'Trichodes ornatus'
;

-- 18: Which observers have either only observed Invertebrates, or only observed Vertebrates, but not both?
SELECT DISTINCT `OBSRVR`
FROM `INVTS` EXCEPT SELECT DISTINCT `OBSRVR`
FROM `VRTBRTS`
;

-- 19: What are the Universal Transverse Mercator north and east coordinates for the records documenting the invertebrate with the Common_Name 'western white'?
SELECT `UNIVTRANSMERCNRTH`, `UNIVTRANSMERCEAST`
FROM `INVTS`
WHERE `CMN_NAME` LIKE 'western white'
;

-- 20: What are the common and scientific names of vertebrates observed at the coordinates Universal Transverse Mercator North = 4814897 and Universal Transverse Mercator East = 291766
SELECT `CMN_NAME`, `SCI_NAME`
FROM `VRTBRTS`
WHERE `UNIVTRANSMERCNRTH` = 4814897 AND `UNIVTRANSMERCEAST` = 291766
;

-- 21: Which roadkill species are not included in the Common_Name field of the invertebrates table? Include only one entry per value.
SELECT DISTINCT `SPECS`
FROM `RDKILL`
WHERE `SPECS` NOT IN (SELECT `CMN_NAME`
FROM `VRTBRTS`)
;

-- 22: What is the highest number of invertebrates  recorded in an observation for each family? Do not include NULL values in the number column.
SELECT `FAMLY`, MAX (`NUMB`) MAXNUM
FROM `INVTS`
WHERE `NUMB` IS NOT NULL
GROUP BY `FAMLY`
;

-- 23: How many paste are there where the species is 'deer'?
SELECT COUNT (*) ERRORCOUNT
FROM `PST_ERRS`
WHERE `SPECS` LIKE 'deer'
;

-- 24: Show the orders for invertebrates in the Insecta class. Only include one row per value.
SELECT DISTINCT `ORD`
FROM `INVTS`
WHERE `CLS` LIKE 'Insecta'
;

-- 25: Get a count of invertebrate observations made at the Hot springs location for each observation type
SELECT `OBS_TYPE`, COUNT (*) OBSCOUNT
FROM `INVTS`
WHERE `LCTN` LIKE 'Hot springs'
GROUP BY `OBS_TYPE`
;

-- 26: For each survey category of vertebrate records, show a count of observations made by the observer stefanic
SELECT `SRVY`, COUNT (*) STEFCOUNT
FROM `VRTBRTS`
WHERE `OBSRVR` LIKE 'stefanic'
GROUP BY `SRVY`
;

-- 27: What is the scientific name of the mammal commonly known as the moose? Only include one row in the response
SELECT `SCI_NAME`
FROM `WLDLF_MSTRLST`
WHERE `CMN_NAME` LIKE 'moose'
;

-- 28: Get a count of big game roadkill for each location. The value for big game is 'yes'.
SELECT `LCTN`, COUNT (*) GAMECOUNT
FROM `RDKILL`
WHERE `BGAME` LIKE 'yes'
GROUP BY `LCTN`
;

-- 29: How many vertebrate observations were made of the Mammal class?
SELECT COUNT (*) MAMMALCOUNT
FROM `VRTBRTS` V
JOIN `CLS` C ON `C`.`CLS` = `V`.`CLS`
WHERE `FIELD2` = 'Mammal'
;

-- 30: Show the species, Common_Name, scientific name, habitat definition, observer, and number observed for all vertebrates observed in numbers greater than 100
SELECT `SPECS`, `CMN_NAME`, `SCI_NAME`, `DEFN`, `NUMB`
FROM `VRTBRTS` V
JOIN `HBT_CD` H ON `V`.`HBTAT` = `H`.`CD`
WHERE `NUMB` > 100
;

-- 31: List all scientific names in the wildlife master list that do not appear in the vertebrates table
SELECT `SCI_NAME`
FROM `WLDLF_MSTRLST`
WHERE `SCI_NAME` NOT IN (SELECT `SCI_NAME`
FROM `VRTBRTS`)
;

-- 32: List all Common_Names in the wildlife master list that do not appear in the invertebrates table
SELECT `CMN_NAME`
FROM `WLDLF_MSTRLST` ML
WHERE NOT EXISTS (SELECT *
FROM `INVTS`
WHERE `ML`.`CMN_NAME` = `CMN_NAME`)
;

-- 33: Show the species of roadkill that were observed in 2014 but not in 2015. Include only one entry per species type.
SELECT DISTINCT `SPECS`
FROM `RDKILL` R
WHERE `YR` = 2014 AND NOT EXISTS (SELECT `SPECS`
FROM `RDKILL`
WHERE `YR` = 2015 AND `R`.`SPECS` = `SPECS`)
;

-- 34: While highway marker had the most roadkill observations in 2021?
SELECT `HWY_MILE_MARKER`
FROM `RDKILL`
WHERE `YR` = 2021
GROUP BY `HWY_MILE_MARKER`
ORDER BY COUNT (`LCTN`) DESC LIMIT 1
;

-- 35: For each vertebrate observation type, show how many observations the observer named Buckley made
SELECT `OBS_TYPE`, COUNT (*) OBSCOUNT
FROM `VRTBRTS`
WHERE `OBSRVR` = 'Buckley'
GROUP BY `OBS_TYPE`
;

-- 36: Show the observation notes entered by observer stefanic for observations of vertebrates with the Common_Name dusky flycatcher
SELECT `NOTS`
FROM `VRTBRTS`
WHERE `OBSRVR` LIKE 'stefanic' AND `CMN_NAME` LIKE 'dusky flycatcher'
;

-- 37: Show all of the invertebrates' Common_Names, genus species, class, family, and order that were observed at the location Arco Tunnel
SELECT `CMN_NAME`, `GNS_SPCS`, `CLS`, `FAMLY`, `ORD`
FROM `INVTS`
WHERE `LCTN` LIKE 'Arco Tunnel'
;

-- 38: For each location that isn't listed as 'unknown', show the count of invertebrates observed at that location by the observer named Munts
SELECT `LCTN`, COUNT (*) OBSCOUNT
FROM `INVTS`
WHERE `LCTN` NOT LIKE 'unknown' AND `OBSRVR` LIKE 'Munts'
GROUP BY `LCTN`
;

-- 39: What are the common invertebrate names for invertebrates that were observed in the same habitat that the northern mockingbird was observed in?
SELECT `CMN_NAME`
FROM `INVTS` I
WHERE `HBTAT` IN (SELECT `HBTAT`
FROM `VRTBRTS`
WHERE `CMN_NAME` LIKE 'Northern mockingbird')
;

-- 40: how many habitat codes are there?
SELECT COUNT (*) CODECOUNT
FROM `HBT_CD`
;

