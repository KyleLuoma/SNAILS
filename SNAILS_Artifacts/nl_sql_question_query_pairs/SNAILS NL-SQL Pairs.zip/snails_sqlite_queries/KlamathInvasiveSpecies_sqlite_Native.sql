-- 1: Show the event notes and location IDs from events that started on August 5th, 2011
select Event_Notes, Location_ID from tbl_Event_Details d join tbl_Events e on e.Event_ID = d.Event_ID WHERE date(Start_Date) between date('2011-08-05') AND date('2011-08-05') 	 	 
;

-- 2: Show the event notes and location Names from events that started on August 5th, 2011
select Event_Notes, Loc_Name from tbl_Event_Details d join tbl_Events e on e.Event_ID = d.Event_ID join tbl_Locations l on e.Location_ID = l.Location_ID WHERE date(Start_Date) between date('2011-08-05') AND date('2011-08-05') 	 	 
;

-- 3: How many events are there?
select count(*) eventCount from tbl_events 
;

-- 4: How many events have both micro habitat and macro habitat observations?
select count(*)  from tbl_MacroHabitat mac join tbl_MicroHabitat mic on mac.Event_ID = mic.Event_ID 
;

-- 5: Show the average slope of macro habitat events with Upland hydrology
select avg(Slope) avgSlope from tbl_MacroHabitat where Hydrology = 'Upland' 
;

-- 6: What is the reason for the most-recent database edit, and what table and field was edited, and when was it changed?
select  Reason, [Table], Field, Date_Change from tbl_Edit_Log order by Date_change desc limit 1
;

-- 7: What is the average percent soil disturbance of micro habitats with surface water?
select avg(Soil_dist) avgSoilDisturbance from tbl_MicroHabitat where SurfaceWater > 0 
;

-- 8: For the event at the highest elevation recorded on July 28 2009, show the light index, evergreen coverage, litter coverage, vegetation height, and elevation
select LightIndex, Evergreen, Litter, VegHeight, Elevation from tbl_MicroHabitat m join tbl_Events e on m.Event_ID = e.Event_ID join tbl_Locations l on e.Location_ID = l.Location_ID WHERE date(Start_Date) BETWEEN date('2009-07-28') AND date('2009-07-28') order by Elevation desc limit 1 
;

-- 9: How many species are included in the crater lakes lookup species lookup table?
select count(distinct Species) SpeciesCount from tlu_Species_CRLA 
;

-- 10: Show all of the species listed in the Lava Beds National Monument species lookup table in 2017
select Species from tlu_Species_LABE where SampleYear = 2017 
;

-- 11: For each year, display a count of distinct species in the oregon caves national monument and preserve species lookup table.
select SampleYear, count(distinct Species) SpeciesCount from tlu_Species_ORCA group by SampleYear 
;

-- 12: For each year, display a count of distinct species in the Redwood National Parks species lookup table.
select SampleYear, count(distinct Species) SpeciesCount from tlu_Species_REDW group by SampleYear 
;

-- 13: Make a list of species that are in the Redwood national parks species lookup table that are not in the Whiskeytown National Recreation area species lookup table. Include only one row per species.
select distinct Species from tlu_Species_REDW where Species not in ( 	select Species from tlu_Species_WHIS ) 
;

-- 14: Which species are in both the Oregon Caves National Monument species lookup table and the Lassen Volcanic National Park species lookup table? Include only one row per species.
select distinct Species from tlu_Species_LAVO where Species in ( 	select Species 	from tlu_Species_ORCA ) 
;

-- 15: What is the position title, city, state, and zip code, of the contact with the first name Ivan and the last name C?
select Position_Title, City, State_Code, Zip_Code from tlu_Contacts where First_Name = 'Ivan' and Last_Name = 'C' 
;

-- 16: What is Dominic D's position title?
select Position_Title  from tlu_Contacts where First_Name = 'Dominic' and Last_Name = 'D' 
;

-- 17: How many different enumeration groups are there?
select count(distinct Enum_Group) enumCount from tlu_Enumerations 
;

-- 18: What is the description of the Logging code in the Land Use enumeration group?
select Enum_Description from tlu_Enumerations where Enum_Group = 'Land Use' 	and Enum_Code = 'Logging' 
;

-- 19: How many different codes are there for each enumeration group?
select Enum_Group, count(*) codeCount from tlu_Enumerations group by Enum_Group 
;

-- 20: What is the revision reason and description for revisions made by Allison S?
select Revision_Reason, Revision_Desc from tbl_Db_Revisions r join tlu_Contacts c on r.Revision_Contact_ID = c.Contact_ID where First_Name = 'Allison' and Last_Name = 'S' 
;

-- 21: For each year, show how many revisions were made to the database.
select strftime('%Y', Revision_Date) YearRevised, count(*) RevisionCount from tbl_Db_Revisions group by strftime('%Y', Revision_Date) 
;

-- 22: Show the name, ID, description, length, and route of the site with the highest starting Y coordinate.
select  Site_ID, Site_Name, Site_Desc, Length, Route from tbl_Sites order by Site_Start_Y desc limit 1
;

-- 23: Show the starting and ending X and Y coordinates for the site named Nobles Pass C
select Site_Start_X, Site_End_X, Site_Start_Y, Site_End_Y from tbl_Sites where Site_Name = 'Nobles Pass C' 
;

-- 24: What is the name and number of sites of the site with the most locations?
select  Site_Name, count(*) LocationCount from tbl_Sites s join tbl_Locations l on s.Site_ID = l.Site_ID group by Site_Name order by count(*) desc limit 1
;

-- 25: Show location name and the X and Y coordinates of all the locations at the site named North A
select Loc_Name, X_Coord, Y_Coord from tbl_Sites s join tbl_Locations l on s.Site_ID = l.Site_ID where site_name = 'North A' 
;

-- 26: What is the first name of the contact associated with the highest number of unique events?
select  First_Name from tlu_Contacts c join xref_Event_Contacts x on c.Contact_ID = x.Contact_ID group by First_Name order by count(distinct event_id) desc limit 1
;

-- 27: What are the First names, last names, and position titles of contacts who uploaded an event that started in August of 2021? Include only one row per contact
select distinct First_Name, Last_Name, Position_Title from tlu_Contacts c join xref_Event_Contacts x on c.Contact_ID = x.Contact_ID join tbl_Events e on x.Event_ID = e.Event_ID where date(Start_Date) >= date('2021-08-01') and date(Start_Date) <= date('2021-08-31') 
;

-- 28: How many events were documented at each location? Show the location name and count of events. Only show the 10 locations with the highest number of events.
select  Loc_Name, count(*) eventCount from tbl_locations l join tbl_events e on l.Location_ID = e.Location_ID group by Loc_Name order by count(*) desc limit 10
;

-- 29: How many events were documented at each site? Show the site name, site description, and count of events. Only show the 10 sites with the highest number of events.
select  Site_Name, site_Desc, count(*) eventCount from tbl_locations l join tbl_events e on l.Location_ID = e.Location_ID join tbl_Sites s on l.Site_ID = s.Site_ID group by Site_Name, Site_Desc order by count(*) desc limit 10
;

-- 30: What is the trimble position dilution of position, the horizontal dilution of position, and the estimated position error of the locations at the site named Mule Town B?
select PDOP, HDOP, EPE from tbl_locations l join tbl_Sites s on l.Site_ID = s.Site_ID where site_name = 'Mule Town B' 
;

-- 31: How many locations are there in Shasta count?
select count(*) locCount from tbl_Locations where county = 'Shasta' 
;

-- 32: For each location type, show a count of locations in shasta county.
select Loc_Type, count(*) locCount from tbl_Locations where county = 'Shasta' group by Loc_Type 
;

-- 33: Show the names of the ten sites and the count of infested sites, of the sites with the most locations of type infestation
select  Site_Name, count(*) SiteCount from tbl_Locations l join tbl_sites s on l.Site_ID = s.Site_ID where loc_Type = 'Infestation' group by site_Name order by count(*) desc limit 10
;

-- 34: Show a list of event IDs for events that were documented at the Wood River watershed and the Annie Creek sub watershed
select Event_ID from tbl_Events e join tbl_locations l on e.Location_ID = l.Location_ID where Watershed = 'Wood River' and Subwatershed = 'Annie Creek' 
;

-- 35: What is the average elevation of the Annie Creek Subwatershed?
select avg(Elevation) avgElevation from tbl_locations where Subwatershed = 'Annie Creek' 
;

-- 36: How many locations were a randomly generated plot that was found to have an infestation?
select count(*) LocCount from tbl_locations where Rnd_Plt_In = 'Yes' 
;

-- 37: Show the X and Y coordinates, the coordinate units, the coordinate system and datum, the horizontal error, accuracy notes and location type of the location named CRLA-Infestation-3924
select Loc_Name, X_Coord, Y_Coord, Coord_Units, Coord_System, Datum, Est_H_Error, Accuracy_Notes, Loc_Type from tbl_locations where Loc_Name = 'CRLA-Infestation-3924' 
;

-- 38: How many events are logged for each Hydrology type?
select Hydrology, count(*) EventCount from tbl_MacroHabitat group by Hydrology 
;

-- 39: Show the Macro Habitat, Micro Habitat, Hydrology, Land Use, Slope, and Aspect of the Macro Habitats associated with events started in July of 2015
select MacroHab, MicroHab, Hydrology, LandUse, Slope, Aspect from tbl_MacroHabitat mh join tbl_Events e on mh.Event_ID = e.Event_ID where date(Start_Date) >= date('2015-07-01') and date(Start_Date) <= date('2015-07-31') 
;

-- 40: What is the deciduous, shrub, herb, debris, litter, ground, and rock coverage of micro habitatis with a Flowering Phenology and a cover percentage greater than 90
select Deciduous, Shrub, Herb, WoodyDebris, Litter, BareGround, Rock from tbl_MicroHabitat where Phenology = 'Flowering' 	and cast(CoverPercent as float) > 90 
;

