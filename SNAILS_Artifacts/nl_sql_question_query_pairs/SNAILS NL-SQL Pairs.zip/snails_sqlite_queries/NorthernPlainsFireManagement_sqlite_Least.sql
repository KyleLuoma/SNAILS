-- 1: How many events were logged in each year?
SELECT STRFTIME ('%Y', `E_DT`) EVENTSYEAR, COUNT (*) EVENTCOUNT
FROM `EVS`
GROUP BY STRFTIME ('%Y', `E_DT`)
;

-- 2: What is the average midpoint diameter of deadwood in decay stage 2a?
SELECT AVG (`MPD`) AVGDIAMETER
FROM `DWOOD`
WHERE `DCY` = '2a'
;

-- 3: What are the directions to the Maddron Bald Trail?
SELECT `DIR`
FROM `LOCS`
WHERE `TR` = 'maddron bald trail'
;

-- 4: Show the site description of locations at plots that were in events in 2001
SELECT `SD`
FROM `LOCS` L
JOIN `EVS` E ON `E`.`L_ID` = `L`.`L_ID`
WHERE STRFTIME ('%Y', `E_DT`) = '2001'
;

-- 5: Show the genus, species, and common name of plant species observed in nested subpluts of event 30. Include only one row per type
SELECT DISTINCT `GNS`, `SPCS`, `CMNM`
FROM `NSTS` N
JOIN `PLSPC` S ON `N`.`S_C` = `S`.`SC`
WHERE `E_ID` = 30
;

-- 6: What is the average diamater of overstory of the montana species observed in events 15 and 16
SELECT AVG (`DBH`) AVGDIAMETER
FROM `EVS` E
JOIN `OVRSTRY` O ON `E`.`E_ID` = `O`.`E_ID`
JOIN `PLSPC` S ON `O`.`S_C` = `S`.`SC`
WHERE `SPCS` = 'montana' AND `E`.`E_ID` IN (15, 16)
;

-- 7: Show all the diamater class 1, 2, 3 and 4 entries for sapplings with species code Abiefra
SELECT `S_C`, `DCLASS1`, `DCLASS2`, `DCLASS3`, `DCLASS4`
FROM `SPL`
WHERE `S_C` = 'Abiefra'
;

-- 8: What is the average seedling density of the Acer genus?
SELECT AVG (`DNS`) AVGSEEDLINGDENSITY
FROM `SDLG` S
JOIN `PLSPC` SP ON `S`.`S_C` = `SP`.`SC`
WHERE `GNS` = 'Acer'
;

-- 9: For each location ID, show the average seedling density of the Acer genus.
SELECT `L_ID`, AVG (`DNS`) AVGSEEDLINGDENSITY
FROM `SDLG` S
JOIN `PLSPC` SP ON `S`.`S_C` = `SP`.`SC`
JOIN `EVS` E ON `E`.`E_ID` = `S`.`E_ID`
WHERE `GNS` = 'Acer'
GROUP BY `L_ID`
;

-- 10: What are the average north and east universal transvserse mercator coordinates of Sevier County TN?
SELECT AVG (`UTME`) ECENTROID, AVG (`UTMN`) NCENTROID
FROM `PLNM`
WHERE `CTY` = 'Sevier' AND `ST` = 'TN'
;

-- 11: What are the X and Y coordinates, and the species code, of the tree with tag ID 144
SELECT `XC`, `YC`, `S_C`
FROM `TRTG`
WHERE `TTID` = 144
;

-- 12: For each tree condition, show the number of trees for trees with a tag number (not tag ID) greater than 220.
SELECT `TRCOND`, COUNT (*) TREECOUNT
FROM `TRTG` TT
JOIN `OVRSTRY` O ON `O`.`TT` = `TT`.`TTID`
WHERE `TG` > 220
GROUP BY `TRCOND`
;

-- 13: Show the tree condition description and the total count of overstory in each condition category.
SELECT `TC_TEXT`, COUNT (*) TREECOUNT
FROM `TR_CN` TC
JOIN `OVRSTRY` O ON `O`.`TRCOND` = `TC`.`TCN`
GROUP BY `TC_TEXT`
;

-- 14: What is the species code and diameter at breast height of the witness tree that is furthest from the marking stake? Exclude location ID 4 from the result.
SELECT `WITSPCD`, `WITNESS_DBH`
FROM `WTNSTRS`
WHERE `L_ID` <> 4
ORDER BY `W_STK` DESC LIMIT 1
;

-- 15: How many overstory's have a codominant canopy position?
SELECT COUNT (*) OVERSTORYCOUNT
FROM `CNP` C
JOIN `OVRSTRY` O ON `C`.`CANPOS_NUM` = `O`.`CANPOS`
WHERE `CPN` = 'codominant'
;

-- 16: For each canopy position name, show how many overstory were classified for each position for the species with the common name 'Red Maple'
SELECT `CPN`, COUNT (*) OVERSTORYCOUNT
FROM `CNP` C
JOIN `OVRSTRY` O ON `C`.`CANPOS_NUM` = `O`.`CANPOS`
JOIN `PLSPC` S ON `S`.`SC` = `O`.`S_C`
WHERE `CMNM` = 'Red maple'
GROUP BY `CPN`
;

-- 17: For all of the locations with a Midslope topographical position, show the site description, slope, aspect, slope shape, and elevation
SELECT `SD`, `SLP`, `ASP`, `S_SHP`, `ELV`
FROM `LOCS` L
JOIN `TOP_POS` P ON `L`.`TP_POS` = `P`.`ID`
WHERE `TPPOS` = 'Midslope'
;

-- 18: What is the species code and cover class text description of the nested subplot with ID 48?
SELECT `S_C`, `CC_TXT`
FROM `NSTS` N
JOIN `CVCL` CC ON `N`.`CVR` = `CC`.`CCN`
WHERE `N_ID` = 48
;

-- 19: For each decay stage, show the description and the count of dead wood observations
SELECT `DCSTGDESCR`, COUNT (*) DEADWOODCOUNT
FROM `DCYSTG` DC
JOIN `DWOOD` DW ON `DC`.`DS_ID` = `DW`.`DCY`
GROUP BY `DCSTGDESCR`
;

-- 20: How many decay stages are there?
SELECT COUNT (*)
FROM `DCYSTG`
;

-- 21: Show the length and midpoint diameter of dead wood in the decay stage that has 'log is flat' in the description?
SELECT `LN`, `MPD`
FROM `DWOOD` DW
JOIN `DCYSTG` DC ON `DW`.`DCY` = `DC`.`DS_ID`
WHERE `DCSTGDESCR` LIKE '%log is flat%'
;

-- 22: Show the genus of plant species observed in nested subplots where their presence description included the phrase 'species occurred in rest of plot'.
SELECT `GNS`
FROM `PLSPC` SP
JOIN `NSTS` N ON `N`.`S_C` = `SP`.`SC`
JOIN `R1ROP` R ON `N`.`R1` = `R`.`PNUM`
WHERE `PTXT` LIKE '%species occurred in rest of plot%'
;

-- 23: How many plant species have the term 'native' in their notes? Show a count of these species by their genus. Only include the five highest results.
SELECT `GNS`, COUNT (*) SPECIESCOUNT
FROM `PLSPC`
WHERE `S_NOTES` LIKE '%native%'
GROUP BY `GNS`
ORDER BY COUNT (*) DESC LIMIT 5
;

-- 24: Show the database title, file name, release notes, author email, and organization name, for the application release that occurred in 2015
SELECT `DB_TTL`, `F_NM`, `R_NOTES`, `A_EML`, `A_ORG_NM`
FROM `TAR`
WHERE DATE (`R_DT`) >= DATE ('2015-01-01') AND DATE (`R_DT`) <= DATE ('2015-12-31')
;

-- 25: How many different slope shapes are there in the lookup table?
SELECT COUNT (*)
FROM `SLP_SHP`
;

-- 26: For events that occurred in 1999, show the average seedling density by location ID.
SELECT `L_ID`, AVG (`DNS`) SEEDLINGDENSITY
FROM `SDLG` S
JOIN `EVS` E ON `S`.`E_ID` = `E`.`E_ID`
WHERE STRFTIME ('%Y', `E_DT`) = '1999'
GROUP BY `L_ID`
;

-- 27: What is the average diameter of the fraseri overstory species measurement in each month with an event that measured one?
SELECT STRFTIME ('%m', `E`.`E_DT`) MON, AVG (`DBH`) AVGFRASERIDIAM
FROM `OVRSTRY` O
JOIN `EVS` E ON `E`.`E_ID` = `O`.`E_ID`
JOIN `PLSPC` S ON `O`.`S_C` = `S`.`SC`
WHERE `S`.`SPCS` = 'fraseri'
GROUP BY STRFTIME ('%m', `E`.`E_DT`)
;

-- 28: Show a count of roads and trails by layer.
SELECT `LYR`, COUNT (*)
FROM `RD_TRL`
GROUP BY `LYR`
;

-- 29: Show a count of roads and trails by layer for entries that have the word Balsam in their valid name.
SELECT `LYR`, COUNT (*)
FROM `RD_TRL`
WHERE `V_NM` LIKE '%Balsam%'
GROUP BY `LYR`
;

-- 30: How many places are in each state?
SELECT `ST`, COUNT (*) PLACECOUNT
FROM `PLNM`
GROUP BY `ST`
;

-- 31: What is the name, county, state, and E and N coordinates of the northmost place?
SELECT `NM`, `CTY`, `ST`, `UTME`, `UTMN`
FROM `PLNM`
ORDER BY `UTMN` DESC LIMIT 1
;

-- 32: For each first presence description text entry, show the number of nested subplots in the event with id 30.
SELECT `PTXT`, COUNT (*) NESTCOUNT
FROM `PRS` P
JOIN `NSTS` N ON `P`.`PNUM` = `N`.`P_FST`
WHERE `E_ID` = 30
GROUP BY `PTXT`
;

-- 33: What is the distance between the highest and lowest X coordinate locations, and the distance between highest and lowest Y coordinate locations?
SELECT MAX (`X_C`) - MIN (`X_C`) XDIST, MAX (`Y_C`) - MIN (`Y_C`) YDIST
FROM `LOCS`
;

-- 34: What is the Genus, species, and common name of the species with the highest seedling density?
SELECT `GNS`, `SPCS`, `CMNM`
FROM `SDLG` S
JOIN `PLSPC` SP ON `S`.`S_C` = `SP`.`SC`
ORDER BY `DNS` DESC LIMIT 1
;

-- 35: Which month has the highest average seedling density?
SELECT STRFTIME ('%m', `E_DT`)
FROM `SDLG` S
JOIN `EVS` E ON `S`.`E_ID` = `E`.`E_ID`
GROUP BY STRFTIME ('%m', `E_DT`)
ORDER BY AVG (`DNS`) DESC LIMIT 1
;

-- 36: How many of each tree species have tree tags at location with ID 2? Show the counts by common species name.
SELECT `CMNM`, COUNT (*) TAGCOUNT
FROM `TRTG` TG
JOIN `PLSPC` SP ON `TG`.`S_C` = `SP`.`SC`
WHERE `L_ID` = 2
GROUP BY `CMNM`
;

-- 37: How many of each tree species have tree tags at locations abobe 4000 feet? Show the counts by genus and common species name.
SELECT `GNS`, `CMNM`, COUNT (*) TAGCOUNT
FROM `TRTG` TG
JOIN `PLSPC` SP ON `TG`.`S_C` = `SP`.`SC`
JOIN `LOCS` L ON `TG`.`L_ID` = `L`.`L_ID`
WHERE `ELV` > 4000
GROUP BY `GNS`, `CMNM`
;

-- 38: Show the ecology notes, coordinate units, coordinate system, and datum for the location on plot A14_1
SELECT `E_NT`, `CRDUNTS`, `CS`, `DM`
FROM `LOCS`
WHERE `PL_ID` = 'A14_1'
;

-- 39: What are the location notes for the location that has the phrase 'probably post logging' in the other disturbance entry?
SELECT `L_NT`
FROM `LOCS`
WHERE `O_DIST` LIKE '%probably post logging%'
;

-- 40: How many events had both overstory and deadwood entries?
SELECT COUNT (DISTINCT `E_ID`) EVENTCOUNT
FROM `DWOOD` D
WHERE `D`.`E_ID` IN (SELECT `E_ID`
FROM `OVRSTRY`)
;

