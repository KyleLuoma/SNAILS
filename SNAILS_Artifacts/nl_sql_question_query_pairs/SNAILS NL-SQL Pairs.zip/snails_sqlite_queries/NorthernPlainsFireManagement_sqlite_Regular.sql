-- 1: How many events were logged in each year?
SELECT STRFTIME ('%Y', `EVENT_DATE`) EVENTSYEAR, COUNT (*) EVENTCOUNT
FROM `TABLE_EVENTS`
GROUP BY STRFTIME ('%Y', `EVENT_DATE`)
;

-- 2: What is the average midpoint diameter of deadwood in decay stage 2a?
SELECT AVG (`MIDPOINTDIAMETER`) AVGDIAMETER
FROM `TABLE_DEADWOOD`
WHERE `DECAY` = '2a'
;

-- 3: What are the directions to the Maddron Bald Trail?
SELECT `DIRECTIONS`
FROM `TABLE_LOCATIONS`
WHERE `TRAIL` = 'maddron bald trail'
;

-- 4: Show the site description of locations at plots that were in events in 2001
SELECT `SITEDESCRIPTION`
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_EVENTS` E ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE STRFTIME ('%Y', `EVENT_DATE`) = '2001'
;

-- 5: Show the genus, species, and common name of plant species observed in nested subpluts of event 30. Include only one row per type
SELECT DISTINCT `GENUS`, `SPECIES`, `COMMONNAME`
FROM `TABLE_NESTS` N
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` S ON `N`.`SPECIES_CODE` = `S`.`SPECIESCODE`
WHERE `EVENT_ID` = 30
;

-- 6: What is the average diamater of overstory of the montana species observed in events 15 and 16
SELECT AVG (`DIAMETERBREASTHEIGHT`) AVGDIAMETER
FROM `TABLE_EVENTS` E
JOIN `TABLE_OVERSTORY` O ON `E`.`EVENT_ID` = `O`.`EVENT_ID`
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` S ON `O`.`SPECIES_CODE` = `S`.`SPECIESCODE`
WHERE `SPECIES` = 'montana' AND `E`.`EVENT_ID` IN (15, 16)
;

-- 7: Show all the diamater class 1, 2, 3 and 4 entries for sapplings with species code Abiefra
SELECT `SPECIES_CODE`, `DIAMETERCLASS1`, `DIAMETERCLASS2`, `DIAMETERCLASS3`, `DIAMETERCLASS4`
FROM `TABLE_SAPLINGS`
WHERE `SPECIES_CODE` = 'Abiefra'
;

-- 8: What is the average seedling density of the Acer genus?
SELECT AVG (`DENSITY`) AVGSEEDLINGDENSITY
FROM `TABLE_SEEDLINGS` S
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` SP ON `S`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
WHERE `GENUS` = 'Acer'
;

-- 9: For each location ID, show the average seedling density of the Acer genus.
SELECT `LOCATION_ID`, AVG (`DENSITY`) AVGSEEDLINGDENSITY
FROM `TABLE_SEEDLINGS` S
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` SP ON `S`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
JOIN `TABLE_EVENTS` E ON `E`.`EVENT_ID` = `S`.`EVENT_ID`
WHERE `GENUS` = 'Acer'
GROUP BY `LOCATION_ID`
;

-- 10: What are the average north and east universal transvserse mercator coordinates of Sevier County TN?
SELECT AVG (`UNIVERSAL_TRANSVERSE_MERCATOR_EASTING`) ECENTROID, AVG (`UNIVERSAL_TRANSVERSE_MERCATOR_NORTHING`) NCENTROID
FROM `TABLE_PLACENAMES`
WHERE `COUNTY` = 'Sevier' AND `STATE` = 'TN'
;

-- 11: What are the X and Y coordinates, and the species code, of the tree with tag ID 144
SELECT `XCOORDINATE`, `YCOORDINATE`, `SPECIES_CODE`
FROM `TABLE_TREE_TAGS`
WHERE `TREE_TAG_IDENTIFIER` = 144
;

-- 12: For each tree condition, show the number of trees for trees with a tag number (not tag ID) greater than 220.
SELECT `TREE_CONDITION`, COUNT (*) TREECOUNT
FROM `TABLE_TREE_TAGS` TT
JOIN `TABLE_OVERSTORY` O ON `O`.`TREETAG` = `TT`.`TREE_TAG_IDENTIFIER`
WHERE `TAG` > 220
GROUP BY `TREE_CONDITION`
;

-- 13: Show the tree condition description and the total count of overstory in each condition category.
SELECT `TREE_CONDITION_DESCRIPTION`, COUNT (*) TREECOUNT
FROM `TABLE_LOOKUP_TREE_CONDITION` TC
JOIN `TABLE_OVERSTORY` O ON `O`.`TREE_CONDITION` = `TC`.`TREE_CONDITION_NUMBER`
GROUP BY `TREE_CONDITION_DESCRIPTION`
;

-- 14: What is the species code and diameter at breast height of the witness tree that is furthest from the marking stake? Exclude location ID 4 from the result.
SELECT `WITNESSTREE_SPECIES_CODE`, `WITNESS_TREE_DIAMETER_BREAST_HEIGHT`
FROM `TABLE_WITNESSTREES`
WHERE `LOCATION_ID` <> 4
ORDER BY `WITNESS_STAKE` DESC LIMIT 1
;

-- 15: How many overstory's have a codominant canopy position?
SELECT COUNT (*) OVERSTORYCOUNT
FROM `TABLE_LOOKUP_CANOPY_POSITION` C
JOIN `TABLE_OVERSTORY` O ON `C`.`CANOPYPOSITIONNUMBER` = `O`.`CANOPY_POSITION`
WHERE `CANOPYPOSITIONNAME` = 'codominant'
;

-- 16: For each canopy position name, show how many overstory were classified for each position for the species with the common name 'Red Maple'
SELECT `CANOPYPOSITIONNAME`, COUNT (*) OVERSTORYCOUNT
FROM `TABLE_LOOKUP_CANOPY_POSITION` C
JOIN `TABLE_OVERSTORY` O ON `C`.`CANOPYPOSITIONNUMBER` = `O`.`CANOPY_POSITION`
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` S ON `S`.`SPECIESCODE` = `O`.`SPECIES_CODE`
WHERE `COMMONNAME` = 'Red maple'
GROUP BY `CANOPYPOSITIONNAME`
;

-- 17: For all of the locations with a Midslope topographical position, show the site description, slope, aspect, slope shape, and elevation
SELECT `SITEDESCRIPTION`, `SLOPE`, `ASPECT`, `SLOPE_SHAPE`, `ELEVATION`
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_LOOKUP_TOPOGRAPHIC_POSITION` P ON `L`.`TOPOGRAPHIC_POSITION` = `P`.`IDENTIFIER`
WHERE `TOPOGRAPHICPOSITION` = 'Midslope'
;

-- 18: What is the species code and cover class text description of the nested subplot with ID 48?
SELECT `SPECIES_CODE`, `COVERCLASS_TEXT`
FROM `TABLE_NESTS` N
JOIN `TABLE_LOOKUP_COVER_CLASS` CC ON `N`.`COVER` = `CC`.`COVERCLASS_NUMBER`
WHERE `NEST_ID` = 48
;

-- 19: For each decay stage, show the description and the count of dead wood observations
SELECT `DECAY_STAGE_DESCRIPTION`, COUNT (*) DEADWOODCOUNT
FROM `TABLE_LOOKUP_DECAYSTAGE` DC
JOIN `TABLE_DEADWOOD` DW ON `DC`.`DECAYSTAGE_ID` = `DW`.`DECAY`
GROUP BY `DECAY_STAGE_DESCRIPTION`
;

-- 20: How many decay stages are there?
SELECT COUNT (*)
FROM `TABLE_LOOKUP_DECAYSTAGE`
;

-- 21: Show the length and midpoint diameter of dead wood in the decay stage that has 'log is flat' in the description?
SELECT `LENGTH`, `MIDPOINTDIAMETER`
FROM `TABLE_DEADWOOD` DW
JOIN `TABLE_LOOKUP_DECAYSTAGE` DC ON `DW`.`DECAY` = `DC`.`DECAYSTAGE_ID`
WHERE `DECAY_STAGE_DESCRIPTION` LIKE '%log is flat%'
;

-- 22: Show the genus of plant species observed in nested subplots where their presence description included the phrase 'species occurred in rest of plot'.
SELECT `GENUS`
FROM `TABLE_LOOKUP_PLANTSPECIES_LIST` SP
JOIN `TABLE_NESTS` N ON `N`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
JOIN `TABLE_LOOKUP_R1_RESTOFPLOT` R ON `N`.`PRESENCE_CLASS_SPECIES_R1` = `R`.`PRESENCE_NUMBER`
WHERE `PRESENCE_DESCRIPTION` LIKE '%species occurred in rest of plot%'
;

-- 23: How many plant species have the term 'native' in their notes? Show a count of these species by their genus. Only include the five highest results.
SELECT `GENUS`, COUNT (*) SPECIESCOUNT
FROM `TABLE_LOOKUP_PLANTSPECIES_LIST`
WHERE `SPECIESNOTES` LIKE '%native%'
GROUP BY `GENUS`
ORDER BY COUNT (*) DESC LIMIT 5
;

-- 24: Show the database title, file name, release notes, author email, and organization name, for the application release that occurred in 2015
SELECT `DATABASE_TITLE`, `FILE_NAME`, `RELEASE_NOTES`, `AUTHOR_EMAIL`, `AUTHOR_ORGANIZATION_NAME`
FROM `APPLICATION_TABLE_APPLICATION_RELEASE_HISTORY`
WHERE DATE (`RELEASE_DATE`) >= DATE ('2015-01-01') AND DATE (`RELEASE_DATE`) <= DATE ('2015-12-31')
;

-- 25: How many different slope shapes are there in the lookup table?
SELECT COUNT (*)
FROM `TABLE_LOOKUP_SLOPE_SHAPE`
;

-- 26: For events that occurred in 1999, show the average seedling density by location ID.
SELECT `LOCATION_ID`, AVG (`DENSITY`) SEEDLINGDENSITY
FROM `TABLE_SEEDLINGS` S
JOIN `TABLE_EVENTS` E ON `S`.`EVENT_ID` = `E`.`EVENT_ID`
WHERE STRFTIME ('%Y', `EVENT_DATE`) = '1999'
GROUP BY `LOCATION_ID`
;

-- 27: What is the average diameter of the fraseri overstory species measurement in each month with an event that measured one?
SELECT STRFTIME ('%m', `E`.`EVENT_DATE`) MON, AVG (`DIAMETERBREASTHEIGHT`) AVGFRASERIDIAM
FROM `TABLE_OVERSTORY` O
JOIN `TABLE_EVENTS` E ON `E`.`EVENT_ID` = `O`.`EVENT_ID`
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` S ON `O`.`SPECIES_CODE` = `S`.`SPECIESCODE`
WHERE `S`.`SPECIES` = 'fraseri'
GROUP BY STRFTIME ('%m', `E`.`EVENT_DATE`)
;

-- 28: Show a count of roads and trails by layer.
SELECT `LAYER`, COUNT (*)
FROM `TABLE_LOOKUP_ROADS_AND_TRAILS`
GROUP BY `LAYER`
;

-- 29: Show a count of roads and trails by layer for entries that have the word Balsam in their valid name.
SELECT `LAYER`, COUNT (*)
FROM `TABLE_LOOKUP_ROADS_AND_TRAILS`
WHERE `VALIDNAME` LIKE '%Balsam%'
GROUP BY `LAYER`
;

-- 30: How many places are in each state?
SELECT `STATE`, COUNT (*) PLACECOUNT
FROM `TABLE_PLACENAMES`
GROUP BY `STATE`
;

-- 31: What is the name, county, state, and E and N coordinates of the northmost place?
SELECT `NAME`, `COUNTY`, `STATE`, `UNIVERSAL_TRANSVERSE_MERCATOR_EASTING`, `UNIVERSAL_TRANSVERSE_MERCATOR_NORTHING`
FROM `TABLE_PLACENAMES`
ORDER BY `UNIVERSAL_TRANSVERSE_MERCATOR_NORTHING` DESC LIMIT 1
;

-- 32: For each first presence description text entry, show the number of nested subplots in the event with id 30.
SELECT `PRESENCE_DESCRIPTION`, COUNT (*) NESTCOUNT
FROM `TABLE_LOOKUP_PRESENCE_NUMBER` P
JOIN `TABLE_NESTS` N ON `P`.`PRESENCE_NUMBER` = `N`.`PRESENCE_FIRST`
WHERE `EVENT_ID` = 30
GROUP BY `PRESENCE_DESCRIPTION`
;

-- 33: What is the distance between the highest and lowest X coordinate locations, and the distance between highest and lowest Y coordinate locations?
SELECT MAX (`X_COORDINATE`) - MIN (`X_COORDINATE`) XDIST, MAX (`Y_COORDINATE`) - MIN (`Y_COORDINATE`) YDIST
FROM `TABLE_LOCATIONS`
;

-- 34: What is the Genus, species, and common name of the species with the highest seedling density?
SELECT `GENUS`, `SPECIES`, `COMMONNAME`
FROM `TABLE_SEEDLINGS` S
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` SP ON `S`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
ORDER BY `DENSITY` DESC LIMIT 1
;

-- 35: Which month has the highest average seedling density?
SELECT STRFTIME ('%m', `EVENT_DATE`)
FROM `TABLE_SEEDLINGS` S
JOIN `TABLE_EVENTS` E ON `S`.`EVENT_ID` = `E`.`EVENT_ID`
GROUP BY STRFTIME ('%m', `EVENT_DATE`)
ORDER BY AVG (`DENSITY`) DESC LIMIT 1
;

-- 36: How many of each tree species have tree tags at location with ID 2? Show the counts by common species name.
SELECT `COMMONNAME`, COUNT (*) TAGCOUNT
FROM `TABLE_TREE_TAGS` TG
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` SP ON `TG`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
WHERE `LOCATION_ID` = 2
GROUP BY `COMMONNAME`
;

-- 37: How many of each tree species have tree tags at locations abobe 4000 feet? Show the counts by genus and common species name.
SELECT `GENUS`, `COMMONNAME`, COUNT (*) TAGCOUNT
FROM `TABLE_TREE_TAGS` TG
JOIN `TABLE_LOOKUP_PLANTSPECIES_LIST` SP ON `TG`.`SPECIES_CODE` = `SP`.`SPECIESCODE`
JOIN `TABLE_LOCATIONS` L ON `TG`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE `ELEVATION` > 4000
GROUP BY `GENUS`, `COMMONNAME`
;

-- 38: Show the ecology notes, coordinate units, coordinate system, and datum for the location on plot A14_1
SELECT `ECOLOGICAL_NOTES`, `COORDINATE_UNITS`, `COORDINATE_SYSTEM`, `DATUM`
FROM `TABLE_LOCATIONS`
WHERE `PLOT_ID` = 'A14_1'
;

-- 39: What are the location notes for the location that has the phrase 'probably post logging' in the other disturbance entry?
SELECT `LOCATION_NOTES`
FROM `TABLE_LOCATIONS`
WHERE `OTHER_DISTURBANCE` LIKE '%probably post logging%'
;

-- 40: How many events had both overstory and deadwood entries?
SELECT COUNT (DISTINCT `EVENT_ID`) EVENTCOUNT
FROM `TABLE_DEADWOOD` D
WHERE `D`.`EVENT_ID` IN (SELECT `EVENT_ID`
FROM `TABLE_OVERSTORY`)
;

