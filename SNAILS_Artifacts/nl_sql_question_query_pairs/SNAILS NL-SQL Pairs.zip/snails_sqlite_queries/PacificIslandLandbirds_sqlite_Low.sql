-- 1: How many stations are there?
SELECT COUNT (*) AS STATION_COUNT
FROM `TBL_STATIONS`
;

-- 2: How many islands are there?
SELECT COUNT (DISTINCT `ILND`)
FROM `TBL_LOCATIONS`
;

-- 3: How many sites does each island have?
SELECT `ILND`, COUNT (DISTINCT `SIT_ID`) AS SITE_COUNT
FROM `TBL_LOCATIONS`
GROUP BY `ILND`
;

-- 4: How many events have a half meter density count greater than 8?
SELECT COUNT (*) DENSITYCOUNT
FROM `TBL_DENS`
WHERE `HLF_MTR` > 8
;

-- 5: Get a count of events by station
SELECT `STN_ID`, COUNT (*) EVENT_COUNT
FROM `TBL_EVENTS`
GROUP BY `STN_ID`
;

-- 6: How many contacts are there from each organization?
SELECT `ORGNZTN`, COUNT (*) PERSON_COUNT
FROM `TLU_CONTACTS`
GROUP BY `ORGNZTN`
;

-- 7: Show all of the zip codes for the city of Hilo.
SELECT DISTINCT `ZIP_CODE`
FROM `TLU_CONTACTS`
WHERE `CTY` = 'Hilo'
;

-- 8: Make a list of events that are repeat samples that were verified by Lauren Smith, and that includes the event id, station id, and the start date,.
SELECT `EVNT_ID`, `STN_ID`, `STRT_DT`
FROM `TBL_EVENTS`
WHERE `REP_SAMPLE` = 1 AND `VERFD_BY` = 'Lauren Smith'
;

-- 9: how many observations were made in the forest bird habitat?
SELECT COUNT (*) OBSCOUNT
FROM `TBL_OBSERVATIONS` O
JOIN `TLU_SPECIES` S ON `O`.`SPECS_ID` = `S`.`SPECS_ID`
WHERE `HBTS` = 'Forest Bird'
;

-- 10: Show a count of observations by species habitat
SELECT `HBTS`, COUNT (*) OBSCOUNT
FROM `TLU_SPECIES` S
JOIN `TBL_OBSERVATIONS` O ON `O`.`SPECS_ID` = `S`.`SPECS_ID`
GROUP BY `HBTS`
;

-- 11: Make a list of event ids for events that have more than 7 observations.
SELECT `E`.`EVNT_ID`
FROM `TBL_EVENTS` E
JOIN `TBL_OBSERVATIONS` O ON `E`.`EVNT_ID` = `O`.`EVNT_ID`
GROUP BY `E`.`EVNT_ID`
HAVING COUNT (*) > 7
;

-- 12: What is the scientific and common name of the three most frequently observed bird species?
SELECT `SCI_NAME`, `CMN_NAM`
FROM `TBL_OBSERVATIONS` O
JOIN `TLU_SPECIES` S ON `O`.`SPECS_ID` = `S`.`SPECS_ID`
GROUP BY `SCI_NAME`, `CMN_NAM`
ORDER BY COUNT (*) DESC LIMIT 3
;

-- 13: What is the most common understory composition and canopy composition combination of events entered by Caitlin Jensen?
SELECT `CANP_COMP`, `UNDRSTRY_CMP`
FROM `TBL_HABITAT` H
JOIN `TBL_EVENTS` E ON `H`.`EVNT_ID` = `E`.`EVNT_ID`
WHERE `ENRTD_BDY` = 'caitlin jensen'
GROUP BY `CANP_COMP`, `UNDRSTRY_CMP`
ORDER BY COUNT (*) DESC LIMIT 1
;

-- 14: What are the weather conditions (cloud cover, rain, wind, and gusts) for events entered by Cari Squibb and updated by Seth Judge?
SELECT `CLOU`, `RN`, `WND`, `GST`
FROM `TBL_EVENTS` E
JOIN `TBL_EVENT_DETAILS` ED ON `E`.`EVNT_ID` = `ED`.`EVNT_ID`
WHERE `UPDTD_BY` = 'Seth Judge' AND `ENRTD_BDY` = 'Cari Squibb'
;

-- 15: How many observations had more than 15 detections?
SELECT COUNT (*) OBSCOUNT
FROM (SELECT `OBSRVN_ID`
FROM `TBL_DETECTIONS` D
GROUP BY `OBSRVN_ID`
HAVING COUNT (`DET_ID`) > 15) T
;

-- 16: What is the average detection distance for all detections?
SELECT AVG (`DISTNC`) AVGDIST
FROM `TBL_DETECTIONS`
;

-- 17: What is the common name of the species observed and detected from the farthest distance?
SELECT `CMN_NAM`
FROM `TLU_SPECIES` S
JOIN `TBL_OBSERVATIONS` O ON `S`.`SPECS_ID` = `O`.`SPECS_ID`
JOIN `TBL_DETECTIONS` T ON `T`.`OBSRVN_ID` = `O`.`OBSRVN_ID`
ORDER BY `DISTNC` DESC LIMIT 1
;

-- 18: what are the common names and alternate names for birds of the family Laridae?
SELECT `CMN_NAM`, `ALTNAME`
FROM `TLU_SPECIES` S
JOIN `XREF_SPECIES_ALTERNATE_NAMES` A ON `S`.`SPECS_ID` = `A`.`SPECS_ID`
WHERE `FAM` = 'laridae'
;

-- 19: what are all of the different sources of species information?
SELECT DISTINCT `SRCE`
FROM `TLU_SPECIES`
;

-- 20: What is the station name of the station currently located at UTM coordinates X 272454 Y 2141631
SELECT `STN`
FROM `TBL_STATIONS`
JOIN `TBL_STATIONS_UTMS` ON `TBL_STATIONS`.`STN_ID` = `TBL_STATIONS_UTMS`.`STN_ID`
WHERE `X_FINAL` = 272454 AND `Y_FINAL` = 2141631
;

-- 21: what is Patrick Hart's position and organization?
SELECT `POSN_TITLE`, `ORGNZTN`
FROM `TLU_CONTACTS`
WHERE `F_NAME` = 'Patrick' AND `L_NAME` = 'Hart'
;

-- 22: What are the names of the sites on each island?
SELECT DISTINCT `ILND`, `SIT_NAM`
FROM `TBL_LOCATIONS`
JOIN `TBL_SITES` ON `TBL_LOCATIONS`.`SIT_ID` = `TBL_SITES`.`SIT_ID`
;

-- 23: Which island has the location called Northwest Kahuku?
SELECT `ILND`
FROM `TBL_LOCATIONS`
WHERE `LOC_NAME` = 'Northwest Kahuku'
;

-- 24: what are the family, scientific and common names of all of the bird species that occupy Forest Bird habitats?
SELECT DISTINCT `FAM`, `SCI_NAME`, `CMN_NAM`
FROM `TLU_SPECIES`
WHERE `HBTS` = 'Forest Bird'
;

-- 25: How many station locations are documented using WGS84 and how many are documented using NAD83 datums?
SELECT DISTINCT `DATM`, COUNT (*) STATIONCOUNT
FROM `TBL_STATIONS_UTMS`
WHERE `DATM` IN ('WGS84', 'NAD83')
GROUP BY `DATM`
;

-- 26: How many observations were made on days when there were no clouds in the sky?
SELECT COUNT (*) OBS_COUNT
FROM `TBL_OBSERVATIONS` OBS
JOIN `TBL_EVENT_DETAILS` DET ON `OBS`.`EVNT_ID` = `DET`.`EVNT_ID`
WHERE `CLOU` = 0
;

-- 27: how many events occurred on the most windy days?
SELECT COUNT (*) WINDY_DAY_COUNT
FROM `TBL_EVENT_DETAILS`
WHERE `WND` IN (SELECT MAX (`WND`)
FROM `TBL_EVENT_DETAILS`)
;

-- 28: How many stations does each island have?
SELECT `ILND`, COUNT (*) AS STATION_COUNT
FROM `TBL_LOCATIONS` LOC
JOIN `TBL_TRANSECT` TRANS ON `LOC`.`LOC_ID` = `TRANS`.`LOC_ID`
JOIN `TBL_STATIONS` STA ON `TRANS`.`TRANSECT_ID` = `STA`.`TRANSECT_ID`
GROUP BY `ILND`
;

-- 29: Which island has the fewest stations, and how many stations does it have?
SELECT `ILND`, COUNT (*) AS STATION_COUNT
FROM `TBL_LOCATIONS` LOC
JOIN `TBL_TRANSECT` TRANS ON `LOC`.`LOC_ID` = `TRANS`.`LOC_ID`
JOIN `TBL_STATIONS` STA ON `TRANS`.`TRANSECT_ID` = `STA`.`TRANSECT_ID`
GROUP BY `ILND`
ORDER BY `STATION_COUNT` ASC LIMIT 1
;

-- 30: List the distinct family and species code of all bird observed during events logged when it was raining (denoted by the value 1).
SELECT DISTINCT `FAM`, `SPECIES_CD`
FROM `TLU_SPECIES` S
JOIN `TBL_OBSERVATIONS` O ON `S`.`SPECS_ID` = `O`.`SPECS_ID`
JOIN `TBL_EVENTS` E ON `O`.`EVNT_ID` = `E`.`EVNT_ID`
JOIN `TBL_EVENT_DETAILS` ED ON `E`.`EVNT_ID` = `ED`.`EVNT_ID`
WHERE `RN` = 1
;

-- 31: What species has Patrick Hart observed? List all of them by their scientific and common names. Don't include duplicate rows.
SELECT DISTINCT `SCI_NAME`, `CMN_NAM`
FROM `TLU_SPECIES` SPC
JOIN `TBL_OBSERVATIONS` OBS ON `SPC`.`SPECS_ID` = `OBS`.`SPECS_ID`
JOIN `XREF_EVENT_CONTACTS` XCON ON `XCON`.`EVNT_ID` = `OBS`.`EVNT_ID`
JOIN `TLU_CONTACTS` CON ON `XCON`.`CONT_ID` = `CON`.`CONT_ID`
WHERE `L_NAME` = 'Hart' AND `F_NAME` = 'Patrick'
ORDER BY `SCI_NAME`
;

-- 32: At stations 2 and 3, show the station name and common names of each species observed at each station, and include the total count of observations per species.
SELECT `STN`, `CMN_NAM`, COUNT (*) NUMOBSERVATIONS
FROM `TBL_STATIONS` T_S
JOIN `TBL_EVENTS` T_E ON `T_E`.`STN_ID` = `T_S`.`STN_ID`
JOIN `TBL_OBSERVATIONS` T_O ON `T_O`.`EVNT_ID` = `T_E`.`EVNT_ID`
JOIN `TLU_SPECIES` T_SP ON `T_O`.`SPECS_ID` = `T_SP`.`SPECS_ID`
WHERE `STN` = '2' OR `STN` = '3'
GROUP BY `STN`, `CMN_NAM`
ORDER BY `STN`
;

-- 33: How many events does each station have? Show them in the descending order of event counts. Include the station name and the event count in the output.
SELECT `STN`, COUNT (*) AS EVENT_COUNT
FROM `TBL_STATIONS` TS
JOIN `TBL_EVENTS` TE ON `TS`.`STN_ID` = `TE`.`STN_ID`
GROUP BY `TS`.`STN`
ORDER BY `EVENT_COUNT` DESC
;

-- 34: What is the northmost station's station name and position?
SELECT `LAT_FINAL`, `LONG_FINAL`, `STN`
FROM `TBL_STATIONS`
ORDER BY `LAT_FINAL` DESC LIMIT 1
;

-- 35: How many stations has the Hawaii Amakihi been observed at?
SELECT COUNT (DISTINCT `TBL_STATIONS`.`STN_ID`) AS STATION_COUNT
FROM `TBL_STATIONS`
JOIN `TBL_EVENTS` ON `TBL_STATIONS`.`STN_ID` = `TBL_EVENTS`.`STN_ID`
JOIN `TBL_OBSERVATIONS` ON `TBL_OBSERVATIONS`.`EVNT_ID` = `TBL_EVENTS`.`EVNT_ID`
JOIN `TLU_SPECIES` ON `TLU_SPECIES`.`SPECS_ID` = `TBL_OBSERVATIONS`.`SPECS_ID`
WHERE `CMN_NAM` = 'Hawaii Amakihi'
;

-- 36: What percent of stations has the bird with the common name Hawaii Amakihi been observed at?
SELECT 100 * (SUM (`SIGHTED`) / COUNT (DISTINCT `STN_ID`)) AS PERC_STATIONS
FROM (SELECT DISTINCT `TBL_STATIONS`.`STN_ID`, CASE WHEN `TLU_SPECIES`.`CMN_NAM` = 'Hawaii Amakihi' THEN 1.0 ELSE 0.0 END AS SIGHTED
FROM `TBL_STATIONS`
JOIN `TBL_EVENTS` ON `TBL_STATIONS`.`STN_ID` = `TBL_EVENTS`.`STN_ID`
JOIN `TBL_OBSERVATIONS` ON `TBL_OBSERVATIONS`.`EVNT_ID` = `TBL_EVENTS`.`EVNT_ID`
JOIN `TLU_SPECIES` ON `TLU_SPECIES`.`SPECS_ID` = `TBL_OBSERVATIONS`.`SPECS_ID`) SIGHTINGS
;

-- 37: Show the first name, last name, and number of logged events for members of the national park service.
SELECT `L_NAME`, `F_NAME`, COUNT (*) NUM_EVENTS
FROM `TLU_CONTACTS` TLC
JOIN `XREF_EVENT_CONTACTS` XREC ON `TLC`.`CONT_ID` = `XREC`.`CONT_ID`
WHERE `ORGNZTN` = 'National Park Service'
GROUP BY `L_NAME`, `F_NAME`, `ORGNZTN`
ORDER BY `L_NAME` DESC
;

-- 38: What is the average canopy height of each species' habitats? Include the common name and scientfic name of each species. Ensure the average has decimal precision.
SELECT `SCI_NAME`, `CMN_NAM`, AVG (CAST (`CANP_HT` AS FLOAT)) AS AVG_CANOPY_HEIGHT
FROM `TBL_HABITAT` HAB
JOIN `TBL_EVENTS` EV ON `HAB`.`EVNT_ID` = `EV`.`EVNT_ID`
JOIN `TBL_OBSERVATIONS` OBS ON `OBS`.`EVNT_ID` = `EV`.`EVNT_ID`
JOIN `TLU_SPECIES` SPEC ON `SPEC`.`SPECS_ID` = `OBS`.`SPECS_ID`
GROUP BY `SCI_NAME`, `CMN_NAM`
ORDER BY `SCI_NAME`
;

-- 39: Create a list of species sightings at each station. Include the island, site name, location name, transect and transect type, station, the station's latitude, the event id of the observations, the last names of those who observed as well as their notes, the family, scientific name, common name, and alternate name of each bird observed.
SELECT `ILND`, `SIT_NAM`, `LOC_NAME`, `TRNSCT`, `TRNSCT_TYP`, `STN`, `LAT_FINAL`, `TE`.`EVNT_ID`, `L_NAME`, `EVNT_NOTES`, `FAM`, `SCI_NAME`, `CMN_NAM`, `ALTNAME`
FROM `TBL_LOCATIONS` TL
JOIN `TBL_SITES` TS ON `TL`.`SIT_ID` = `TS`.`SIT_ID`
JOIN `TBL_TRANSECT` TR ON `TR`.`LOC_ID` = `TL`.`LOC_ID`
JOIN `TBL_STATIONS` ST ON `ST`.`TRANSECT_ID` = `TR`.`TRANSECT_ID`
JOIN `TBL_EVENTS` TE ON `TE`.`STN_ID` = `ST`.`STN_ID`
JOIN `XREF_EVENT_CONTACTS` EC ON `EC`.`EVNT_ID` = `TE`.`EVNT_ID`
JOIN `TLU_CONTACTS` CON ON `EC`.`CONT_ID` = `CON`.`CONT_ID`
JOIN `TBL_OBSERVATIONS` OBS ON `TE`.`EVNT_ID` = `OBS`.`EVNT_ID`
JOIN `TLU_SPECIES` SPC ON `OBS`.`SPECS_ID` = `SPC`.`SPECS_ID`
JOIN `XREF_SPECIES_ALTERNATE_NAMES` SPC_ALT ON `SPC`.`SPECS_ID` = `SPC_ALT`.`SPECS_ID`
;

-- 40: Which island has the most sightings of the bird with the common name Pacific Kingfisher?
SELECT `ILND`, COUNT (*) AS KINGFISHER_COUNT
FROM `TBL_LOCATIONS` TL
JOIN `TBL_TRANSECT` TR ON `TR`.`LOC_ID` = `TL`.`LOC_ID`
JOIN `TBL_STATIONS` ST ON `ST`.`TRANSECT_ID` = `TR`.`TRANSECT_ID`
JOIN `TBL_EVENTS` TE ON `TE`.`STN_ID` = `ST`.`STN_ID`
JOIN `XREF_EVENT_CONTACTS` EC ON `EC`.`EVNT_ID` = `TE`.`EVNT_ID`
JOIN `TLU_CONTACTS` CON ON `EC`.`CONT_ID` = `CON`.`CONT_ID`
JOIN `TBL_OBSERVATIONS` OBS ON `TE`.`EVNT_ID` = `OBS`.`EVNT_ID`
JOIN `TLU_SPECIES` SPC ON `OBS`.`SPECS_ID` = `SPC`.`SPECS_ID`
WHERE `CMN_NAM` = 'Pacific Kingfisher'
GROUP BY `ILND`
ORDER BY `KINGFISHER_COUNT` LIMIT 1
;

