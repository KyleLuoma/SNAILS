-- 1: Show the group name and count of business partners in each card group
select GroupName, count(*) partnerCount from OCRG join OCRD on OCRG.GroupCode = OCRD.GroupCode group by GroupName 
;

-- 2: Make a contact roster that includes the name, address, cell phone number, and email address of all persons currently in either a CEO or COO position.
select Name, address, Cellolar, E_MailL from OCPR where Position = 'CEO' or Position = 'COO' 
;

-- 3: What is the commission rate of the sales employee named Bill Levine?
select Commission from OSLP where SlpName = 'Bill Levine' 
;

-- 4: What are the names of sales employees in the high commission group?
select SlpName from OSLP join OCOG on OSLP.GroupCode = OCOG.GroupCode where GroupName = 'High Commission' 
;

-- 5: What are the names, mobile phone numbers, and email addresses of sales employees in the high commission group?
select SlpName, Mobil, Email from OSLP join OCOG on OSLP.GroupCode = OCOG.GroupCode where GroupName = 'High Commission' 
;

-- 6: Display the payment code and tax code for current business partners whos closing date procedure number is lower than 35
select PymCode, TaxCode from OCRD join CRD1 on OCRD.CardCode = CRD1.CardCode where CDPNum < 35 
;

-- 7: List the activity number, contact time and date, and the details of all activities created in the year 2021
select ClgCode, CntctDate, CntctTime, details from OCLG where date(CreateDate) >= date('2021-01-01' and date(CreateDate) <= date('2021-12-31')) 
;

-- 8: Show the bank details, to include bank code, country, account number, branch, and city, for the business partner with the card name Microchips
select OCRB.BankCode, OCRB.Country, Account, Branch, OCRB.City from OCRD join OCRB on OCRD.CardCode = OCRD.CardCode where CardName = 'Microchips' 
;

-- 9: what is the account balance of the business partner with the payment method code 'Incoming BT' and a currency type that is either 'EUR' or 'CAN'
select Balance  from OCRD where Currency in ('EUR', 'CAN') and OCRD.PymCode = 'Incoming BT' 
;

-- 10: What is the email address and federal tax ID of the target with the position of CIO that is of target type C?
select E_Mail, LicTradNum from TGG1 join OTGG on TGG1.TargetCode = OTGG.TargetCode where Position = 'CIO' and TargetType = 'C' 
;

