-- 1: Show the account name and number of journal entries for the general ledger account with code '_SYS00000000002'.
SELECT `ACCTN`, COUNT (*) ENTRYCOUNT
FROM `OACT` O
JOIN `JDT1` J ON `O`.`A_CD` = `J`.`ACCT`
WHERE `ACCT` = '_SYS00000000002'
GROUP BY `ACCTN`
;

-- 2: What is the sum of journal entry debits and sum of journal entry credits due in 2021?
SELECT SUM (`DB`) DEBITSUM, SUM (`CDT`) CREDITSUM
FROM `JDT1`
WHERE DATE (`DU_D`) >= DATE ('2021-01-01' AND DATE (`DU_D`) <= DATE ('2021-12-31'))
;

-- 3: Show the account name, the average monthly budget debit, and average monthly budget credit totals for general ledger accounts with the words 'Travel Expense' in their account name.
SELECT `ACCTN`, AVG (`DLT`) AS AVGDEB, AVG (`CLT`) AS AVGCRED
FROM `OACT`
JOIN `BGT1` ON `OACT`.`A_CD` = `BGT1`.`A_CD`
WHERE `ACCTN` LIKE '%Travel Expense%'
GROUP BY `ACCTN`
;

-- 4: Show the account name and current total balance of accounts with the category name cash
SELECT `ACCTN`, `CR_TT`
FROM `OACT`
JOIN `OACG` ON `OACT`.`CTG` = `OACG`.`ABI`
WHERE `OACG`.`NM` = 'cash'
;

-- 5: For all rows associated with the value added tax transactions that have source object type 18, show the Tax Code, value added tax percent, and the value added tax sum.
SELECT `TX_CD`, `VATPCT`, `VS`
FROM `OTAX`
JOIN `TX1` ON `OTAX`.`ABSE` = `TX1`.`ABSE`
WHERE `SOA` = 18
;

-- 6: What year had the highest rate for currency type 'CAN' from data source I?
SELECT STRFTIME ('%Y', `RT_DT`) HIGHYEAR
FROM `ORTT`
WHERE `D_SRC` = 'I'
ORDER BY `RT` DESC LIMIT 1
;

-- 7: Get a count of recurring postings by year of the next execution
SELECT STRFTIME ('%Y', `NX_D`) NEXTYEAR, COUNT (*) NUMPOSTINGS
FROM `ORCR`
GROUP BY STRFTIME ('%Y', `NX_D`)
;

-- 8: Show the names of the financial report categories that have father number 10
SELECT `NM`
FROM `OFRC`
WHERE `FTHNUM` = 10
;

-- 9: show the report category name and the three different calculation methods for extended category f financial reports with a cash flow line item ids greater than 30
SELECT `NM`, `CMETHOD`, `CM2`, `CM3`
FROM `FRC1`
JOIN `OFRC` ON `FRC1`.`CG_ID` = `OFRC`.`CG_ID`
WHERE `CFWID` > 30
;

-- 10: What is the project code and name of the projects valid after 2020?
SELECT `PJ_C`, `PJNM`
FROM `OPRJ`
WHERE DATE (`VF`) > DATE ('2020-12-31')
;

