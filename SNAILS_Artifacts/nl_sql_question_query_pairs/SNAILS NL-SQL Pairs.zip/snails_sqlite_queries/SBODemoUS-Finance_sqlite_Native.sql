-- 1: Show the account name and number of journal entries for the general ledger account with code '_SYS00000000002'.
select AcctName, count(*) EntryCount from OACT O join JDT1 J on O.AcctCode = J.Account where Account = '_SYS00000000002' group by Acctname 
;

-- 2: What is the sum of journal entry debits and sum of journal entry credits due in 2021?
select sum(debit) debitSum, sum(credit) creditSum from JDT1 where date(DueDate) >= date('2021-01-01' and date(DueDate) <= date('2021-12-31')) 
;

-- 3: Show the account name, the average monthly budget debit, and average monthly budget credit totals for general ledger accounts with the words 'Travel Expense' in their account name.
select AcctName, avg(DebLTotal) as AvgDeb, avg(CredLTotal) as AvgCred from OACT join BGT1 on OACT.AcctCode = BGT1.AcctCode where AcctName like '%Travel Expense%' group by AcctName 
;

-- 4: Show the account name and current total balance of accounts with the category name cash
select AcctName, CurrTotal from OACT join OACG on OACT.category = OACG.AbsId where OACG.Name = 'cash' 
;

-- 5: For all rows associated with the value added tax transactions that have source object type 18, show the Tax Code, value added tax percent, and the value added tax sum.
select TaxCode, VatPercent, VatSum  from OTAX join TAX1 on OTAX.AbsEntry = TAX1.AbsEntry where SrcObjAbs = 18 
;

-- 6: What year had the highest rate for currency type 'CAN' from data source I?
select strftime('%Y', RateDate) HighYear from ORTT where DataSource = 'I' order by Rate desc limit 1 
;

-- 7: Get a count of recurring postings by year of the next execution
select strftime('%Y', NextDeu) NextYear, count(*) NumPostings from ORCR group by strftime('%Y', NextDeu) 
;

-- 8: Show the names of the financial report categories that have father number 10
select name from OFRC where FatherNum = 10 
;

-- 9: show the report category name and the three different calculation methods for extended category f financial reports with a cash flow line item ids greater than 30
select name, CalcMethod, CalMethod2, CalMethod3 from FRC1 join OFRC on FRC1.CatId = OFRC.CatId where CFWId > 30 
;

-- 10: What is the project code and name of the projects valid after 2020?
select prjcode, prjname from OPRJ where date(ValidFrom) > date('2020-12-31') 
;

