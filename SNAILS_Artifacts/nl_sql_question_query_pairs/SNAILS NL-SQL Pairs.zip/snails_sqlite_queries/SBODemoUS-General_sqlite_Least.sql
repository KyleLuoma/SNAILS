-- 1: Show the description and expected costs of project management stages with start dates before october 20th, 2021.
SELECT `DSCRT`, `EX_CST`
FROM `PMG1`
WHERE DATE (`STA`) < DATE ('2021-10-20')
;

-- 2: What values are associated with the dictionary key 'HomePage'?
SELECT `_V`
FROM `CDIC`
WHERE `K` LIKE 'HomePage'
;

-- 3: How many queries does the dashboard entry with code DAB002 have?
SELECT COUNT (*) QUERYCOUNT
FROM `ODAB`
JOIN `DAB1` ON `ODAB`.`ABSE` = `DAB1`.`DB_ENT`
WHERE `DBCD` = 'DAB002'
;

-- 4: Show the Dashboard name, dashboard path, status, and query name for dashboards and their queries where the query category is 2
SELECT `DBN`, `DSHBDPTH`, `STAT`, `QRN`
FROM `ODAB`
JOIN `DAB1` ON `ODAB`.`ABSE` = `DAB1`.`DB_ENT`
WHERE `QY_CT` = 2
;

-- 5: Show the code, name, and number of fields for key performance indicator sets of type P
SELECT `KPS_C`, `KPSNM`, `FLDSNUM`
FROM `OKPS`
WHERE `KTP` = 'P'
;

-- 6: What is the resource name, type, group code, and resource cost 1 of the employee resource with employee ID 9?
SELECT `RSNM`, `RSC_TP`, `RGC`, `SC1`
FROM `ORSC`
JOIN `RSC4` ON `ORSC`.`RS_CD` = `RSC4`.`RS_CD`
WHERE `EID` = 9
;

-- 7: what is the average daily capacity factor 1 of the resource named 'Testing Machine' on weekdays 1 through 5?
SELECT AVG (`C_FCT1`) AVGCAPACITY
FROM `ORSC`
JOIN `RSC6` ON `ORSC`.`RS_CD` = `RSC6`.`RS_CD`
WHERE `RSNM` = 'Testing Machine' AND `WKD` >= 1 AND `WKD` <= 5
;

-- 8: Show the project name and open issue remarks, and open issue solution for projects that have open issues.
SELECT `NM`, `RKS`, `SOL`
FROM `OPMG`
JOIN `PMG2` ON `OPMG`.`ABSE` = `PMG2`.`ABSE`
;

-- 9: Show the cockpit subtable left, right, top, and bottom values for the cockpit named purchase
SELECT `CPT1`.`_LFT`, `CPT1`.`_R`, `CPT1`.`_TP`, `CPT1`.`_BTM`
FROM `OCPT`
JOIN `CPT1` ON `OCPT`.`ABSE` = `CPT1`.`ABSE`
WHERE `NM` = 'Purchase'
;

-- 10: What are the table names of business object briefs with the description fields that have the word Memo in them?
SELECT `T_NM`
FROM `OBOB`
WHERE `DSC_F` LIKE '%Memo%'
;

