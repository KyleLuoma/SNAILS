-- 1: What are the first and last names of employees on the Sales team?
select lastName, firstName from OHEM employees join HTM1 teamMembers on employees.empId = teamMembers.empID join OHTM emplTeams on teamMembers.teamID = emplTeams.teamID where emplTeams.name = 'Sales' 
;

-- 2: Get a list of all of the holiday start and end dates and remarks for holidays in 2014.
select StrDate, EndDate, Rmrks from HLD1 where StrDate >= '20140101 00:00:00.000' 	and EndDate <= '20141231 23:59:59.000' 
;

-- 3: What is the average salary of employees on the purchasing team?
select avg(salary) as avgSalary from OHEM join HTM1 on OHEM.empID = HTM1.empID join OHTM on OHTM.teamID = HTM1.teamID where OHTM.name = 'Purchasing' 
;

-- 4: What is the office phone number, mobile phone number, pager number, and home phone number of the employee named George Keeng?
select officeTel, mobile, pager, homeTel from OHEM where lastName = 'Keeng' and firstName = 'George' 
;

-- 5: What is the first and last name of the spouse of employee Maria Bridi?
select FNameSP, SurnameSP from OHEM where lastName = 'Bridi' and firstName = 'Maria' 
;

-- 6: Show the last name, education status, and number of children for employees of type Technician
select lastName, StatusOfE, nChildren from OHEM join OHTY on OHTY.typeID = OHEM.type where OHTY.name = 'Technician' 
;

-- 7: Show the type ID and name of each employee type
select typeID, [name] from OHTY 
;

-- 8: Make an employee health insurance list that includes their employee ID, last name,  insurance company name, insurance code, and type of insurance.
select empID, lastName, HeaInsName, HeaInsCode, HeaInsType from OHEM 
;

-- 9: What is the job title code of the employee with the last name  Chan?
select JTCode from OHEM where lastName = 'Chan' 
;

-- 10: What are the average vacation days in the current year for employees on the sales team?
select avg(vacCurYear) from OHEM employees join HTM1 teamMembers on employees.empId = teamMembers.empID join OHTM emplTeams on teamMembers.teamID = emplTeams.teamID where emplTeams.name = 'Sales' 
;

-- 11: Show the team ID of the team that has the employee with the personal fiscal ID 51B.
select teamID from HTM1  join OHEM on HTM1.empID = OHEM.empID where CPF = '51B' 
;

-- 12: Show the municipality key, tax class, and income tax liability for all of the employees of type accountant.
select MunKey, TaxClass, InTaxLiabi from OHEM join OHTY on OHEM.type = OHTY.typeID where OHTY.name = 'Accountant' 
;

-- 13: What are the role IDs of employees whos' salaries are less than 5000?
select roleID from HEM6 join OHEM on HEM6.empID = OHEM.empID where salary < 5000 
;

-- 14: Show the date of birth, country of birth, home city, home county, and home country for the employees with the job title of accountant
select birthDate, brthCountr, homeCity, homeCounty, homeCountr from OHEM where jobTitle = 'Accountant' 
;

-- 15: Show the professional status, citizenship and passport number  of the employee whos last name is Buyer
select StatusOfP, citizenshp, passportNo from OHEM where lastName = 'Buyer' 
;

-- 16: Show the first name, last name, home city, and work city of employees whos costs are higher than 4000.
select firstName, lastName, homeCity, workCity from OHEM where emplCost > 4000 
;

-- 17: Show the municipality key, home city, home phone number, work city and office phone number of employees on the sales team.
select MunKey, homeCity, homeTel, workCity, officeTel from OHEM employees join HTM1 teamMembers on employees.empId = teamMembers.empID join OHTM emplTeams on teamMembers.teamID = emplTeams.teamID where emplTeams.name = 'Sales' 
;

-- 18: Show the professional status and educational statuses as well as the home and work street numbers of employees on the purchasing team.
select StatusOfP, StatusOfE, StreetNoW, StreetNoH from OHEM employees join HTM1 teamMembers on employees.empId = teamMembers.empID join OHTM emplTeams on teamMembers.teamID = emplTeams.teamID where emplTeams.name = 'Purchasing' 
;

-- 19: What is the payment method, exemption amount currency, and additional amount currency, for the employee who's tax office name is baltimore?
select pymmeth, exemptcurr, addicurr  from OHEM where TaxOName = 'baltimore' 
;

-- 20: What is the marital status, home street, home block, home zip code, and home state of the employee with the last name Bridi?
select martstatus, homestreet, homeblock, homezip, homestate from OHEM where lastName = 'Bridi' 
;

