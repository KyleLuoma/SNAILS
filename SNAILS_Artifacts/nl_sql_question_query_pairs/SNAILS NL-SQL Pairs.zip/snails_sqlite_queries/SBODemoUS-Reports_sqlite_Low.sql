-- 1: Show the parameter names and parameter parameters for the parameters with the description 'Electronic documents'
SELECT `PARAMNAME`, `PARAMPRMS`
FROM `ELEC_COMM_TYPES_PROTOCOLS`
JOIN `ELEC_COMM_PARAMS` ON `ELEC_COMM_TYPES_PROTOCOLS`.`CD` = `ELEC_COMM_PARAMS`.`CD`
WHERE `DESCR` = 'Electronic documents'
;

-- 2: Get the field and object type xpaths for the mapping determinations associated with parameters with the description 'PEPPOL'.
SELECT `OBJXPATH`, `FLDXPATH`
FROM `IMPRT_MAP_DET`
JOIN `ELEC_COMM_TYPES_PROTOCOLS` ON `IMPRT_MAP_DET`.`CD` = `ELEC_COMM_TYPES_PROTOCOLS`.`CD`
WHERE `DESCR` = 'PEPPOL'
;

-- 3: How many queries are there in each category?
SELECT `QCATEGORY`, COUNT (*) QCOUNT
FROM `QRS_TBL_MN`
GROUP BY `QCATEGORY`
;

-- 4: Display the group description, log instance, the updated date, and the created date of the query group with the code 'Group4'
SELECT `AUTHGRPN`, `LOGINSTANC`, `UPDT_DATE`, `CREAT_DT`
FROM `QRY_AUTH_GROUPS`
WHERE `AUTHGRPCD` = 'Group4'
;

-- 5: What is the widest document width for documents with a grid size of 10?
SELECT `WDTH`
FROM `DOC_TBL`
WHERE `GRDSIZE` = 10
ORDER BY `WDTH` DESC LIMIT 1
;

-- 6: What are the type codes and screen fonts for documents that use the email font 'Tahoma'?
SELECT `TYPCD`, `SCRFONT`
FROM `DOC_TBL`
WHERE `EMFONT` = 'Tahoma'
;

-- 7: Show the document code, and the document type code of the document types with 'Service Call' in the type name
SELECT `DOCCODE`, `CD`
FROM `DOC_TBL`
JOIN `DOC_TYPE_LST` ON `DOC_TBL`.`DOCCODE` = `DOC_TYPE_LST`.`STD_RPT`
WHERE `NM` LIKE '%Service Call%'
;

-- 8: Show the document code and document name name, and count of reporting elements for each document with the type code 'WTR1'
SELECT `DOC_TBL`.`DOCCODE`, `DOCNAME`, COUNT (*) ELMTCT
FROM `DOC_TBL`
JOIN `RPTNG_ELEM_TBL` ON `DOC_TBL`.`DOCCODE` = `RPTNG_ELEM_TBL`.`DOCCODE`
WHERE `TYPCD` = 'WTR1'
GROUP BY `DOC_TBL`.`DOCCODE`, `DOCNAME`
;

-- 9: Show the Action for extension error, and the number of repetetive areas for documents that require conversion font for email (indicated by 'Y' value).
SELECT `EXTONERR`, `NUMREPARS`
FROM `DOC_TBL`
WHERE `SWPINEMAIL` = 'Y'
;

-- 10: What are the background, foreground, bold, and border red / green / blue values for the reporting elements with a height less than 5 and greater than 0?
SELECT `BGRED`, `BGGREEN`, `BGBLUE`, `FGRED`, `FGGREEN`, `TXT_BLUE`, `MRKRRED`, `MRKRBLUE`, `MRKRGREEN`, `BRDRRED`, `BRDRBLUE`, `BRDRGREEN`
FROM `RPTNG_ELEM_TBL`
WHERE `HGHT` < 5 AND `HGHT` > 0
;

