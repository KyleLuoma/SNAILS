-- 1: How many events were logged in each year?
select year(Event_Date) EventsYear, count(*) eventCount
from tbl_events
group by year(Event_Date)
;

-- 2: What is the average midpoint diameter of deadwood in decay stage 2a?
select avg(MPD) avgDiameter
from tbl_Deadwood
where decay = '2a'
;

-- 3: What are the directions to the Maddron Bald Trail?
select directions
from tbl_Locations
where trail = 'maddron bald trail'
;

-- 4: Show the site description of locations at plots that were in events in 2001
select SiteDescription
from tbl_locations l 
join tbl_events e on e.Location_ID = l.Location_ID 
where year(event_date) = 2001
;

-- 5: Show the genus, species, and common name of plant species observed in nested subpluts of event 30. Include only one row per type
select distinct genus, species, CommonName
from tbl_Nests n
join tlu_PlantSpecies s on n.SpCode = s.SpeciesCode
where Event_ID = 30
;

-- 6: What is the average diamater of overstory of the montana species observed in events 15 and 16
select avg(DBH) avgDiameter
from tbl_events e
join tbl_Overstory o on e.Event_ID = o.Event_ID
join tlu_PlantSpecies s on o.SpCode = s.SpeciesCode
where species = 'montana'
	and e.Event_ID in (15, 16)
;

-- 7: Show all the diamater class 1, 2, 3 and 4 entries for sapplings with species code Abiefra
select spcode, DClass1, DClass2, DClass3, DClass4
from tbl_Saplings
where spcode = 'Abiefra'
;

-- 8: What is the average seedling density of the Acer genus?
select avg(Density) avgSeedlingDensity
from tbl_seedlings s
join tlu_PlantSpecies sp on s.SpCode = sp.SpeciesCode
where genus = 'Acer'
;

-- 9: For each location ID, show the average seedling density of the Acer genus.
select Location_ID, avg(Density) avgSeedlingDensity
from tbl_seedlings s
join tlu_PlantSpecies sp on s.SpCode = sp.SpeciesCode
join tbl_Events e on e.Event_ID = s.Event_ID
where genus = 'Acer'
group by Location_ID
;

-- 10: What are the average north and east universal transvserse mercator coordinates of Sevier County TN?
select avg(utmE) ECentroid, avg(utmN) NCentroid
from tlu_PlaceNames
where County = 'Sevier' and State = 'TN'
;

-- 11: What are the X and Y coordinates, and the species code, of the tree with tag ID 144
select XCoord, Ycoord, SpCode
from tbl_Tree_Tags
where Tree_Tag_ID = 144
;

-- 12: For each tree condition, show the number of trees for trees with a tag number (not tag ID) greater than 220.
select TreeCond, count(*) treeCount
from tbl_Tree_Tags tt
join tbl_Overstory o on o.TreeTag = tt.Tree_Tag_ID
where Tag > 220
group by TreeCond
;

-- 13: Show the tree condition description and the total count of overstory in each condition category.
select TreeCond_Text, count(*) TreeCount
from tlu_Tree_Cond tc
join tbl_Overstory o on o.TreeCond = tc.TreeCond_Num
group by TreeCond_Text
;

-- 14: What is the species code and diameter at breast height of the witness tree that is furthest from the marking stake? Exclude location ID 4 from the result.
select top 1 Witness_SpCode, Witness_DBH
from tbl_WitnessTrees
where Location_ID <> 4
order by Witness_stake desc
;

-- 15: How many overstory's have a codominant canopy position?
select count(*) OverstoryCount
from tlu_Can_Pos c
join tbl_Overstory o on c.CanPos_Num = o.CanPos
where CanPos_Name = 'codominant'
;

-- 16: For each canopy position name, show how many overstory were classified for each position for the species with the common name 'Red Maple'
select CanPos_Name, count(*) OverstoryCount
from tlu_Can_Pos c
join tbl_Overstory o on c.CanPos_Num = o.CanPos
join tlu_PlantSpecies s on s.SpeciesCode = o.SpCode
where CommonName = 'Red maple'
group by CanPos_Name
;

-- 17: For all of the locations with a Midslope topographical position, show the site description, slope, aspect, slope shape, and elevation
select SiteDescription, Slope, Aspect, Slope_shape, Elevation
from tbl_Locations l
join tlu_topo_position p on l.Topo_Position = p.ID
where TopoPosition = 'Midslope'
;

-- 18: What is the species code and cover class text description of the nested subplot with ID 48?
select SpCode, CoverClass_Text
from tbl_Nests n
join tlu_Cover_Cls cc on n.cover = cc.CoverClass_Num
where Nest_ID = 48
;

-- 19: For each decay stage, show the description and the count of dead wood observations
select DecayStage_Descr, count(*) DeadWoodCount
from tlu_DecayStage dc
join tbl_Deadwood dw on dc.DecayStage_ID = dw.Decay
group by DecayStage_Descr
;

-- 20: How many decay stages are there?
select count(*)
from tlu_DecayStage
;

-- 21: Show the length and midpoint diameter of dead wood in the decay stage that has 'log is flat' in the description?
select length, mpd
from tbl_Deadwood dw
join tlu_DecayStage dc on dw.Decay = dc.DecayStage_ID
where DecayStage_Descr like '%log is flat%'
;

-- 22: Show the genus of plant species observed in nested subplots where their presence description included the phrase 'species occurred in rest of plot'.
select genus
from tlu_PlantSpecies sp
join tbl_Nests n on n.SpCode = sp.SpeciesCode
join tlu_R1_RestOfPlot r on n.R1 = r.Pres_Num
where Pres_Text like '%species occurred in rest of plot%'
;

-- 23: How many plant species have the term 'native' in their notes? Show a count of these species by their genus. Only include the five highest results.
select top 5 genus, count(*) speciesCount
from tlu_PlantSpecies
where SpeciesNotes like '%native%'
group by genus
order by count(*) desc
;

-- 24: Show the database title, file name, release notes, author email, and organization name, for the application release that occurred in 2015
select Database_title, File_name, Release_notes, Author_email, Author_org_name
from tsys_App_Releases
where year(release_date) = 2015
;

-- 25: How many different slope shapes are there in the lookup table?
select count(*)
from tlu_Slope_Shape
;

-- 26: For events that occurred in 1999, show the average seedling density by location ID.
select Location_ID, avg(density) seedlingDensity
from tbl_Seedlings s
join tbl_Events e on s.Event_ID = e.Event_ID 
where year(Event_Date) = 1999
group by Location_ID
;

-- 27: What is the average diameter of the fraseri overstory species measurement in each month with an event that measured one?
select month(e.Event_Date) Mon, avg(DBH) avgFraseriDiam
from tbl_Overstory o
join tbl_events e on e.event_id = o.event_id
join tlu_PlantSpecies s on o.SpCode = s.SpeciesCode
where s.species = 'fraseri'
group by month(e.Event_Date)
;

-- 28: Show a count of roads and trails by layer.
select layer, count(*)
from tlu_Roads_and_Trails
group by layer
;

-- 29: Show a count of roads and trails by layer for entries that have the word Balsam in their valid name.
select layer, count(*)
from tlu_Roads_and_Trails
where ValidName like '%Balsam%'
group by layer
;

-- 30: How many places are in each state?
select State, count(*) placeCount
from tlu_PlaceNames
group by state
;

-- 31: What is the name, county, state, and E and N coordinates of the northmost place?
select top 1 Name, County, State, utmE, utmN
from tlu_PlaceNames
order by utmN desc
;

-- 32: For each first presence description text entry, show the number of nested subplots in the event with id 30.
select Pres_Text, count(*) nestCount
from tlu_Presence p
join tbl_Nests n on p.Pres_Num = n.Presence_First
where Event_ID = 30
group by Pres_text
;

-- 33: What is the distance between the highest and lowest X coordinate locations, and the distance between highest and lowest Y coordinate locations?
select max(X_Coord) - min(X_Coord) xDist, max(Y_Coord) - min(Y_Coord) yDist
from tbl_Locations
;

-- 34: What is the Genus, species, and common name of the species with the highest seedling density?
select top 1 Genus, species, CommonName
from tbl_Seedlings s
join tlu_PlantSpecies sp on s.SpCode = sp.SpeciesCode
order by density desc
;

-- 35: Which month has the highest average seedling density?
select top 1 month(Event_Date)
from tbl_seedlings s
join tbl_Events e on s.Event_ID = e.Event_ID
group by month(Event_Date)
order by avg(Density) desc
;

-- 36: How many of each tree species have tree tags at location with ID 2? Show the counts by common species name.
select CommonName, count(*) tagCount
from tbl_Tree_Tags tg
join tlu_PlantSpecies sp on tg.SpCode = sp.SpeciesCode
where Location_ID = 2
group by CommonName
;

-- 37: How many of each tree species have tree tags at locations abobe 4000 feet? Show the counts by genus and common species name.
select genus, CommonName, count(*) tagCount
from tbl_Tree_Tags tg
join tlu_PlantSpecies sp on tg.SpCode = sp.SpeciesCode
join tbl_Locations l on tg.Location_ID = l.Location_ID
where Elevation > 4000
group by genus, CommonName
;

-- 38: Show the ecology notes, coordinate units, coordinate system, and datum for the location on plot A14_1
select Eco_notes, coord_units, Coord_system, datum
from tbl_locations
where Plot_ID = 'A14_1'
;

-- 39: What are the location notes for the location that has the phrase 'probably post logging' in the other disturbance entry?
select loc_notes
from tbl_locations
where Other_Disturbance like '%probably post logging%'
;

-- 40: How many events had both overstory and deadwood entries?
select count(distinct Event_ID) eventCount
from tbl_Deadwood d
where d.Event_ID in (select event_id from tbl_Overstory)
;
