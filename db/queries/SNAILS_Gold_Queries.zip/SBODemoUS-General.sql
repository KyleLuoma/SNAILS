-- 1: Show the description and expected costs of project management stages with start dates before october 20th, 2021.
select DSCRIPTION, EXPCOSTS
from PMG1
where START < '2021-10-20'
;

-- 2: What values are associated with the dictionary key 'HomePage'?
select _Value
from CDIC
where _Key like 'HomePage'
;

-- 3: How many queries does the dashboard entry with code DAB002 have?
select count(*) queryCount
from ODAB
join DAB1 on ODAB.AbsEntry = DAB1.DsbEntry
where DashbdCode = 'DAB002'
;

-- 4: Show the Dashboard name, dashboard path, status, and query name for dashboards and their queries where the query category is 2
select DashbdName, DashbdPath, Status, QryName
from ODAB
join DAB1 on ODAB.AbsEntry = DAB1.DsbEntry
where QryCtgry = 2
;

-- 5: Show the code, name, and number of fields for key performance indicator sets of type P
select KpsCode, KpsName, FieldsNum
from OKPS
where KpsType = 'P'
;

-- 6: What is the resource name, type, group code, and resource cost 1 of the employee resource with employee ID 9? 
select ResName, ResType, ResGrpCod, StdCost1
from ORSC
join RSC4 on ORSC.ResCode = RSC4.ResCode
where EmpId = 9
;

-- 7: what is the average daily capacity factor 1 of the resource named 'Testing Machine' on weekdays 1 through 5?
select avg(CapFactor1) avgCapacity
from ORSC
join RSC6 on ORSC.ResCode = RSC6.ResCode
where ResName = 'Testing Machine' and WeekDay >= 1 and WeekDay <= 5
;

-- 8: Show the project name and open issue remarks, and open issue solution for projects that have open issues.
select NAME, REMARKS, SOLUTION
from OPMG
join PMG2 on OPMG.AbsEntry = PMG2.AbsEntry
;

-- 9: Show the cockpit subtable left, right, top, and bottom values for the cockpit named purchase
select CPT1._left, CPT1._right, CPT1._top, CPT1._bottom
from OCPT
join CPT1 on OCPT.AbsEntry = CPT1.AbsEntry
where Name = 'Purchase'
;

-- 10: What are the table names of business object briefs with the description fields that have the word Memo in them?
select TableName
from OBOB
where DescField like '%Memo%'
;