-- 1: How many items with the name 'USB Flashdrive 128GB' are on hand, committed, and on order?
select OnHand, IsCommited, OnOrder
from OITM
where ItemName = 'USB Flashdrive 128GB'
;

-- 2: What is the number of commited items, the price-per-item, and the total price of the commited items for the item called 'Memory Chip?
select IsCommited, Price, IsCommited * Price as totalPrice
from OITM
join ITM1 on OITM.ItemCode = ITM1.ItemCode
where ItemName = 'Memory Chip'
;

-- 3: For the vendor with vendor code V1010, show item names, consignment numbers, and last purchase price for items where the vendor is preferred. 
select ItemName, Consig, LastPurPrc
from ITM2
join OITM on ITM2.ItemCode = OITM.ItemCode
where VendorCode = 'V1010'
;

-- 4: For the item named 'Printer Paper A4 White', show the package dimensions including height 1, width 1, length 1, and volume, for the packaging that holds a quantity of 24. 
select height1, width1, length1, volume from ITM4
join OITM on ITM4.ItemCode = OITM.ItemCode
where itemname = 'Printer Paper A4 White'
      and QtyPerPack = 24
;

-- 5: What is the useful life, remaining life, and remaining day parameters for the item that uses depreciation area 'GAAP'?
select UsefulLife, RemainLife, RemainDays
from ITM7
where DprArea = 'GAAP'
;

-- 6: What is the volume of the box package type?
select volume
from OPKG
where PkgType = 'Box'
;

-- 7: What are the barcodes for the item named 'Printer Paper A4 White' with unit of measurement entries that are either 3 or 4?
select BcdCode 
from OITM
join OBCD on OITM.ItemCode = OBCD.ItemCode
where ItemName =  'Printer Paper A4 White'
      and UomEntry in (3, 4)
;

-- 8: Show the display names, data source, and updated date of bin field configurations that are activated (activated code = 'Y')
select DispName, DataSource, UpdateDate
from OBFC
where activated = 'Y'
;

-- 9: Display a count of items for each item group. Include the item group name and count of items in the result.
select ItmsGrpNam, count(*) ItmCt
from OITM
join OITB on OITM.ItmsGrpCod = OITB.ItmsGrpCod
group by ItmsGrpNam
;

-- 10: What is the average volume of items in the 'Items' Item group?
select avg(volume) avgVolume
from OITM
join OITB on OITM.ItmsGrpCod = OITB.ItmsGrpCod
join ITM4 on OITM.ItemCode = ITM4.ItemCode
where ItmsGrpNam = 'Items'
;
