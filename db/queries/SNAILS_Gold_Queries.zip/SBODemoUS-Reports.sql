-- 1: Show the parameter names and parameter parameters for the parameters with the description 'Electronic documents'
select ParamName, ParamPrms
from OECM
join ECM1 on OECM.Code = ECM1.Code
where Descr = 'Electronic documents'
;

-- 2: Get the field and object type xpaths for the mapping determinations associated with parameters with the description 'PEPPOL'.
select ObjXPath, FieldXPath
from ECM4
join OECM on ECM4.Code = OECM.Code
where Descr = 'PEPPOL'
;

-- 3: How many queries are there in each category?
select QCategory, count(*) qCount
from OUQR
group by QCategory
;

-- 4: Display the group description, log instance, the updated date, and the created date of the query group with the code 'Group4'
select AUTHGRPN, LogInstanc, UpdateDate, CreateDate
from OQAG
where AUTHGRPCD = 'Group4'
;

-- 5: What is the widest document width for documents with a grid size of 10?
select top 1 Width
from RDOC
where GridSize = 10
order by width desc
;

-- 6: What are the type codes and screen fonts for documents that use the email font 'Tahoma'?
select TypeCode, ScreenFont
from RDOC
where EmailFont = 'Tahoma'
;

-- 7: Show the document code, and the document type code of the document types with 'Service Call' in the type name
select DocCode, CODE 
from RDOC
join RTYP on RDOC.DocCode = RTYP.DEFLT_REP
where NAME like '%Service Call%'
;

-- 8: Show the document code and document name name, and count of reporting elements for each document with the type code 'WTR1'
select RDOC.DocCode, DocName, count(*) elmtCt
from RDOC
join RITM on RDOC.DocCode = RITM.DocCode
where TypeCode = 'WTR1'
group by RDOC.DocCode, DocName
;

-- 9: Show the Action for extension error, and the number of repetetive areas for documents that require conversion font for email (indicated by 'Y' value).
select ExtOnErr, NumRepArs
from RDOC
where SwpInEmail = 'Y'
;

--10: What are the background, foreground, bold, and border red / green / blue values for the reporting elements with a height less than 5 and greater than 0?
select BGRed, BGGreen, BGBlue, FGRed, FGGreen, FGBlue, MrkrRed, MrkrBlue, MrkrGreen, BrdrRed, BrdrBlue, BrdrGreen
from RITM
where height < 5 and height > 0
;

