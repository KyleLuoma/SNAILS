-- 1: How many service contract items are there for each service contract? Include the contract ID in the result.
select OCTR.ContractID, count(*) itemCount
from OCTR
join CTR1 on OCTR.ContractID = CTR1.ContractID
group by OCTR.ContractID
;

-- 2: What is the renewal status of the contracts with the customer named 'Maxi-Teq'? Include the contract ID and the status in the result.
select ContractID, Renewal
from OCTR
where CstmrName = 'Maxi-Teq'
;

-- 3: For each state in the country US, show a count of entries in the customer equipment card table
select state, count(*) entryCount
from OINS
where country = 'US'
group by state
;

-- 4: What is the customer equipment item name of the item with code S10000? Include only one result in the output.
select distinct itemName
from OINS
where itemCode = 'S10000'
;

-- 5: For each queue, show the description, manager, and email address
select descript, manager, email
from OQUE
;

-- 6: How many service calls are there per customer where the priority is medium? (value M) Include the custmer ID and customer name
select customer, custmrName, count(*) callCount
from OSCL
where priority = 'M'
group by customer, custmrName
;

-- 7: Show the assigned date, response date, and resolved date of service calls that originated on the web
select AssignDate, respOnDate, resolOnDat
from OSCL
join OSCO on OSCL.origin = OSCO.originID
where OSCO.Name = 'Web'
;

-- 8: what is the business partner shipping and billing address and email for the customer named 'Aquent Systems'. Display only one row per unique result.
select distinct BPShipAddr, BPBillAddr, BPE_Mail
from OSCL
where custmrName = 'Aquent Systems'
;

-- 9: Show the number of service calls for customer with the 'Silver Warranty' contract template. Include the customer name and count of calls in the result.
select CstmrName, count(*) callCount
from OCTR
join OSCL on OCTR.CstmrCode = OSCL.customer
group by CstmrName
;

-- 10: What are the internal serial numbers of the service contract with the customer named microhips and the iten code A00006?
select internalSN
from OINS
where custmrName = 'Microchips' and itemCode = 'A00006'
;

