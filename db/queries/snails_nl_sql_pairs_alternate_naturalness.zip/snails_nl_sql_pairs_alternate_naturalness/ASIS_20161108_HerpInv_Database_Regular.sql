-- 1: How many five year old turtles were measured?
SELECT COUNT (*) TURTLECOUNT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
WHERE [AGE] = '5'
;

-- 2: How many turtles were measured at each location where turtles were measured?
SELECT [LOCATION_ID_CODE], COUNT (*) TURTLECOUNT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
GROUP BY [LOCATION_ID_CODE]
;

-- 3: what is the average weight of all turtles?
SELECT AVG ([WEIGHT]) TURTLEWEIGHT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
;

-- 4: at which locations were both snakes and turtles measured?
SELECT DISTINCT [T].[LOCATION_ID_CODE]
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA] T
JOIN [TABLE_FIELD_DATA_SNAKE_SURVEY] S ON [T].[LOCATION_ID_CODE] = [S].[LOCATION_ID_CODE]
;

-- 5: How many minnow traps are there at each location?
SELECT [LOCATION_ID_CODE], COUNT (DISTINCT [TRAP_#]) TRAPCOUNT
FROM [TABLE_FIELD_DATA_MINNOW_TRAP_SURVEYS]
GROUP BY [LOCATION_ID_CODE]
;

-- 6: show the total number of minnows counted at each location
SELECT [LOCATION_ID_CODE], SUM ([COUNT]) MINNOWCOUNTSUM
FROM [TABLE_FIELD_DATA_MINNOW_TRAP_SURVEYS]
GROUP BY [LOCATION_ID_CODE]
;

-- 7: show the total number of minnows counted at each trap by location. Each location has multiple traps.
SELECT [LOCATION_ID_CODE], [TRAP_#], SUM ([COUNT]) MINNOWCOUNTSUM
FROM [TABLE_FIELD_DATA_MINNOW_TRAP_SURVEYS]
GROUP BY [LOCATION_ID_CODE], [TRAP_#]
;

-- 8: show how many minnows of each stage were counted at the location ASIS_HERPS_20H
SELECT [STAGE], SUM ([COUNT]) MINNOWCOUNTSUM
FROM [TABLE_FIELD_DATA_MINNOW_TRAP_SURVEYS]
WHERE [LOCATION_ID_CODE] = 'ASIS_HERPS_20H'
GROUP BY [STAGE]
;

-- 9: What is the average water temperature (celcius) at locations where amphibians were counted?
SELECT AVG ([TEMPERATURECELSIUS]) AVGTEMP
FROM [TABLE_FIELD_DATA_WATER_PROPERTIES]
WHERE [LOCATION_ID_CODE] IN (SELECT [LOCATION_ID_CODE]
FROM [TABLE_FIELD_DATA_AMPHIBIAN_CALL_COUNTS])
;

-- 10: Show the average temperature, salinity, conductivity, and pH level of the water at locations corresponding to turtle observation records.
SELECT AVG ([TEMPERATURECELSIUS]) AVGTEMPC, AVG ([SALINITY]) AVGSALINITY, AVG ([CONDUCTIVITY]) AVGCONDUCT, AVG ([PH]) AVGPH
FROM [TABLE_FIELD_DATA_WATER_PROPERTIES] W, [TABLE_FIELD_DATA_TURTLE_TRAP_SURVEYS] T
WHERE [W].[RECORDID] IN (SELECT [RECORDID]
FROM [TABLE_FIELD_DATA_TURTLE_TRAP_SURVEYS])
;

-- 11: Make a list of turtle record IDs and measurement comments where the trap survey sex data did not match the measurement sex data.
SELECT [T].[RECORDID], [M].[COMMENTS]
FROM [TABLE_FIELD_DATA_TURTLE_TRAP_SURVEYS] T
JOIN [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA] M ON [T].[RECORDID] = [M].[RECORDID] AND [M].[SEX] <> [T].[SEX]
;

-- 12: show the heaviest turtle for each sex
SELECT [SEX], MAX ([WEIGHT]) HEAVIESTWEIGHT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
GROUP BY [SEX]
;

-- 13: what is the highest snake snout-to-vent length recorded?
SELECT TOP 1 [SNOUT_TO_VENT_LENGTH]
FROM [TABLE_FIELD_DATA_SNAKE_SURVEY]
ORDER BY [SNOUT_TO_VENT_LENGTH] DESC
;

-- 14: Show the average snake weight and snout-to-vent length by sex.
SELECT [SEX], AVG ([WEIGHT]) AVGWEIGHT, AVG ([SNOUT_TO_VENT_LENGTH]) AVGSVL
FROM [TABLE_FIELD_DATA_SNAKE_SURVEY]
GROUP BY [SEX]
;

-- 15: show the average snake total length and weight by species.
SELECT [SPECIES_CODE], AVG ([TOTALLENGTH]) AVGTLENGTH, AVG ([WEIGHT]) AVGWEIGHT
FROM [TABLE_FIELD_DATA_SNAKE_SURVEY]
GROUP BY [SPECIES_CODE]
;

-- 16: Show a count of turtle measurements made by each agency.
SELECT [AGENCY/TITLE], COUNT (DISTINCT [RECORDID])
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA] T
JOIN [TABLE_LINK_OBSERVERS_SAMPLING_EVENTS] OL ON [T].[EVENTID] = [OL].[EVENTID]
JOIN [OBSERVER_LOOKUP_TABLE] O ON [O].[OBSERVER_INITIALS] = [OL].[OBSERVER_INITIALS]
GROUP BY [AGENCY/TITLE]
;

-- 17: Make a list of all event IDs from 2004 that were observed by Allison Turner
SELECT [E].[EVENTID]
FROM [TABLE_EVENTS] E
JOIN [TABLE_EVENT_DATA_HERPS] ED ON [E].[EVENTID] = [ED].[EVENTID]
JOIN [TABLE_LINK_OBSERVERS_SAMPLING_EVENTS] OL ON [ED].[EVENTID] = [OL].[EVENTID]
JOIN [OBSERVER_LOOKUP_TABLE] O ON [OL].[OBSERVER_INITIALS] = [O].[OBSERVER_INITIALS]
WHERE [YEAR] = 2004 AND [FIRSTNAME] = 'allison' AND [LASTNAME] = 'turner'
;

-- 18: Which observers participated in events where measurements of turtle were made? Show their initials, and first and last names.
SELECT DISTINCT [O].[OBSERVER_INITIALS], [FIRSTNAME], [LASTNAME]
FROM [TABLE_LINK_OBSERVERS_SAMPLING_EVENTS] OL
JOIN [OBSERVER_LOOKUP_TABLE] O ON [OL].[OBSERVER_INITIALS] = [O].[OBSERVER_INITIALS]
JOIN [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA] TM ON [TM].[EVENTID] = [OL].[EVENTID]
;

-- 19: how many distinct species were documented on a reptile survey green card?
SELECT COUNT (DISTINCT [SPECIES_CODE]) SPECIESCOUNT
FROM [TABLE_FIELD_DATA_GREEN_CARD_OBSERVATIONS]
;

-- 20: what are the Universal Transverse Mercator x and y coordinates for locations where time constrained searches were conducted? Include the location ID and x and y point coordinate averages in the result.
SELECT [L].[LOCATION_ID_CODE], AVG ([UNIVERSAL_TRANSVERSE_MERCATOR_XCOORDINATE]) X, AVG ([UNIVERSAL_TRANSVERSE_MERCATOR_YCOORDINATE]) Y
FROM [TABLE_FIELD_DATA_TIME_CONSTRAINED_SEARCH_SURVEYS] DF
JOIN [TABLE_LOCATIONS_POINTS] L ON [DF].[LOCATION_ID_CODE] = [L].[LOCATION_ID_CODE]
GROUP BY [L].[LOCATION_ID_CODE]
;

-- 21: show a count of minnow measurements by stage description
SELECT [DESCRIPTION], COUNT (*) MINNOWCOUNT
FROM [TABLE_LOOKUP_LIFE_STAGE] S
JOIN [TABLE_FIELD_DATA_MINNOW_TRAP_SURVEYS] M ON [S].[STAGE] = [M].[STAGE]
GROUP BY [DESCRIPTION]
;

-- 22: What is the ID and description of the occasional abundance category?
SELECT [ABUNDANCEID], [ABUNDANCETEXT]
FROM [TABLE_ABUNDANCE_LOOKUP]
WHERE [ABUNDANCE] = 'Occasional'
;

-- 23: What are the location IDs of locations that have covers made out of wood? Only include one row per location ID.
SELECT DISTINCT [LOCATION_ID_CODE]
FROM [TABLE_FIELD_DATA_COVERBOARD_SURVEYS]
WHERE [TYPE] = 'Wood'
;

-- 24: Show the board number and types for boards at site with ID 18CB1. Ignore boards with a number 0.
SELECT [BOARD_#], [TYPE]
FROM [TABLE_FIELD_DATA_COVERBOARD_SURVEYS] CB
JOIN [TABLE_LOCATIONS] L ON [CB].[LOCATION_ID_CODE] = [L].[LOCATION_ID_CODE]
WHERE [SITEID] = '18CB1' AND [BOARD_#] <> 0
;

-- 25: Show the average air temperature on cloudy days that correspond to cover board  data where the board material is wood at the site with id 30CB2
SELECT AVG ([AIRTEMPERATURE]) AS AVGTEMP
FROM [TABLE_FIELD_DATA_COVERBOARD_SURVEYS] CB
JOIN [TABLE_EVENT_DATA_HERPS] EV ON [CB].[EVENTID] = [EV].[EVENTID]
JOIN [TABLE_LOCATIONS] L ON [CB].[LOCATION_ID_CODE] = [L].[LOCATION_ID_CODE]
WHERE [TYPE] = 'Metal' AND [SITEID] = '30CB2' AND [WEATHER] = 'cloudy'
;

-- 26: For each behavior type, how many records were documented for snakes captured using the coverboard method?
SELECT [BEHAVIOR], COUNT (*) AS RECORDCOUNT
FROM [TABLE_FIELD_DATA_SNAKE_SURVEY]
WHERE [CAPTUREMETHOD] = 'coverboard'
GROUP BY [BEHAVIOR]
;

-- 27: what were the behaviors and capture methods of snakes where the record notes include the word rafters?
SELECT [BEHAVIOR], [CAPTUREMETHOD]
FROM [TABLE_FIELD_DATA_SNAKE_SURVEY]
WHERE [NOTES] LIKE '%rafters%'
;

-- 28: for location points associated with records relating to cover boards, at the site with id 18CB1, what are the point IDs, snake ids, board numbers, and UTM X and Y coordinates?
SELECT [SEQUENTIAL_NUMBER_OF_POINTS], [SNAKEID], [BOARD_#], [UNIVERSAL_TRANSVERSE_MERCATOR_XCOORDINATE], [UNIVERSAL_TRANSVERSE_MERCATOR_YCOORDINATE]
FROM [TABLE_FIELD_DATA_COVERBOARD_SURVEYS] CB
JOIN [TABLE_LOCATIONS] L ON [CB].[LOCATION_ID_CODE] = [L].[LOCATION_ID_CODE]
JOIN [TABLE_LOCATIONS_POINTS] LP ON [L].[LOCATION_ID_CODE] = [LP].[LOCATION_ID_CODE]
WHERE [RECAPTURE] = 'new' AND [SITEID] = '18CB1'
;

-- 29: What are the initials of observers who logged events relating to cover board observations? Include only one row per initials.
SELECT DISTINCT [O].[OBSERVER_INITIALS]
FROM [OBSERVER_LOOKUP_TABLE] O
JOIN [TABLE_LINK_OBSERVERS_SAMPLING_EVENTS] TLO ON [O].[OBSERVER_INITIALS] = [TLO].[OBSERVER_INITIALS]
JOIN [TABLE_EVENTS] E ON [TLO].[EVENTID] = [E].[EVENTID]
JOIN [TABLE_FIELD_DATA_COVERBOARD_SURVEYS] CB ON [E].[EVENTID] = [CB].[EVENTID]
;

-- 30: Show a count of events in the herpetological survey table, group the counts by weather condition. Also include the average air and water temperatures.
SELECT [WEATHER], COUNT (*) EVENTCOUNT, AVG ([AIRTEMPERATURE]) AVGAIRTEMP, AVG ([WATERTEMPERATURE]) AVGWATERTEMP
FROM [TABLE_EVENT_DATA_HERPS]
GROUP BY [WEATHER]
;

-- 31: Show the average air temperature for herpetological surveys for each observer. Group them by the initials of the observer who logged the event.
SELECT [O].[OBSERVER_INITIALS], AVG ([AIRTEMPERATURE]) AVGAIRTEMP
FROM [OBSERVER_LOOKUP_TABLE] O
JOIN [TABLE_LINK_OBSERVERS_SAMPLING_EVENTS] TLO ON [O].[OBSERVER_INITIALS] = [TLO].[OBSERVER_INITIALS]
JOIN [TABLE_EVENT_DATA_HERPS] E ON [TLO].[EVENTID] = [E].[EVENTID]
GROUP BY [O].[OBSERVER_INITIALS]
;

-- 32: what is the average air temperature for each weather type for herpetological survey events?
SELECT [WEATHER], AVG ([AIRTEMPERATURE]) AVGAIRTEMP
FROM [TABLE_EVENT_DATA_HERPS]
GROUP BY [WEATHER]
;

-- 33: what is the description of project code WQ?
SELECT [DESCRIPTION]
FROM [TABLE_LOOKUP_HERPETOLOGICAL_SURVEY_PROJECTS]
WHERE [PROJECT] = 'WQ'
;

-- 34: What type of park is the park with code ASIS?
SELECT [PARKTYPE]
FROM [TABLE_LOOKUP_PARK_CODE]
WHERE [PARKCODE] = 'ASIS'
;

-- 35: What does the evidence code DOR mean?
SELECT [TEXT]
FROM [TABLE_LOOKUP_EVIDENCE_CODE]
WHERE [EVIDENCE_CODE] = 'DOR'
;

-- 36: Show the habitat names and descriptions of the 'Temporary Pond' and 'Permanent Pond' micro habitats.
SELECT [HABITAT], [DESCRIPTION]
FROM [TABLE_LOOKUP_MICROHABITAT_TYPES]
WHERE [HABITAT] IN ('Temporary Pond', 'Permanent Pond')
;

-- 37: How many records are logged for each turtle trap type?
SELECT [TRAP_TYPE], COUNT (*) RECORDCOUNT
FROM [TABLE_FIELD_DATA_TURTLE_TRAP_SURVEYS]
GROUP BY [TRAP_TYPE]
;

-- 38: Which location IDs have crab type turtle traps? Include only one row per location.
SELECT DISTINCT [T].[LOCATION_ID_CODE]
FROM [TABLE_LOCATIONS] L
JOIN [TABLE_FIELD_DATA_TURTLE_TRAP_SURVEYS] T ON [L].[LOCATION_ID_CODE] = [T].[LOCATION_ID_CODE]
WHERE [TRAP_TYPE] = 'crab'
;

-- 39: What are the average turtle dimensions by sex? Include carapace length and width, plastron length and width, and weight.
SELECT [SEX], AVG ([CARAPACE_LENGTH]) AVGCARLEN, AVG ([CARAPACE_WIDTH]) AVGCARWID, AVG ([PLASTRON_LENGTH]) AVGPLASLEN, AVG ([PLASTRON_WIDTH]) AVGPLASWID, AVG ([WEIGHT]) AVGWEIGHT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
GROUP BY [SEX]
;

-- 40: how many turtle measurements were of turtles carrying eggs or young? This is indicated by the value 1.
SELECT COUNT (*) GRAVIDCOUNT
FROM [TABLE_FIELD_DATA_TURTLE_MEASUREMENT_FIELD_DATA]
WHERE [IS_GRAVID] = 1
;

