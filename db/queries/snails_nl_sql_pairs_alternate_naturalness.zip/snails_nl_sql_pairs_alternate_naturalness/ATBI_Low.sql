-- 1: What tree species have been observed within nested subplots? Show the species code, genus, sub genus, and common name.
SELECT DISTINCT [CMN_NAME], [SPCODE], [GNUS], [SUBGNUS]
FROM [TBL_NESTS]
JOIN [TLU_PLANTSPECIES] ON [TBL_NESTS].[SPCODE] = [TLU_PLANTSPECIES].[SP_CODE]
ORDER BY [CMN_NAME]
;

-- 2: Are there any tree species that have not been observed within nested subplots? What are their common names?
SELECT DISTINCT [CMN_NAME]
FROM [TLU_PLANTSPECIES]
WHERE [SP_CODE] NOT IN (SELECT DISTINCT [SPCODE]
FROM [TBL_NESTS])
;

-- 3: What are the five most common geni observed in nested subplots and how many nested subplotes have they been observed in?
SELECT TOP 5 [GNUS], COUNT (*) AS NESTCOUNT
FROM [TLU_PLANTSPECIES]
JOIN [TBL_NESTS] ON [TLU_PLANTSPECIES].[SP_CODE] = [TBL_NESTS].[SPCODE]
GROUP BY [GNUS]
ORDER BY [NESTCOUNT] DESC
;

-- 4: Show me the different decay stages and their descriptions
SELECT *
FROM [TLU_DECAYSTAGE]
;

-- 5: How many events observed at least some stage of decay?
SELECT COUNT (DISTINCT [EVT_ID])
FROM [TBL_DEADWOOD]
;

-- 6: How many different decayed logs were found in each event where decay was observed?
SELECT [EVT_ID], COUNT (*)
FROM [TBL_DEADWOOD]
GROUP BY [EVT_ID]
;

-- 7: For the event that observed the most decayed logs, how many of each stage of decay were observed? Show the description of each decay stage in the result.
SELECT [DECAYSTAGE_DESCR], COUNT (*) AS NUMLOGS
FROM [TBL_DEADWOOD]
JOIN [TLU_DECAYSTAGE] ON [TBL_DEADWOOD].[DECY] = [TLU_DECAYSTAGE].[DCYSTG_ID]
WHERE [EVT_ID] IN (SELECT TOP 1 [EVT_ID]
FROM [TBL_DEADWOOD]
GROUP BY [EVT_ID]
ORDER BY COUNT (*) DESC)
GROUP BY [DECAYSTAGE_DESCR]
;

-- 8: Show me the events where both nested subplots and decayed logs were observed. Include the number of decayed logs, and the number of nested subplots were observed.
SELECT [E].[EVT_ID], [DEADWOOD_COUNT], [NEST_COUNT]
FROM [TBL_EVENTS] AS E
JOIN (SELECT [EVT_ID], COUNT (*) AS DEADWOOD_COUNT
FROM [TBL_DEADWOOD]
GROUP BY [EVT_ID]) AS DW ON [E].[EVT_ID] = [DW].[EVT_ID]
JOIN (SELECT [EVT_ID], COUNT (*) AS NEST_COUNT
FROM [TBL_NESTS]
GROUP BY [EVT_ID]) AS NE ON [E].[EVT_ID] = [NE].[EVT_ID]
ORDER BY [DEADWOOD_COUNT] DESC
;

-- 9: Get the Plot ID, x and y coordinates, and directions for the location with the event that has the most nested subplot observations
SELECT [PLT_ID], [X_COORD], [Y_COORD], [DIRCTNS]
FROM [TBL_LOCATIONS] L
JOIN [TBL_EVENTS] E ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE [E].[EVT_ID] IN (SELECT TOP 1 [EVT_ID]
FROM [TBL_NESTS]
GROUP BY [EVT_ID]
ORDER BY COUNT (*))
;

-- 10: What is the average diameter at breast height for  trees of the Acer genus?
SELECT AVG ([DIAM_BRST_HT]) AVGDBH
FROM [TBL_OVERSTORY] O
JOIN [TLU_PLANTSPECIES] P ON [O].[SPCODE] = [P].[SP_CODE]
WHERE [GNUS] = 'Acer'
;

-- 11: What is the canopy position name and the count of trees for each canopy position
SELECT [CANPOS_NAME], COUNT (*) AS TREECOUNT
FROM [TLU_CAN_POS] P
JOIN [TBL_OVERSTORY] O ON [P].[CANPOS_NUMBER] = [O].[CANPOS]
GROUP BY [CANPOS_NAME]
;

-- 12: Create a list of trees where their condition is 'down'. Include the tree tag number, and species common name.
SELECT [CMN_NAME], [TRTAG]
FROM [TLU_PLANTSPECIES] S
JOIN [TBL_OVERSTORY] O ON [S].[SP_CODE] = [O].[SPCODE]
JOIN [TLU_TREE_COND] C ON [O].[TREECOND] = [C].[TREECOND_NUM]
WHERE [TREECOND_TEXT] = 'down'
;

-- 13: Get a count of saplings entries for each species code for species with more than 20 saplings entries
SELECT [SPCODE], COUNT (*) AS SAPLINGCOUNT
FROM [TBL_SAPLINGS]
GROUP BY [SPCODE]
HAVING COUNT (*) > 20
;

-- 14: How many saplings records are there that have an entry higher than 10 in the diameter class 3 field?
SELECT COUNT (*) AS SAPLINGCOUNT
FROM [TBL_SAPLINGS]
WHERE [DIAMCLASS3] > 10
;

-- 15: What is the highest seedling density for each species code?
SELECT [SPCODE], MAX ([DNSTY]) SEEDLINGDENSITY
FROM [TBL_SEEDLINGS]
GROUP BY [SPCODE]
;

-- 16: How many events recorded seedling density data?
SELECT COUNT (DISTINCT [EVT_ID]) EVENTCOUNT
FROM [TBL_SEEDLINGS]
;

-- 17: What are the directions to the plot where the tree with tag number 6 is located?
SELECT [DIRCTNS]
FROM [TBL_TREE_TAGS] T
JOIN [TBL_LOCATIONS] L ON [T].[LOC_ID] = [L].[LOC_ID]
WHERE [TREE_TAG_ID] = 6
;

-- 18: Show the description and location notes for locations higher than 4000 feet in elevation
SELECT [SITEDESC], [LOC_NOTES]
FROM [TBL_LOCATIONS]
WHERE [ELEV] > 4000
;

-- 19: For each event ID, show the count of nested sub plots for each cover class text description.
SELECT [EVT_ID], [CVRCLS_TXT], COUNT (*) NESTCOUNT
FROM [TLU_COVER_CLS] CC
JOIN [TBL_NESTS] N ON [CC].[COVERCLASS_NUM] = [N].[COVR]
GROUP BY [EVT_ID], [CVRCLS_TXT]
;

-- 20: Show the azimuth and distance from the witness tree stake to the tree for trees with a diameter at breast height of less than 30
SELECT [WTNS_AZMT], [WTNSS_STK]
FROM [TBL_WITNESSTREES]
WHERE [WTNSS_DIAM_BRST_HT] < 30
;

-- 21: For each genus and species, get the total number of witness trees observed.
SELECT [GNUS], [SPEC], COUNT (*) TREECOUNT
FROM [TLU_PLANTSPECIES] S
JOIN [TBL_WITNESSTREES] W ON [S].[SP_CODE] = [W].[WITNESS_SPCODE]
GROUP BY [GNUS], [SPEC]
;

-- 22: What are the listed and valid names of the trail adjacent to the location associated with event id 2?
SELECT [LSTD_NM], [VLD_NM]
FROM [TLU_ROADS_AND_TRAILS] RT
JOIN [TBL_LOCATIONS] L ON [L].[TRL] = [RT].[LSTD_NM]
JOIN [TBL_EVENTS] E ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE [E].[EVT_ID] = 2
;

-- 23: Show a count of tree tags by state and county.
SELECT [STAT], [CNTY], COUNT (*) TAGCOUNT
FROM [TLU_PLACENAMES] PN
JOIN [TBL_LOCATIONS] L ON [PN].[ID] = [L].[PLCNMID]
JOIN [TBL_TREE_TAGS] TG ON [L].[LOC_ID] = [TG].[LOC_ID]
GROUP BY [STAT], [CNTY]
;

-- 24: What are the East and North Universal Transverse Mercator coordinates for the locations in Blount county? Include the location name.
SELECT [NAM], [UTMEASTING], [UTMNORTHING]
FROM [TLU_PLACENAMES]
WHERE [CNTY] = 'Blount'
;

-- 25: Show the topographic position description from the topographic position lookup table for the location with X coordinate 269647 and Y coordinate 3943851
SELECT [T].[TOPOPOSITION]
FROM [TLU_TOPO_POSITION] T
JOIN [TBL_LOCATIONS] L ON [L].[TOPO_POSITION] = [T].[ID]
WHERE [X_COORD] = 269647 AND [Y_COORD] = 3943851
;

-- 26: what is the condition number for the 'Dead' condition text entry?
SELECT [COND_NUM]
FROM [TLU_LIVE_DEAD]
WHERE [COND_TEXT] = 'Dead'
;

-- 27: What is the text entry for presence number 3?
SELECT [PRES_TEXT]
FROM [TLU_PRESENCE]
WHERE [PRES_NUM] = 3
;

-- 28: What is the default datum for this project?
SELECT [DTM]
FROM [TSYS_APP_DEFAULTS]
;

-- 29: Make a list of genus, species, and common name, for overstory (trees) in Swain county. Include only one row per distinct combination.
SELECT DISTINCT [GNUS], [SPEC], [CMN_NAME]
FROM [TLU_PLANTSPECIES] SP
JOIN [TBL_OVERSTORY] OS ON [SP].[SP_CODE] = [OS].[SPCODE]
JOIN [TBL_TREE_TAGS] TT ON [TT].[TREE_TAG_ID] = [OS].[TRTAG]
JOIN [TBL_LOCATIONS] L ON [L].[LOC_ID] = [TT].[LOC_ID]
JOIN [TLU_PLACENAMES] PN ON [PN].[ID] = [L].[PLCNMID]
WHERE [CNTY] = 'Swain'
;

-- 30: Which tree species were recorded as mature overstory but not as saplings? Include the species name and common name.
SELECT [SPEC], [CMN_NAME]
FROM [TLU_PLANTSPECIES] SP
WHERE EXISTS (SELECT [OVRSTRY_ID]
FROM [TBL_OVERSTORY]
WHERE [SPCODE] = [SP].[SP_CODE]) AND NOT EXISTS (SELECT [SEEDLGS_ID]
FROM [TBL_SEEDLINGS]
WHERE [SPCODE] = [SP].[SP_CODE])
;

-- 31: What are the x an y coordinates for the tree with tag 652?
SELECT [XCOORD], [YCOORD]
FROM [TBL_TREE_TAGS]
WHERE [TG] = 652
;

-- 32: For each cover class text description, how many nested subplots records are there?
SELECT [CVRCLS_TXT], COUNT (*) NESTEDSUBPLOTCOUNT
FROM [TBL_NESTS] N
JOIN [TLU_COVER_CLS] R2 ON [N].[COVR_CLSS_R2] = [R2].[COVERCLASS_NUM]
GROUP BY [CVRCLS_TXT]
;

-- 33: For each presence class text description, how many nested subplots records are there where the presence class is the presence class of species in the firsted nested corner within a module?
SELECT [PRES_TEXT], COUNT (*) NESTEDSUBPLOTCOUNT
FROM [TBL_NESTS] N
JOIN [TLU_PRESENCE] P ON [N].[PRES_FRST] = [P].[PRES_NUM]
GROUP BY [PRES_TEXT]
;

-- 34: What is the highest midpoint diameter (in meters) for each type of deadwood decay?
SELECT [DECY], MAX ([MIDPT_DIAM]) MAXMPD
FROM [TBL_DEADWOOD]
GROUP BY [DECY]
;

-- 35: What is the longest length for each type of deadwood decay?
SELECT [DECY], MAX ([LEN]) MAXLENGTH
FROM [TBL_DEADWOOD]
GROUP BY [DECY]
;

-- 36: What is the decay stage description for the decay stage associated with the lowest recorded midpoint diameter (in meters)?
SELECT [DECAYSTAGE_DESCR]
FROM [TLU_DECAYSTAGE] DS
WHERE [DS].[DCYSTG_ID] IN (SELECT TOP 1 [DECY]
FROM [TBL_DEADWOOD]
ORDER BY [MIDPT_DIAM] ASC)
;

-- 37: What is the decay stage description for the decay stage associated with the shortest recorded length?
SELECT [DECAYSTAGE_DESCR]
FROM [TLU_DECAYSTAGE] DS
WHERE [DS].[DCYSTG_ID] IN (SELECT TOP 1 [DECY]
FROM [TBL_DEADWOOD]
ORDER BY [LEN] ASC)
;

-- 38: Show the site description, slope, aspect, location notes, and accuracy notes, for locations with a convex slope shape.
SELECT [SITEDESC], [SLP], [ASPCT], [LOC_NOTES], [ACC_NOTES]
FROM [TBL_LOCATIONS]
WHERE [SLP_SHP] = 'convex'
;

-- 39: What is the quad name for the location with a topographic position of 7?
SELECT [QUADNAME]
FROM [TBL_LOCATIONS]
WHERE [TOPO_POSITION] = 7
;

-- 40: For each tree condition text description, show a count of the number of sapling records.
SELECT [TREECOND_TEXT], COUNT (*) SAPLINGCOUNT
FROM [TBL_SAPLINGS] S
JOIN [TLU_TREE_COND] C ON [S].[CNDTN] = [C].[TREECOND_NUM]
GROUP BY [TREECOND_TEXT]
;

