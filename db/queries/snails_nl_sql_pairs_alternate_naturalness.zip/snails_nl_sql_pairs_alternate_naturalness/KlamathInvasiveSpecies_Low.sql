-- 1: Show the event notes and location IDs from events that started on August 5th, 2011
SELECT [EVT_NOTES], [LOC_ID]
FROM [TBL_EVENT_DETAILS] D
JOIN [TBL_EVENTS] E ON [E].[EVT_ID] = [D].[EVT_ID]
WHERE DAY ([STRT_DT]) = 5 AND MONTH ([STRT_DT]) = 8 AND YEAR ([STRT_DT]) = 2011
;

-- 2: Show the event notes and location Names from events that started on August 5th, 2011
SELECT [EVT_NOTES], [LOC_NAME]
FROM [TBL_EVENT_DETAILS] D
JOIN [TBL_EVENTS] E ON [E].[EVT_ID] = [D].[EVT_ID]
JOIN [TBL_LOCATIONS] L ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE DAY ([STRT_DT]) = 5 AND MONTH ([STRT_DT]) = 8 AND YEAR ([STRT_DT]) = 2011
;

-- 3: How many events are there?
SELECT COUNT (*) EVENTCOUNT
FROM [TBL_EVENTS]
;

-- 4: How many events have both micro habitat and macro habitat observations?
SELECT COUNT (*)
FROM [TBL_MACROHABITAT] MAC
JOIN [TBL_MICROHABITAT] MIC ON [MAC].[EVT_ID] = [MIC].[EVT_ID]
;

-- 5: Show the average slope of macro habitat events with Upland hydrology
SELECT AVG ([SLOP]) AVGSLOPE
FROM [TBL_MACROHABITAT]
WHERE [HYDRLGY] = 'Upland'
;

-- 6: What is the reason for the most-recent database edit, and what table and field was edited, and when was it changed?
SELECT TOP 1 [REASN], [TABL], [FLD], [DT_CHNG]
FROM [TBL_EDLOG]
ORDER BY [DT_CHNG] DESC
;

-- 7: What is the average percent soil disturbance of micro habitats with surface water?
SELECT AVG ([SOIL_DIST]) AVGSOILDISTURBANCE
FROM [TBL_MICROHABITAT]
WHERE [SURFWATER] > 0
;

-- 8: For the event at the highest elevation recorded on July 28 2009, show the light index, evergreen coverage, litter coverage, vegetation height, and elevation
SELECT TOP 1 [LGHTIDX], [EVERGRN], [LITTR], [VEGHEIGHT], [ELEV]
FROM [TBL_MICROHABITAT] M
JOIN [TBL_EVENTS] E ON [M].[EVT_ID] = [E].[EVT_ID]
JOIN [TBL_LOCATIONS] L ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE YEAR ([STRT_DT]) = 2009 AND MONTH ([STRT_DT]) = 7 AND DAY ([STRT_DT]) = 28
ORDER BY [ELEV] DESC
;

-- 9: How many species are included in the crater lakes lookup species lookup table?
SELECT COUNT (DISTINCT [SPECS]) SPECIESCOUNT
FROM [TLU_SPECIES_CRLA]
;

-- 10: Show all of the species listed in the Lava Beds National Monument species lookup table in 2017
SELECT [SPECS]
FROM [TLU_SPECIES_LABE]
WHERE [SMPLYR] = 2017
;

-- 11: For each year, display a count of distinct species in the oregon caves national monument and preserve species lookup table.
SELECT [SMPLYR], COUNT (DISTINCT [SPECS]) SPECIESCOUNT
FROM [TLU_SPECIES_ORCA]
GROUP BY [SMPLYR]
;

-- 12: For each year, display a count of distinct species in the Redwood National Parks species lookup table.
SELECT [SMPLYR], COUNT (DISTINCT [SPECS]) SPECIESCOUNT
FROM [TLU_SPECIES_REDW]
GROUP BY [SMPLYR]
;

-- 13: Make a list of species that are in the Redwood national parks species lookup table that are not in the Whiskeytown National Recreation area species lookup table. Include only one row per species.
SELECT DISTINCT [SPECS]
FROM [TLU_SPECIES_REDW]
WHERE [SPECS] NOT IN (SELECT [SPECS]
FROM [TLU_SPECIES_WHIS])
;

-- 14: Which species are in both the Oregon Caves National Monument species lookup table and the Lassen Volcanic National Park species lookup table? Include only one row per species.
SELECT DISTINCT [SPECS]
FROM [TLU_SPECIES_LAVO]
WHERE [SPECS] IN (SELECT [SPECS]
FROM [TLU_SPECIES_ORCA])
;

-- 15: What is the position title, city, state, and zip code, of the contact with the first name Ivan and the last name C?
SELECT [POS_TTL], [CTY], [ST_CODE], [ZIP_CD]
FROM [TLU_CONTACTS]
WHERE [FST_NM] = 'Ivan' AND [LST_NM] = 'C'
;

-- 16: What is Dominic D's position title?
SELECT [POS_TTL]
FROM [TLU_CONTACTS]
WHERE [FST_NM] = 'Dominic' AND [LST_NM] = 'D'
;

-- 17: How many different enumeration groups are there?
SELECT COUNT (DISTINCT [ENUM_GROUP]) ENUMCOUNT
FROM [TLU_ENUMERATIONS]
;

-- 18: What is the description of the Logging code in the Land Use enumeration group?
SELECT [ENUM_DESCRIPTION]
FROM [TLU_ENUMERATIONS]
WHERE [ENUM_GROUP] = 'Land Use' AND [ENUM_CODE] = 'Logging'
;

-- 19: How many different codes are there for each enumeration group?
SELECT [ENUM_GROUP], COUNT (*) CODECOUNT
FROM [TLU_ENUMERATIONS]
GROUP BY [ENUM_GROUP]
;

-- 20: What is the revision reason and description for revisions made by Allison S?
SELECT [REV_REASON], [REVISION_DESC]
FROM [TBL_DB_REVISIONS] R
JOIN [TLU_CONTACTS] C ON [R].[REV_CONT_ID] = [C].[CNTCT_ID]
WHERE [FST_NM] = 'Allison' AND [LST_NM] = 'S'
;

-- 21: For each year, show how many revisions were made to the database.
SELECT YEAR ([REV_DATE]) YEARREVISED, COUNT (*) REVISIONCOUNT
FROM [TBL_DB_REVISIONS]
GROUP BY YEAR ([REV_DATE])
;

-- 22: Show the name, ID, description, length, and route of the site with the highest starting Y coordinate.
SELECT TOP 1 [ST_ID], [SITE_NM], [SITE_DESC], [LEN], [ROUT]
FROM [TBL_SITES]
ORDER BY [ST_START_Y] DESC
;

-- 23: Show the starting and ending X and Y coordinates for the site named Nobles Pass C
SELECT [ST_START_X], [ST_END_X], [ST_START_Y], [ST_END_Y]
FROM [TBL_SITES]
WHERE [SITE_NM] = 'Nobles Pass C'
;

-- 24: What is the name and number of sites of the site with the most locations?
SELECT TOP 1 [SITE_NM], COUNT (*) LOCATIONCOUNT
FROM [TBL_SITES] S
JOIN [TBL_LOCATIONS] L ON [S].[ST_ID] = [L].[ST_ID]
GROUP BY [SITE_NM]
ORDER BY COUNT (*) DESC
;

-- 25: Show location name and the X and Y coordinates of all the locations at the site named North A
SELECT [LOC_NAME], [X_COORD], [Y_COORD]
FROM [TBL_SITES] S
JOIN [TBL_LOCATIONS] L ON [S].[ST_ID] = [L].[ST_ID]
WHERE [SITE_NM] = 'North A'
;

-- 26: What is the first name of the contact associated with the highest number of unique events?
SELECT TOP 1 [FST_NM]
FROM [TLU_CONTACTS] C
JOIN [XREF_EVENT_CONTACTS] X ON [C].[CNTCT_ID] = [X].[CNTCT_ID]
GROUP BY [FST_NM]
ORDER BY COUNT (DISTINCT [EVT_ID]) DESC
;

-- 27: What are the First names, last names, and position titles of contacts who uploaded an event that started in August of 2021? Include only one row per contact
SELECT DISTINCT [FST_NM], [LST_NM], [POS_TTL]
FROM [TLU_CONTACTS] C
JOIN [XREF_EVENT_CONTACTS] X ON [C].[CNTCT_ID] = [X].[CNTCT_ID]
JOIN [TBL_EVENTS] E ON [X].[EVT_ID] = [E].[EVT_ID]
WHERE YEAR ([STRT_DT]) = 2021 AND MONTH ([STRT_DT]) = 8
;

-- 28: How many events were documented at each location? Show the location name and count of events. Only show the 10 locations with the highest number of events.
SELECT TOP 10 [LOC_NAME], COUNT (*) EVENTCOUNT
FROM [TBL_LOCATIONS] L
JOIN [TBL_EVENTS] E ON [L].[LOC_ID] = [E].[LOC_ID]
GROUP BY [LOC_NAME]
ORDER BY COUNT (*) DESC
;

-- 29: How many events were documented at each site? Show the site name, site description, and count of events. Only show the 10 sites with the highest number of events.
SELECT TOP 10 [SITE_NM], [SITE_DESC], COUNT (*) EVENTCOUNT
FROM [TBL_LOCATIONS] L
JOIN [TBL_EVENTS] E ON [L].[LOC_ID] = [E].[LOC_ID]
JOIN [TBL_SITES] S ON [L].[ST_ID] = [S].[ST_ID]
GROUP BY [SITE_NM], [SITE_DESC]
ORDER BY COUNT (*) DESC
;

-- 30: What is the trimble position dilution of position, the horizontal dilution of position, and the estimated position error of the locations at the site named Mule Town B?
SELECT [POSN_DILTN_PRECSN], [HORIZ_DLITN_PRECSN], [EST_POSN_ERR]
FROM [TBL_LOCATIONS] L
JOIN [TBL_SITES] S ON [L].[ST_ID] = [S].[ST_ID]
WHERE [SITE_NM] = 'Mule Town B'
;

-- 31: How many locations are there in Shasta count?
SELECT COUNT (*) LOCCOUNT
FROM [TBL_LOCATIONS]
WHERE [CNTY] = 'Shasta'
;

-- 32: For each location type, show a count of locations in shasta county.
SELECT [LOC_TYPE], COUNT (*) LOCCOUNT
FROM [TBL_LOCATIONS]
WHERE [CNTY] = 'Shasta'
GROUP BY [LOC_TYPE]
;

-- 33: Show the names of the ten sites and the count of infested sites, of the sites with the most locations of type infestation
SELECT TOP 10 [SITE_NM], COUNT (*) SITECOUNT
FROM [TBL_LOCATIONS] L
JOIN [TBL_SITES] S ON [L].[ST_ID] = [S].[ST_ID]
WHERE [LOC_TYPE] = 'Infestation'
GROUP BY [SITE_NM]
ORDER BY COUNT (*) DESC
;

-- 34: Show a list of event IDs for events that were documented at the Wood River watershed and the Annie Creek sub watershed
SELECT [EVT_ID]
FROM [TBL_EVENTS] E
JOIN [TBL_LOCATIONS] L ON [E].[LOC_ID] = [L].[LOC_ID]
WHERE [WTRSHD] = 'Wood River' AND [SUBWTRSHD] = 'Annie Creek'
;

-- 35: What is the average elevation of the Annie Creek Subwatershed?
SELECT AVG ([ELEV]) AVGELEVATION
FROM [TBL_LOCATIONS]
WHERE [SUBWTRSHD] = 'Annie Creek'
;

-- 36: How many locations were a randomly generated plot that was found to have an infestation?
SELECT COUNT (*) LOCCOUNT
FROM [TBL_LOCATIONS]
WHERE [RNDPLTIN] = 'Yes'
;

-- 37: Show the X and Y coordinates, the coordinate units, the coordinate system and datum, the horizontal error, accuracy notes and location type of the location named CRLA-Infestation-3924
SELECT [LOC_NAME], [X_COORD], [Y_COORD], [COORD_UNITS], [COORD_SYSTEM], [DTM], [ESTHORIZERROR], [ACC_NOTES], [LOC_TYPE]
FROM [TBL_LOCATIONS]
WHERE [LOC_NAME] = 'CRLA-Infestation-3924'
;

-- 38: How many events are logged for each Hydrology type?
SELECT [HYDRLGY], COUNT (*) EVENTCOUNT
FROM [TBL_MACROHABITAT]
GROUP BY [HYDRLGY]
;

-- 39: Show the Macro Habitat, Micro Habitat, Hydrology, Land Use, Slope, and Aspect of the Macro Habitats associated with events started in July of 2015
SELECT [MACROHAB], [MICROHAB], [HYDRLGY], [LNDUSE], [SLOP], [ASPCT]
FROM [TBL_MACROHABITAT] MH
JOIN [TBL_EVENTS] E ON [MH].[EVT_ID] = [E].[EVT_ID]
WHERE YEAR ([STRT_DT]) = 2015 AND MONTH ([STRT_DT]) = 7
;

-- 40: What is the deciduous, shrub, herb, debris, litter, ground, and rock coverage of micro habitatis with a Flowering Phenology and a cover percentage greater than 90
SELECT [DECIDUS], [SHRB], [HRB], [WDYDBRS], [LITTR], [BAREGRND], [RCK]
FROM [TBL_MICROHABITAT]
WHERE [PHENOLGY] = 'Flowering' AND CAST ([COVERPERC] AS FLOAT) > 90
;

