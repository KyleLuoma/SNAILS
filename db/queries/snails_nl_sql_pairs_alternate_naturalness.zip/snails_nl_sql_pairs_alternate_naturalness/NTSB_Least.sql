-- 1: How many different vehicles are there?
SELECT COUNT (DISTINCT [VIN]) VEHCOUNT
FROM [GV]
;

-- 2: How many crashes had a reported fire?
SELECT COUNT (DISTINCT [C_ID]) CRASHCOUNT
FROM [FI]
;

-- 3: What years does this data span?
SELECT DISTINCT [C_Y]
FROM [CRS]
;

-- 4: How many events were recorded by an event data recorder?
SELECT COUNT (*) AS RECORDEDEVENTCOUNT
FROM [EDR_EV]
;

-- 5: How many vehicle occupants received attention from emergency services?
SELECT COUNT (*) OCCCOUNT
FROM [OCC]
WHERE [EMS_D] = 1
;

-- 6: How many adjusted jackknife replicate weight entries are there for cases in category 3?
SELECT COUNT (*) CASECOUNT
FROM [JK_W]
WHERE [CGY] = 3
;

-- 7: What is the average weight of adjusted jackknife replicate weight 3
SELECT AVG ([JKWGT3]) WGT3AVG
FROM [JK_W]
;

-- 8: Show the average weight of the adjusted jackknife replicate weight 5 by case category
SELECT [CGY], AVG ([JKWGT5]) WGT5AVG
FROM [JK_W]
GROUP BY [CGY]
;

-- 9: How many crashes involved a driver with a blood alcohol concentration greater than 250 mg/DL? Actual values range from 0-499. Exclude values greater than 499.
SELECT COUNT (DISTINCT [C_ID]) CRASHCOUNT
FROM [GV]
WHERE [ALC_TST_RSLT] > 250 AND [ALC_TST_RSLT] < 500
;

-- 10: Show a list of vehicle make, model, and curb weight for all vehicles with a curb weight between 2000 and 3000 kg.
SELECT [V].[MK], [V].[MDL], [CRB_W]
FROM [GV]
JOIN [VPIC_D] V ON [GV].[C_ID] = [V].[C_ID] AND [GV].[V_NO] = [V].[V_NO]
WHERE [CRB_W] > = 2000 AND [CRB_W] < = 3000
;

-- 11: Display a count of vehicle inspections by inspection type
SELECT [INSP_T], COUNT (*) AS VEHCOUNT
FROM [GV]
GROUP BY [INSP_T]
;

-- 12: Display a count of crashes by lighting condition
SELECT [L_CON], COUNT (DISTINCT [C_ID])
FROM [GV]
GROUP BY [L_CON]
;

-- 13: How many vehicles are there where drugs were present (presence code value is 1) and the vehicle was towed for a reason not due to disabling damage (towed code is 3)
SELECT COUNT (*) VEHCOUNT
FROM [GV]
WHERE [P_DR] = 1 AND [TW] = 3
;

-- 14: Show a count of vehicles for each type of road rumble strip presence.
SELECT [RMBL_RD], COUNT (*) VEHCOUNT
FROM [GV]
GROUP BY [RMBL_RD]
;

-- 15: For each vehicle, show the road speed limit, the highest speed the vehicle was recorded by the event data recorder, and how much higher or lower than the speed limit the vehicle was traveling. Limit travel speed and speedlimit to values less than 300 kph.
SELECT [SPD_L], [MAXSPEED], [MAXSPEED] - [SPD_L] DIFF
FROM [GV]
JOIN (SELECT [C_ID], [V_NO], MAX ([PVALUE]) MAXSPEED
FROM [EDR_PRE_CR]
WHERE [PCODE] = 1010 AND [PVALUE] < 300
GROUP BY [C_ID], [V_NO]) S ON [GV].[C_ID] = [S].[C_ID] AND [GV].[V_NO] = [S].[V_NO]
WHERE [SPD_L] < 300
;

-- 16: What is the average length of the first object stuck after the vehicle departs the shoulder or roadway? Valid values range from 0 to 120 centimeters. Ignore values outside of this range.
SELECT AVG ([STK_LEN]) AVGLENGTH
FROM [GV]
WHERE [STK_LEN] BETWEEN 0 AND 120
;

-- 17: How many vehicles are there where there was a yield sign in their environment just prior to the crash? The lookup code for yield sign is 3.
SELECT COUNT (*) VEHCOUNT
FROM [GV]
WHERE [TRAFDEV] = 3
;

-- 18: Show the number of vehicles in each intrusion magnitude category
SELECT [INTMAG], COUNT (DISTINCT (CONCAT ([C_ID], [V_NO]))) VEHCOUNT
FROM [INTR]
GROUP BY [INTMAG]
;

-- 19: Show the number of crashes in each intrusion magnitude category
SELECT [INTMAG], (COUNT (DISTINCT [C_ID])) CRASHCOUNT
FROM [INTR]
GROUP BY [INTMAG]
;

-- 20: Display the Case ID, vehicle number, intrusion components, intrusion magnitude, and intrusion direction for cases with an ID less than 20392
SELECT [C_ID], [V_NO], [INTCOMP], [INTMAG], [INT_DIR]
FROM [INTR]
WHERE [C_ID] < 20392
;

-- 21: What are the intrusion directions for all vehicles in case 20387? Include vehicle number and intrusion direction in the result set.
SELECT [V_NO], [INT_DIR]
FROM [INTR]
WHERE [C_ID] = 20387
;

-- 22: Show a count of injuries by body region
SELECT [RGN], COUNT (*) INJCOUNT
FROM [INJ]
GROUP BY [RGN]
;

-- 23: Show a count of injuries by injury severity
SELECT [AIS], COUNT (*) INJCOUNT
FROM [INJ]
GROUP BY [AIS]
;

-- 24: How many injuries were caused by an unknown energy source? The lookup code unknown is 999.
SELECT COUNT (*) INJCOUNT
FROM [ICS]
WHERE [SOE] = 999
;

-- 25: Show a count of injuries by body region where the injury severity is critical. The lookup code for critical injury is 5.
SELECT [RGN], COUNT (*) INJCOUNT
FROM [INJ]
WHERE [AIS] = 5
GROUP BY [RGN]
;

-- 26: Show a count of injuries by severity where the body region is the spine. The lookup code for spine is 6.
SELECT [AIS], COUNT (*) INJCOUNT
FROM [INJ]
WHERE [RGN] = 6
GROUP BY [AIS]
;

-- 27: Show a count of minor injuries by vehicle make. The lookup code for minor injuries is 1.
SELECT [MK], COUNT (*) MINORINJURIES
FROM [VPIC_D] V
JOIN [INJ] I ON [V].[C_ID] = [I].[C_ID] AND [V].[V_NO] = [I].[V_NO]
WHERE [AIS] = 1
GROUP BY [MK]
;

-- 28: Which vehicle manufacturer has the most neck injuries?
SELECT TOP 1 [MK]
FROM [VPIC_D] V
JOIN [INJ] I ON [V].[C_ID] = [I].[C_ID] AND [V].[V_NO] = [I].[V_NO]
WHERE [RGN] = 3
GROUP BY [MK]
ORDER BY COUNT (*)
;

-- 29: What is the average time it takes for emergency services to be notified after a crash occurs? Exclude values greater than 1000
SELECT AVG ([NOTIF]) AVGNOTIFICATIONTIME
FROM [EMS_CR]
WHERE [NOTIF] < = 1000
;

-- 30: What is the average time it takes for emergency services to arrive at the scene after a crash occurs? Exclude values greater than 1600.
SELECT AVG ([SCN_ARR]) AVGARRIVALTIME
FROM [EMS_CR]
WHERE [SCN_ARR] < = 1600
;

-- 31: What is the average total time from the time an accident occurs to the time that emergency services depart the scene of an accident? Exclude values greater than 1600.
SELECT AVG ([SCN_DEP]) AVGDEPTIME
FROM [EMS_CR]
WHERE [SCN_DEP] < = 1600
;

-- 32: What is the average total time from the time an accident occurs to the time that emergency medical services arrive at the medical facility? Exclude values greater than 1600.
SELECT AVG ([ARV_MED]) AVGMEDARRIVE
FROM [EMS_CR]
WHERE [ARV_MED] < = 1600
;

-- 33: Make a list that shows the time it took for emergency services to be notified after an accident, the time it took for emergency services to arrive at the scene, the time it took for them to depart the scene, and the time it took for them to arrive at the hospital. Show these times for each crash by case id. Only show cases where an ambulance responded. The lookupcode for ambulance is 1.
SELECT [C_ID], [NOTIF], [SCN_ARR], [SCN_DEP], [ARV_MED]
FROM [EMS_CR]
WHERE [EMS_TP] = 1
;

-- 34: How many toyota tacomas are there in the data?
SELECT COUNT (*) TACOMACOUNT
FROM [VPIC_D]
WHERE [MK] = 'TOYOTA' AND [MDL] = 'TACOMA'
;

-- 35: How many of each model year vehicle are there? Present them from oldest to newest.
SELECT [MD_YR], COUNT (*) VEHCOUNT
FROM [GV]
GROUP BY [MD_YR]
ORDER BY [MD_YR]
;

-- 36: What vehicle make has the oldest average model year?
SELECT TOP 1 [MK], AVG ([MDL_Y]) AVGYEAR
FROM [VPIC_D]
GROUP BY [MK]
ORDER BY [AVGYEAR] ASC
;

-- 37: How many vehicles had no driver present?
SELECT COUNT (*) VEHCOUNT
FROM [GV]
WHERE [DRV_P] = 0
;

-- 38: How many vehicles are there with the driver's current residence ZIP as 95020?
SELECT COUNT (*) VEHCOUNT
FROM [GV]
WHERE [ZIP] = 95020
;

-- 39: Show a count of vehicles by drug test result
SELECT [D_TST], COUNT (*)
FROM [GV]
GROUP BY [D_TST]
;

-- 40: What are the unique category codes for glazing (glass) pre-crash status?
SELECT DISTINCT [G_PRE]
FROM [GZNG]
;

-- 41: Show a count of all vehicles grouped by plane of impact
SELECT [CDC_PL], COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHICLECOUNT
FROM [CDC]
GROUP BY [CDC_PL]
;

-- 42: How many accidents involved occupant contact with vehicle glazing (aka glass)?
SELECT COUNT (DISTINCT [C_ID]) ACCIDENTCOUNT
FROM [INTE]
WHERE [GLZ_CNT] = 1
;

-- 43: What is the most common first manufacture-recommended front tire size? Exclude tire size values of '9999999999'
SELECT TOP 1 [RECFRONT1]
FROM [T_PL] T
WHERE [RECFRONT1] <> '9999999999'
GROUP BY [RECFRONT1]
ORDER BY COUNT (*) DESC
;

-- 44: How many vehicles had damage to the windshield glazing?
SELECT COUNT (*) AS WINDSHIELD_DAMAGE_COUNT
FROM [GZNG]
WHERE [G_LOC] = 1
;

-- 45: Display a count of all vehicles by glazing (glass) impact damage category
SELECT [G_IMP], COUNT (DISTINCT [VIN]) AS VEHCOUNT
FROM [GZNG] GZ
JOIN [GV] ON [GV].[C_ID] = [GZ].[C_ID] AND [GV].[V_NO] = [GZ].[V_NO]
GROUP BY [G_IMP]
ORDER BY [G_IMP]
;

-- 46: How many crashes involved vehicles with after-marked adaptive driving equipment?
SELECT COUNT (*) CRASHCOUNT
FROM [ADP]
;

-- 47: What is the highest roll angle recorded post-crash by an event data recorder?
SELECT TOP 1 [PVALUE]
FROM [EDR_PST_CR]
WHERE [PCODE] = 2060
ORDER BY [PVALUE] DESC
;

-- 48: Show number of crashes by month in month order
SELECT [C_M], COUNT (*) AS CRASHCOUNT
FROM [CRS]
GROUP BY [C_M]
ORDER BY [C_M]
;

-- 49: Show the highest speed recorded by the event data recorder for each case for cases where at least one vehicle exceeded 100 (but no more than 200).
SELECT [C_ID], MAX ([PVALUE]) MAXSPEED
FROM [EDR_PRE_CR]
WHERE [PCODE] = 1010 AND [PVALUE] > 100 AND [PVALUE] < 200
GROUP BY [C_ID]
;

-- 50: Show the highest speed recorded by the event data recorder for each case for cases where at least one vehicle exceeded 160 (but no more than 300). Include the case id, vehicle make and model. Sort from fastest to slowest.
SELECT [PR].[C_ID], [MK], [MDL], MAX ([PVALUE]) MAXSPEED
FROM [EDR_PRE_CR] PR
JOIN [VPIC_D] V ON [PR].[C_ID] = [V].[C_ID] AND [V].[V_NO] = [PR].[V_NO]
WHERE [PCODE] = 1010 AND [PVALUE] > 160 AND [PVALUE] < 300
GROUP BY [PR].[C_ID], [PR].[V_NO], [MK], [MDL]
ORDER BY MAX ([PVALUE]) DESC
;

-- 51: What are all the makes of vehicles in the database?
SELECT DISTINCT [MK]
FROM [VPIC_D]
;

-- 52: How many different types of injury causation scenarios are there?
SELECT COUNT (DISTINCT [ICS_T]) TYPECOUNT
FROM [ICS]
;

-- 53: How many injuries are there for each body region?
SELECT [BRI], COUNT (*) AS INJURY_COUNT
FROM [ICS]
GROUP BY [BRI]
;

-- 54: What is the average age of all vehicle occupants? Ignore values higher than 130.
SELECT AVG ([AGE]) AVGAGE
FROM [OCC]
WHERE [AGE] < = 130
;

-- 55: Show the average height of all occupants by age. Ignore height values higher than 220 and age values higher than 120. Show in age order from youngest to oldest.
SELECT [AGE], AVG ([HT]) AVGHEIGHT
FROM [OCC]
WHERE [AGE] < = 120 AND [HT] < = 220
GROUP BY [AGE]
ORDER BY [AGE] ASC
;

-- 56: How many crashes resulted in the death of a fetus? The lookup value for fetal mortality is 1.
SELECT COUNT (DISTINCT [C_ID]) DEATHCOUNT
FROM [OCC]
WHERE [FETALMORT] = 1
;

-- 57: How many crashes had vehicles where no seatbelt was available because it was removed or destroyed? The lookup value for no belt available due to removal or destruction is 1.
SELECT COUNT (DISTINCT [C_ID]) NOBELTCOUNT
FROM [OCC]
WHERE [B_AVA] = 1
;

-- 58: How many crashes had an occupant that did not use a seat belt? The codes that correspond to no use are 0 and 1.
SELECT COUNT (DISTINCT [C_ID]) NOBELTCOUNT
FROM [OCC]
WHERE [B_USE] IN (0, 1)
;

-- 59: How many vehicle occupants did not wear a seatbelt even though there was one available? The codes that correspond to no use are 0 and 1. The codes that correspond to a belt being available are 2, 3, 4, 5, 6, 7 and 8.
SELECT COUNT (*) OCCCOUNT
FROM [OCC]
WHERE [B_USE] IN (0, 1) AND [B_AVA] IN (2, 3, 4, 5, 6, 7, 8)
;

-- 60: Show me occupant mortality counts by belt use category. A mortality occured (was fatal) indicated by lookup code 1.
SELECT [B_USE], COUNT (*) MORTALCOUNT
FROM [OCC]
WHERE [MORT] = 1
GROUP BY [B_USE]
;

-- 61: Show the total occupant count and the mortality count by belt use category. A mortality occured (was fatal) indicated by lookup code 1.
SELECT [M].[B_USE], [TOTALCOUNT], [MORTALCOUNT]
FROM (SELECT [B_USE], COUNT (*) MORTALCOUNT
FROM [OCC]
WHERE [MORT] = 1
GROUP BY [B_USE]) M
JOIN (SELECT [B_USE], COUNT (*) TOTALCOUNT
FROM [OCC]
GROUP BY [B_USE]) T ON [M].[B_USE] = [T].[B_USE]
;

-- 62: How many vehicles were documented as encountering a direction of force between 150 and 210 degrees inclusive?
SELECT COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHCOUNT
FROM [CDC]
WHERE [PDOF] > = 150 AND [PDOF] < = 210
;

-- 63: How many crashes are there where the vehicle-to-vehicle heading angle at impact was between 0 and 90 degrees inclusive?
SELECT COUNT (DISTINCT [C_ID]) CRASHCOUNT
FROM [CDC]
WHERE [H_ANG] > = 0 AND [H_ANG] < = 90
;

-- 64: What is the maximum depth of crush measured? Codes 888 and 999 should be ignored.
SELECT TOP 1 [CMAX]
FROM [CDC]
WHERE [CMAX] NOT IN (888, 999)
ORDER BY [CMAX] DESC
;

-- 65: How many vehicles had A pillar damage?
SELECT COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHICLECOUNT
FROM [CDC]
WHERE [DAMAPILLAR] = 1
;

-- 66: How many vehicles had damage to a pillar other than an A, B, or C pillar?
SELECT COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHICLECOUNT
FROM [CDC]
WHERE [DAMOTHPILLAR] = 1
;

-- 67: What is the average difference in crush between the door sill and the door structure for all vehicles where this information was reported? Ignore the codes 888 and 999.
SELECT AVG ([D_S_D]) AVGDIFF
FROM [CDC]
WHERE [D_S_D] NOT IN (888, 999)
;

-- 68: What is the highest vehicle-to-object collision speed difference recorded? This would equivalent to the speed of the vehicle if it struck a fixed stationary obstacle. 999 indicates an unknown value.
SELECT TOP 1 [DVBARRIER]
FROM [CDC]
WHERE [DVBARRIER] <> 999
ORDER BY [DVBARRIER] DESC
;

-- 69: For each case where measurements were performed, show the case ID, vehicle number, and all of the different crush measurements and the maximum. Codes 888 and 999 indicate that measurements are not available.
SELECT [C_ID], [V_NO], [CMAX], [C1], [C2], [C3], [C4], [C5], [C6]
FROM [CDC]
WHERE [CMAX] NOT IN (888, 999)
;

-- 70: What are the case ids, vehicle numbers, and event data recording summary numbers of the vehicles that had 10 events recorded in their event data recorder?
SELECT [C_ID], [V_NO], [EDR_SMN]
FROM [EDR_EV]
GROUP BY [C_ID], [V_NO], [EDR_SMN]
HAVING COUNT (*) = 10
;

-- 71: For each crash, show the case number, event number, and number of time-based datapoints recorded prior to the crash for each event data recorder event.
SELECT [EV].[C_ID], [EV].[EDREVN], COUNT (*) AS PRECRASHTIMEPOINTS
FROM [EDR_PRE_CR] PC
JOIN [EDR_EV] EV ON [PC].[C_ID] = [EV].[C_ID] AND [PC].[EDREVN] = [EV].[EDREVN]
GROUP BY [EV].[C_ID], [EV].[EDREVN]
ORDER BY [C_ID]
;

-- 72: Show the make, model, manufacture year, and number of ignition cycles of all vehicles with fewer than 200 ignition cycles registered in the event data recorder at the time of crash. Display them by model year older, with the newest models at the top.
SELECT DISTINCT [MK], [MDL], [MDL_Y], [IGCYCRASH]
FROM [EDR_EV] E
JOIN [VPIC_D] V ON [E].[C_ID] = [V].[C_ID] AND [E].[V_NO] = [V].[V_NO]
WHERE [IGCYCRASH] < 200 AND [IGCYCRASH] > 0
ORDER BY [MDL_Y] DESC
;

-- 73: How many vehicles with fewer than 400, but more than 0, ignition cycles are in the data?
SELECT COUNT (*) AS VEHICLECOUNT
FROM (SELECT DISTINCT [C_ID], [V_NO], [IGCYCRASH]
FROM [EDR_EV]) E
WHERE [IGCYCRASH] > 0 AND [IGCYCRASH] < 400
;

-- 74: list all of the cases, vehicle number, occupant number, and number of injuries for cases with an occupant that sustained more than one injury
SELECT [C_ID], [V_NO], [OC_N], COUNT (*) AS INJURY_COUNT
FROM [INJ]
GROUP BY [C_ID], [V_NO], [OC_N]
HAVING COUNT ([IN_NO]) > 1
ORDER BY [INJURY_COUNT] DESC
;

-- 75: How many fires were reported for each fuel type?
SELECT [F_TP], COUNT (*)
FROM [FI]
JOIN [FL] ON [FI].[C_ID] = [FL].[C_ID] AND [FI].[V_NO] = [FL].[V_NO]
GROUP BY [F_TP]
;

-- 76: Show a count of occupant ejections by sex
SELECT [SX], COUNT (*)
FROM [OCC]
JOIN [EJCT] ON [OCC].[C_ID] = [EJCT].[C_ID] AND [OCC].[V_NO] = [EJCT].[V_NO] AND [OCC].[OC_N] = [EJCT].[V_NO]
GROUP BY [SX]
;

-- 77: List the number of crashes by vehicle make from most to least
SELECT [MK], COUNT (*) AS CRASHCOUNT
FROM [VPIC_D]
GROUP BY [MK]
ORDER BY [CRASHCOUNT] DESC
;

-- 78: How many crashes involved vehicles that were equipped with crash avoidance features?
SELECT COUNT (DISTINCT [C_ID]) CRASHCOUNT
FROM [AVD]
WHERE [AV] = 1
;

-- 79: What is the most common crash avoidance equipment feature?
SELECT TOP 1 [EQ]
FROM [AVD]
WHERE [AV] = 1
GROUP BY [EQ]
ORDER BY COUNT (*) DESC
;

-- 80: How many vehicles have more than four crash avoidance features?
SELECT COUNT (*) VEHCOUNT
FROM (SELECT [C_ID], [V_NO], COUNT ([EQ]) FEATURECOUNT
FROM [AVD]
WHERE [AV] = 1
GROUP BY [C_ID], [V_NO]
HAVING COUNT (*) > 4) SUBQUERY_T
;

-- 81: How many vehicles had tire damage?
SELECT COUNT (*) VEHCOUNT
FROM (SELECT DISTINCT [C_ID], [V_NO]
FROM [T_DAM]) T
;

-- 82: How many vehicles have a gross vehicle weight rating less than 4000?
SELECT COUNT (*) VEHCOUNT
FROM [T_PL]
WHERE [GVWR] < 4000
;

-- 83: List the Front and rear axle weight ratings for vehicles that have a gross vehicle weight rating between 4000 and 9000
SELECT [GAWRFRONT], [GAWRREAR]
FROM [T_PL]
WHERE [GVWR] BETWEEN 4000 AND 9000
;

-- 84: Show the average first manufacture recommended front and rear tire pressures for vehicles with a gross vehicle weight rating below 3000.
SELECT AVG ([RECFRPRESS1]) AVGFRONT, AVG ([RECRRPRESS1]) AVGREAR
FROM [T_PL]
WHERE [GVWR] < 3000
;

-- 85: For each of the first manufacturer's recommended front tire sizes, list the average first recommended pressure.
SELECT [RECFRONT1], AVG ([RECFRPRESS1]) AVGPRESS
FROM [T_PL]
GROUP BY [RECFRONT1]
;

-- 86: Show the first recommended front and rear tire sizes for all of the Subaru WRXs in the dataset.
SELECT [RECFRONT1], [RECREAR1]
FROM [VPIC_D] V
JOIN [T_PL] T ON [V].[C_ID] = [T].[C_ID] AND [V].[V_NO] = [T].[V_NO]
WHERE [MK] = 'SUBARU' AND [MDL] = 'WRX'
;

-- 87: Show the first recommended front and rear tire sizes and pressure levels for all of the Honda Civics manufactured before 2012 in the dataset.
SELECT [RECFRONT1], [RECREAR1], [RECFRPRESS1], [RECRRPRESS1]
FROM [VPIC_D] V
JOIN [T_PL] T ON [V].[C_ID] = [T].[C_ID] AND [V].[V_NO] = [T].[V_NO]
WHERE [MK] = 'HONDA' AND [MDL] = 'CIVIC' AND [MDL_Y] < 2012
;

-- 88: How many vehicles had wrangler model tires?
SELECT COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHCOUNT
FROM [T]
WHERE [T_MOD] = 'WRANGLER'
;

-- 89: List the tire model names found on Jeep Wranglers. Ensure only one row per model name.
SELECT DISTINCT [T_MOD]
FROM [T] T
JOIN [VPIC_D] V ON [T].[C_ID] = [V].[C_ID] AND [T].[V_NO] = [V].[V_NO]
WHERE [MK] = 'JEEP' AND [MDL] = 'WRANGLER'
;

-- 90: Make a list of tire models and the number of vehicles that had them installed. Display them from most to least common models.
SELECT [T_MOD], COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) VEHCOUNT
FROM [T] T
GROUP BY [T_MOD]
ORDER BY COUNT (DISTINCT CONCAT ([C_ID], [V_NO])) DESC
;

-- 91: Make a list of tire models and the number of vehicles with those tires installed where tire damage was observed on at least one tire, as indicated by category values other than 0. Display them from most to least common models. Do not include the unknown damage category value 9.
SELECT [T_MOD], COUNT (DISTINCT CONCAT ([T].[C_ID], [T].[V_NO])) VEHCOUNT
FROM [T] T LEFT
JOIN [T_DAM] TD ON [T].[C_ID] = [TD].[C_ID] AND [T].[V_NO] = [TD].[V_NO]
WHERE [DMG] > 0 AND [DMG] <> 9
GROUP BY [T_MOD]
ORDER BY COUNT (DISTINCT CONCAT ([T].[C_ID], [T].[V_NO])) DESC
;

-- 92: List the case IDs and vehicle number, recommended and actual tire sizes for vehicles that had a left front tire size that matched the manufacturers first recommended front tire size.
SELECT [T].[C_ID], [T].[V_NO], [T_SZ], [RECFRONT1]
FROM [T] T
JOIN [T_PL] TP ON [T].[C_ID] = [TP].[C_ID] AND [T].[V_NO] = [TP].[V_NO]
WHERE [T_LOC] = 'LF' AND [T_SZ] = [RECFRONT1]
;

-- 93: List the case IDs, make, model, recommended and actual tire sizes for vehicles that had a left front tire size that did not match the manufacturers first recommended front tire size.
SELECT [T].[C_ID], [MK], [MDL], [T].[V_NO], [T_SZ], [RECFRONT1]
FROM [T] T
JOIN [T_PL] TP ON [T].[C_ID] = [TP].[C_ID] AND [T].[V_NO] = [TP].[V_NO]
JOIN [VPIC_D] V ON [T].[C_ID] = [V].[C_ID] AND [T].[V_NO] = [V].[V_NO]
WHERE [T_LOC] = 'LF' AND [T_SZ] <> [RECFRONT1]
;

-- 94: Which vehicle make has the most instances of mismatched front left tires? That is, where the left front tire size on the vehicle does not match the manufacturers first recommended front tire size.
SELECT TOP 1 [MK]
FROM [T] T
JOIN [T_PL] TP ON [T].[C_ID] = [TP].[C_ID] AND [T].[V_NO] = [TP].[V_NO]
JOIN [VPIC_D] V ON [T].[C_ID] = [V].[C_ID] AND [T].[V_NO] = [V].[V_NO]
WHERE [T_LOC] = 'LF' AND [T_SZ] <> [RECFRONT1]
GROUP BY [MK]
ORDER BY COUNT (DISTINCT [T].[C_ID]) DESC
;

-- 95: How many accidents were related to distracted driving?
SELECT COUNT (DISTINCT [C_ID]) DISTRACTACCIDENTCOUNT
FROM [DSTR] D
;

-- 96: How many accidents with occupied child seats were related to distracted driving?
SELECT COUNT (DISTINCT [D].[C_ID]) ACCIDENTCOUNT
FROM [DSTR] D
JOIN (SELECT DISTINCT [C_ID]
FROM [CHST]
WHERE [OC_N] IS NOT NULL) S ON [D].[C_ID] = [S].[C_ID]
;

-- 97: List vehicles by make and model and the count of the vehicles that had car seats; order from highest to lowest count.
SELECT [MK], [MDL], COUNT (*) AS VEHICLE_COUNT
FROM [VPIC_D] V
JOIN [CHST] C ON [V].[C_ID] = [C].[C_ID] AND [V].[V_NO] = [C].[V_NO]
GROUP BY [MK], [MDL]
ORDER BY [VEHICLE_COUNT] DESC
;

-- 98: List vehicles by make and model and the count of the vehicles that had child car seats; Provide a separate count of how many of these vehicles had distracted drivers.
SELECT [MK], [MDL], COUNT (*) AS VEHICLE_COUNT, COUNT ([DIST]) AS DISTRACTION_COUNT
FROM [VPIC_D] V
JOIN [CHST] C ON [V].[C_ID] = [C].[C_ID] AND [V].[V_NO] = [C].[V_NO] LEFT
JOIN [DSTR] D ON [D].[C_ID] = [V].[C_ID] AND [D].[V_NO] = [V].[V_NO]
GROUP BY [MK], [MDL]
ORDER BY [DISTRACTION_COUNT] DESC
;

-- 99: Which vehicle make with more than 5 vehicles in the database has the highest number of distracted drivers in proportion to the total number of the make and model in the data?
SELECT [MK], COUNT (*) AS VEHICLE_COUNT, COUNT ([DIST]) AS DISTRACT_COUNT, CAST (COUNT ([DIST]) AS FLOAT) / CAST (COUNT (*) AS FLOAT) AS PROP_DISTRACT
FROM [VPIC_D] V LEFT
JOIN [DSTR] D ON [V].[C_ID] = [D].[C_ID] AND [V].[V_NO] = [D].[V_NO]
GROUP BY [MK]
HAVING COUNT (*) > 5
ORDER BY [PROP_DISTRACT] DESC
;

-- 100: List the number of crashes by vehicle make from most to least. Show how many of these crashes resulted in a fire. Calculate the proportion of total crashes by make to crashes with a fire
SELECT [MK], COUNT (*) AS CASE_COUNT, SUM ([FI]) AS FIRE_COUNT, (CAST (SUM ([FI]) AS FLOAT) / CAST (COUNT (*) AS FLOAT)) AS FIRE_PROPORTION
FROM [VPIC_D] VD
JOIN [FI] F ON [F].[C_ID] = [VD].[C_ID] AND [F].[V_NO] = [VD].[V_NO]
GROUP BY [MK]
ORDER BY [FIRE_PROPORTION] DESC
;

