-- 1: How many different vehicles are there?
SELECT COUNT (DISTINCT [VEH_ID_NO]) VEHCOUNT
FROM [GEN_VEH]
;

-- 2: How many crashes had a reported fire?
SELECT COUNT (DISTINCT [CS_ID]) CRASHCOUNT
FROM [FIR]
;

-- 3: What years does this data span?
SELECT DISTINCT [CRSHYR]
FROM [CRSH]
;

-- 4: How many events were recorded by an event data recorder?
SELECT COUNT (*) AS RECORDEDEVENTCOUNT
FROM [EDREVENT]
;

-- 5: How many vehicle occupants received attention from emergency services?
SELECT COUNT (*) OCCCOUNT
FROM [OCCPNT]
WHERE [EMSDATA] = 1
;

-- 6: How many adjusted jackknife replicate weight entries are there for cases in category 3?
SELECT COUNT (*) CASECOUNT
FROM [JKWGT]
WHERE [CTGRY] = 3
;

-- 7: What is the average weight of adjusted jackknife replicate weight 3
SELECT AVG ([JCKKNFWGHT3]) WGT3AVG
FROM [JKWGT]
;

-- 8: Show the average weight of the adjusted jackknife replicate weight 5 by case category
SELECT [CTGRY], AVG ([JCKKNFWGHT5]) WGT5AVG
FROM [JKWGT]
GROUP BY [CTGRY]
;

-- 9: How many crashes involved a driver with a blood alcohol concentration greater than 250 mg/DL? Actual values range from 0-499. Exclude values greater than 499.
SELECT COUNT (DISTINCT [CS_ID]) CRASHCOUNT
FROM [GEN_VEH]
WHERE [ALCTESTRESULT] > 250 AND [ALCTESTRESULT] < 500
;

-- 10: Show a list of vehicle make, model, and curb weight for all vehicles with a curb weight between 2000 and 3000 kg.
SELECT [V].[MKE], [V].[MODL], [CURBWT]
FROM [GEN_VEH]
JOIN [VPICDECODE] V ON [GEN_VEH].[CS_ID] = [V].[CS_ID] AND [GEN_VEH].[VEHNO] = [V].[VEHNO]
WHERE [CURBWT] > = 2000 AND [CURBWT] < = 3000
;

-- 11: Display a count of vehicle inspections by inspection type
SELECT [INSPTYPE], COUNT (*) AS VEHCOUNT
FROM [GEN_VEH]
GROUP BY [INSPTYPE]
;

-- 12: Display a count of crashes by lighting condition
SELECT [LIGHTCOND], COUNT (DISTINCT [CS_ID])
FROM [GEN_VEH]
GROUP BY [LIGHTCOND]
;

-- 13: How many vehicles are there where drugs were present (presence code value is 1) and the vehicle was towed for a reason not due to disabling damage (towed code is 3)
SELECT COUNT (*) VEHCOUNT
FROM [GEN_VEH]
WHERE [PARDRUG] = 1 AND [TOWD] = 3
;

-- 14: Show a count of vehicles for each type of road rumble strip presence.
SELECT [RUMBROAD], COUNT (*) VEHCOUNT
FROM [GEN_VEH]
GROUP BY [RUMBROAD]
;

-- 15: For each vehicle, show the road speed limit, the highest speed the vehicle was recorded by the event data recorder, and how much higher or lower than the speed limit the vehicle was traveling. Limit travel speed and speedlimit to values less than 300 kph.
SELECT [SPD_LIM], [MAXSPEED], [MAXSPEED] - [SPD_LIM] DIFF
FROM [GEN_VEH]
JOIN (SELECT [CS_ID], [VEHNO], MAX ([PNT_VAL]) MAXSPEED
FROM [EDRPRECRASH]
WHERE [PNT_CODE] = 1010 AND [PNT_VAL] < 300
GROUP BY [CS_ID], [VEHNO]) S ON [GEN_VEH].[CS_ID] = [S].[CS_ID] AND [GEN_VEH].[VEHNO] = [S].[VEHNO]
WHERE [SPD_LIM] < 300
;

-- 16: What is the average length of the first object stuck after the vehicle departs the shoulder or roadway? Valid values range from 0 to 120 centimeters. Ignore values outside of this range.
SELECT AVG ([STRKLENGTH]) AVGLENGTH
FROM [GEN_VEH]
WHERE [STRKLENGTH] BETWEEN 0 AND 120
;

-- 17: How many vehicles are there where there was a yield sign in their environment just prior to the crash? The lookup code for yield sign is 3.
SELECT COUNT (*) VEHCOUNT
FROM [GEN_VEH]
WHERE [TRFC_CTRL_DEV] = 3
;

-- 18: Show the number of vehicles in each intrusion magnitude category
SELECT [INTR_MAGN], COUNT (DISTINCT (CONCAT ([CS_ID], [VEHNO]))) VEHCOUNT
FROM [INTRSN]
GROUP BY [INTR_MAGN]
;

-- 19: Show the number of crashes in each intrusion magnitude category
SELECT [INTR_MAGN], (COUNT (DISTINCT [CS_ID])) CRASHCOUNT
FROM [INTRSN]
GROUP BY [INTR_MAGN]
;

-- 20: Display the Case ID, vehicle number, intrusion components, intrusion magnitude, and intrusion direction for cases with an ID less than 20392
SELECT [CS_ID], [VEHNO], [INTR_COMPNT], [INTR_MAGN], [INTDIRECT]
FROM [INTRSN]
WHERE [CS_ID] < 20392
;

-- 21: What are the intrusion directions for all vehicles in case 20387? Include vehicle number and intrusion direction in the result set.
SELECT [VEHNO], [INTDIRECT]
FROM [INTRSN]
WHERE [CS_ID] = 20387
;

-- 22: Show a count of injuries by body region
SELECT [REGN], COUNT (*) INJCOUNT
FROM [INJUR]
GROUP BY [REGN]
;

-- 23: Show a count of injuries by injury severity
SELECT [ABRV_INJ_SCL], COUNT (*) INJCOUNT
FROM [INJUR]
GROUP BY [ABRV_INJ_SCL]
;

-- 24: How many injuries were caused by an unknown energy source? The lookup code unknown is 999.
SELECT COUNT (*) INJCOUNT
FROM [INJ_CAUS_SCEN]
WHERE [SRC_ENRGY] = 999
;

-- 25: Show a count of injuries by body region where the injury severity is critical. The lookup code for critical injury is 5.
SELECT [REGN], COUNT (*) INJCOUNT
FROM [INJUR]
WHERE [ABRV_INJ_SCL] = 5
GROUP BY [REGN]
;

-- 26: Show a count of injuries by severity where the body region is the spine. The lookup code for spine is 6.
SELECT [ABRV_INJ_SCL], COUNT (*) INJCOUNT
FROM [INJUR]
WHERE [REGN] = 6
GROUP BY [ABRV_INJ_SCL]
;

-- 27: Show a count of minor injuries by vehicle make. The lookup code for minor injuries is 1.
SELECT [MKE], COUNT (*) MINORINJURIES
FROM [VPICDECODE] V
JOIN [INJUR] I ON [V].[CS_ID] = [I].[CS_ID] AND [V].[VEHNO] = [I].[VEHNO]
WHERE [ABRV_INJ_SCL] = 1
GROUP BY [MKE]
;

-- 28: Which vehicle manufacturer has the most neck injuries?
SELECT TOP 1 [MKE]
FROM [VPICDECODE] V
JOIN [INJUR] I ON [V].[CS_ID] = [I].[CS_ID] AND [V].[VEHNO] = [I].[VEHNO]
WHERE [REGN] = 3
GROUP BY [MKE]
ORDER BY COUNT (*)
;

-- 29: What is the average time it takes for emergency services to be notified after a crash occurs? Exclude values greater than 1000
SELECT AVG ([NOTIFIED]) AVGNOTIFICATIONTIME
FROM [EMSCARE]
WHERE [NOTIFIED] < = 1000
;

-- 30: What is the average time it takes for emergency services to arrive at the scene after a crash occurs? Exclude values greater than 1600.
SELECT AVG ([SCENEARR]) AVGARRIVALTIME
FROM [EMSCARE]
WHERE [SCENEARR] < = 1600
;

-- 31: What is the average total time from the time an accident occurs to the time that emergency services depart the scene of an accident? Exclude values greater than 1600.
SELECT AVG ([SCENEDEP]) AVGDEPTIME
FROM [EMSCARE]
WHERE [SCENEDEP] < = 1600
;

-- 32: What is the average total time from the time an accident occurs to the time that emergency medical services arrive at the medical facility? Exclude values greater than 1600.
SELECT AVG ([ARRMEDICAL]) AVGMEDARRIVE
FROM [EMSCARE]
WHERE [ARRMEDICAL] < = 1600
;

-- 33: Make a list that shows the time it took for emergency services to be notified after an accident, the time it took for emergency services to arrive at the scene, the time it took for them to depart the scene, and the time it took for them to arrive at the hospital. Show these times for each crash by case id. Only show cases where an ambulance responded. The lookupcode for ambulance is 1.
SELECT [CS_ID], [NOTIFIED], [SCENEARR], [SCENEDEP], [ARRMEDICAL]
FROM [EMSCARE]
WHERE [EMSTYPE] = 1
;

-- 34: How many toyota tacomas are there in the data?
SELECT COUNT (*) TACOMACOUNT
FROM [VPICDECODE]
WHERE [MKE] = 'TOYOTA' AND [MODL] = 'TACOMA'
;

-- 35: How many of each model year vehicle are there? Present them from oldest to newest.
SELECT [MODL_YR], COUNT (*) VEHCOUNT
FROM [GEN_VEH]
GROUP BY [MODL_YR]
ORDER BY [MODL_YR]
;

-- 36: What vehicle make has the oldest average model year?
SELECT TOP 1 [MKE], AVG ([MODLYR]) AVGYEAR
FROM [VPICDECODE]
GROUP BY [MKE]
ORDER BY [AVGYEAR] ASC
;

-- 37: How many vehicles had no driver present?
SELECT COUNT (*) VEHCOUNT
FROM [GEN_VEH]
WHERE [DRPRESENT] = 0
;

-- 38: How many vehicles are there with the driver's current residence ZIP as 95020?
SELECT COUNT (*) VEHCOUNT
FROM [GEN_VEH]
WHERE [ZIP] = 95020
;

-- 39: Show a count of vehicles by drug test result
SELECT [DRG_TST], COUNT (*)
FROM [GEN_VEH]
GROUP BY [DRG_TST]
;

-- 40: What are the unique category codes for glazing (glass) pre-crash status?
SELECT DISTINCT [GLAZPRE]
FROM [GLZING]
;

-- 41: Show a count of all vehicles grouped by plane of impact
SELECT [CDCPLANE], COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHICLECOUNT
FROM [COLL_DEF_CLASS]
GROUP BY [CDCPLANE]
;

-- 42: How many accidents involved occupant contact with vehicle glazing (aka glass)?
SELECT COUNT (DISTINCT [CS_ID]) ACCIDENTCOUNT
FROM [INTER]
WHERE [GLAZINGCONT] = 1
;

-- 43: What is the most common first manufacture-recommended front tire size? Exclude tire size values of '9999999999'
SELECT TOP 1 [RECMND_FRONT1]
FROM [TIREPLAC] T
WHERE [RECMND_FRONT1] <> '9999999999'
GROUP BY [RECMND_FRONT1]
ORDER BY COUNT (*) DESC
;

-- 44: How many vehicles had damage to the windshield glazing?
SELECT COUNT (*) AS WINDSHIELD_DAMAGE_COUNT
FROM [GLZING]
WHERE [GLAZLOC] = 1
;

-- 45: Display a count of all vehicles by glazing (glass) impact damage category
SELECT [GLAZIMP], COUNT (DISTINCT [VEH_ID_NO]) AS VEHCOUNT
FROM [GLZING] GZ
JOIN [GEN_VEH] ON [GEN_VEH].[CS_ID] = [GZ].[CS_ID] AND [GEN_VEH].[VEHNO] = [GZ].[VEHNO]
GROUP BY [GLAZIMP]
ORDER BY [GLAZIMP]
;

-- 46: How many crashes involved vehicles with after-marked adaptive driving equipment?
SELECT COUNT (*) CRASHCOUNT
FROM [ADPT]
;

-- 47: What is the highest roll angle recorded post-crash by an event data recorder?
SELECT TOP 1 [PNT_VAL]
FROM [EDRPOSTCRASH]
WHERE [PNT_CODE] = 2060
ORDER BY [PNT_VAL] DESC
;

-- 48: Show number of crashes by month in month order
SELECT [CRSHMON], COUNT (*) AS CRASHCOUNT
FROM [CRSH]
GROUP BY [CRSHMON]
ORDER BY [CRSHMON]
;

-- 49: Show the highest speed recorded by the event data recorder for each case for cases where at least one vehicle exceeded 100 (but no more than 200).
SELECT [CS_ID], MAX ([PNT_VAL]) MAXSPEED
FROM [EDRPRECRASH]
WHERE [PNT_CODE] = 1010 AND [PNT_VAL] > 100 AND [PNT_VAL] < 200
GROUP BY [CS_ID]
;

-- 50: Show the highest speed recorded by the event data recorder for each case for cases where at least one vehicle exceeded 160 (but no more than 300). Include the case id, vehicle make and model. Sort from fastest to slowest.
SELECT [PR].[CS_ID], [MKE], [MODL], MAX ([PNT_VAL]) MAXSPEED
FROM [EDRPRECRASH] PR
JOIN [VPICDECODE] V ON [PR].[CS_ID] = [V].[CS_ID] AND [V].[VEHNO] = [PR].[VEHNO]
WHERE [PNT_CODE] = 1010 AND [PNT_VAL] > 160 AND [PNT_VAL] < 300
GROUP BY [PR].[CS_ID], [PR].[VEHNO], [MKE], [MODL]
ORDER BY MAX ([PNT_VAL]) DESC
;

-- 51: What are all the makes of vehicles in the database?
SELECT DISTINCT [MKE]
FROM [VPICDECODE]
;

-- 52: How many different types of injury causation scenarios are there?
SELECT COUNT (DISTINCT [ICS_TYPE]) TYPECOUNT
FROM [INJ_CAUS_SCEN]
;

-- 53: How many injuries are there for each body region?
SELECT [BOD_RGN_INJ], COUNT (*) AS INJURY_COUNT
FROM [INJ_CAUS_SCEN]
GROUP BY [BOD_RGN_INJ]
;

-- 54: What is the average age of all vehicle occupants? Ignore values higher than 130.
SELECT AVG ([AGE]) AVGAGE
FROM [OCCPNT]
WHERE [AGE] < = 130
;

-- 55: Show the average height of all occupants by age. Ignore height values higher than 220 and age values higher than 120. Show in age order from youngest to oldest.
SELECT [AGE], AVG ([HGT]) AVGHEIGHT
FROM [OCCPNT]
WHERE [AGE] < = 120 AND [HGT] < = 220
GROUP BY [AGE]
ORDER BY [AGE] ASC
;

-- 56: How many crashes resulted in the death of a fetus? The lookup value for fetal mortality is 1.
SELECT COUNT (DISTINCT [CS_ID]) DEATHCOUNT
FROM [OCCPNT]
WHERE [FETAL_MORTALTY] = 1
;

-- 57: How many crashes had vehicles where no seatbelt was available because it was removed or destroyed? The lookup value for no belt available due to removal or destruction is 1.
SELECT COUNT (DISTINCT [CS_ID]) NOBELTCOUNT
FROM [OCCPNT]
WHERE [BELTAVAIL] = 1
;

-- 58: How many crashes had an occupant that did not use a seat belt? The codes that correspond to no use are 0 and 1.
SELECT COUNT (DISTINCT [CS_ID]) NOBELTCOUNT
FROM [OCCPNT]
WHERE [BLT_USE] IN (0, 1)
;

-- 59: How many vehicle occupants did not wear a seatbelt even though there was one available? The codes that correspond to no use are 0 and 1. The codes that correspond to a belt being available are 2, 3, 4, 5, 6, 7 and 8.
SELECT COUNT (*) OCCCOUNT
FROM [OCCPNT]
WHERE [BLT_USE] IN (0, 1) AND [BELTAVAIL] IN (2, 3, 4, 5, 6, 7, 8)
;

-- 60: Show me occupant mortality counts by belt use category. A mortality occured (was fatal) indicated by lookup code 1.
SELECT [BLT_USE], COUNT (*) MORTALCOUNT
FROM [OCCPNT]
WHERE [MORTLTY] = 1
GROUP BY [BLT_USE]
;

-- 61: Show the total occupant count and the mortality count by belt use category. A mortality occured (was fatal) indicated by lookup code 1.
SELECT [M].[BLT_USE], [TOTALCOUNT], [MORTALCOUNT]
FROM (SELECT [BLT_USE], COUNT (*) MORTALCOUNT
FROM [OCCPNT]
WHERE [MORTLTY] = 1
GROUP BY [BLT_USE]) M
JOIN (SELECT [BLT_USE], COUNT (*) TOTALCOUNT
FROM [OCCPNT]
GROUP BY [BLT_USE]) T ON [M].[BLT_USE] = [T].[BLT_USE]
;

-- 62: How many vehicles were documented as encountering a direction of force between 150 and 210 degrees inclusive?
SELECT COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHCOUNT
FROM [COLL_DEF_CLASS]
WHERE [PRINC_DIR_FOR] > = 150 AND [PRINC_DIR_FOR] < = 210
;

-- 63: How many crashes are there where the vehicle-to-vehicle heading angle at impact was between 0 and 90 degrees inclusive?
SELECT COUNT (DISTINCT [CS_ID]) CRASHCOUNT
FROM [COLL_DEF_CLASS]
WHERE [HEADINGANG] > = 0 AND [HEADINGANG] < = 90
;

-- 64: What is the maximum depth of crush measured? Codes 888 and 999 should be ignored.
SELECT TOP 1 [CRSH_MAX]
FROM [COLL_DEF_CLASS]
WHERE [CRSH_MAX] NOT IN (888, 999)
ORDER BY [CRSH_MAX] DESC
;

-- 65: How many vehicles had A pillar damage?
SELECT COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHICLECOUNT
FROM [COLL_DEF_CLASS]
WHERE [DAMG_APILLAR] = 1
;

-- 66: How many vehicles had damage to a pillar other than an A, B, or C pillar?
SELECT COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHICLECOUNT
FROM [COLL_DEF_CLASS]
WHERE [DAMG_OTH_PILLAR] = 1
;

-- 67: What is the average difference in crush between the door sill and the door structure for all vehicles where this information was reported? Ignore the codes 888 and 999.
SELECT AVG ([DOORSILLDIFF]) AVGDIFF
FROM [COLL_DEF_CLASS]
WHERE [DOORSILLDIFF] NOT IN (888, 999)
;

-- 68: What is the highest vehicle-to-object collision speed difference recorded? This would equivalent to the speed of the vehicle if it struck a fixed stationary obstacle. 999 indicates an unknown value.
SELECT TOP 1 [DLTV_BARRIER]
FROM [COLL_DEF_CLASS]
WHERE [DLTV_BARRIER] <> 999
ORDER BY [DLTV_BARRIER] DESC
;

-- 69: For each case where measurements were performed, show the case ID, vehicle number, and all of the different crush measurements and the maximum. Codes 888 and 999 indicate that measurements are not available.
SELECT [CS_ID], [VEHNO], [CRSH_MAX], [CRS1_MEAS], [CRS2_MEAS], [CRS3_MEAS], [CRS4_MEAS], [CRS5_MEAS], [CRS6_MEAS]
FROM [COLL_DEF_CLASS]
WHERE [CRSH_MAX] NOT IN (888, 999)
;

-- 70: What are the case ids, vehicle numbers, and event data recording summary numbers of the vehicles that had 10 events recorded in their event data recorder?
SELECT [CS_ID], [VEHNO], [EDR_SUMMNO]
FROM [EDREVENT]
GROUP BY [CS_ID], [VEHNO], [EDR_SUMMNO]
HAVING COUNT (*) = 10
;

-- 71: For each crash, show the case number, event number, and number of time-based datapoints recorded prior to the crash for each event data recorder event.
SELECT [EV].[CS_ID], [EV].[EDREVENTNO], COUNT (*) AS PRECRASHTIMEPOINTS
FROM [EDRPRECRASH] PC
JOIN [EDREVENT] EV ON [PC].[CS_ID] = [EV].[CS_ID] AND [PC].[EDREVENTNO] = [EV].[EDREVENTNO]
GROUP BY [EV].[CS_ID], [EV].[EDREVENTNO]
ORDER BY [CS_ID]
;

-- 72: Show the make, model, manufacture year, and number of ignition cycles of all vehicles with fewer than 200 ignition cycles registered in the event data recorder at the time of crash. Display them by model year older, with the newest models at the top.
SELECT DISTINCT [MKE], [MODL], [MODLYR], [IGN_CYC_CRASH]
FROM [EDREVENT] E
JOIN [VPICDECODE] V ON [E].[CS_ID] = [V].[CS_ID] AND [E].[VEHNO] = [V].[VEHNO]
WHERE [IGN_CYC_CRASH] < 200 AND [IGN_CYC_CRASH] > 0
ORDER BY [MODLYR] DESC
;

-- 73: How many vehicles with fewer than 400, but more than 0, ignition cycles are in the data?
SELECT COUNT (*) AS VEHICLECOUNT
FROM (SELECT DISTINCT [CS_ID], [VEHNO], [IGN_CYC_CRASH]
FROM [EDREVENT]) E
WHERE [IGN_CYC_CRASH] > 0 AND [IGN_CYC_CRASH] < 400
;

-- 74: list all of the cases, vehicle number, occupant number, and number of injuries for cases with an occupant that sustained more than one injury
SELECT [CS_ID], [VEHNO], [OCCNO], COUNT (*) AS INJURY_COUNT
FROM [INJUR]
GROUP BY [CS_ID], [VEHNO], [OCCNO]
HAVING COUNT ([INJNO]) > 1
ORDER BY [INJURY_COUNT] DESC
;

-- 75: How many fires were reported for each fuel type?
SELECT [FUELTP], COUNT (*)
FROM [FIR]
JOIN [FUEL] ON [FIR].[CS_ID] = [FUEL].[CS_ID] AND [FIR].[VEHNO] = [FUEL].[VEHNO]
GROUP BY [FUELTP]
;

-- 76: Show a count of occupant ejections by sex
SELECT [SEX], COUNT (*)
FROM [OCCPNT]
JOIN [EJECT] ON [OCCPNT].[CS_ID] = [EJECT].[CS_ID] AND [OCCPNT].[VEHNO] = [EJECT].[VEHNO] AND [OCCPNT].[OCCNO] = [EJECT].[VEHNO]
GROUP BY [SEX]
;

-- 77: List the number of crashes by vehicle make from most to least
SELECT [MKE], COUNT (*) AS CRASHCOUNT
FROM [VPICDECODE]
GROUP BY [MKE]
ORDER BY [CRASHCOUNT] DESC
;

-- 78: How many crashes involved vehicles that were equipped with crash avoidance features?
SELECT COUNT (DISTINCT [CS_ID]) CRASHCOUNT
FROM [AVOID]
WHERE [AVL] = 1
;

-- 79: What is the most common crash avoidance equipment feature?
SELECT TOP 1 [EQUIP]
FROM [AVOID]
WHERE [AVL] = 1
GROUP BY [EQUIP]
ORDER BY COUNT (*) DESC
;

-- 80: How many vehicles have more than four crash avoidance features?
SELECT COUNT (*) VEHCOUNT
FROM (SELECT [CS_ID], [VEHNO], COUNT ([EQUIP]) FEATURECOUNT
FROM [AVOID]
WHERE [AVL] = 1
GROUP BY [CS_ID], [VEHNO]
HAVING COUNT (*) > 4) SUBQUERY_T
;

-- 81: How many vehicles had tire damage?
SELECT COUNT (*) VEHCOUNT
FROM (SELECT DISTINCT [CS_ID], [VEHNO]
FROM [TIRE_DAM]) T
;

-- 82: How many vehicles have a gross vehicle weight rating less than 4000?
SELECT COUNT (*) VEHCOUNT
FROM [TIREPLAC]
WHERE [GRS_VEH_WT_RTNG] < 4000
;

-- 83: List the Front and rear axle weight ratings for vehicles that have a gross vehicle weight rating between 4000 and 9000
SELECT [GRS_ACTL_WT_RTNG_FRONT], [GRS_ACTL_WT_RTNG_REAR]
FROM [TIREPLAC]
WHERE [GRS_VEH_WT_RTNG] BETWEEN 4000 AND 9000
;

-- 84: Show the average first manufacture recommended front and rear tire pressures for vehicles with a gross vehicle weight rating below 3000.
SELECT AVG ([RECMND_FRONT_PRESSR1]) AVGFRONT, AVG ([RECMND_REAR_PRESSR1]) AVGREAR
FROM [TIREPLAC]
WHERE [GRS_VEH_WT_RTNG] < 3000
;

-- 85: For each of the first manufacturer's recommended front tire sizes, list the average first recommended pressure.
SELECT [RECMND_FRONT1], AVG ([RECMND_FRONT_PRESSR1]) AVGPRESS
FROM [TIREPLAC]
GROUP BY [RECMND_FRONT1]
;

-- 86: Show the first recommended front and rear tire sizes for all of the Subaru WRXs in the dataset.
SELECT [RECMND_FRONT1], [RECMND_REAR1]
FROM [VPICDECODE] V
JOIN [TIREPLAC] T ON [V].[CS_ID] = [T].[CS_ID] AND [V].[VEHNO] = [T].[VEHNO]
WHERE [MKE] = 'SUBARU' AND [MODL] = 'WRX'
;

-- 87: Show the first recommended front and rear tire sizes and pressure levels for all of the Honda Civics manufactured before 2012 in the dataset.
SELECT [RECMND_FRONT1], [RECMND_REAR1], [RECMND_FRONT_PRESSR1], [RECMND_REAR_PRESSR1]
FROM [VPICDECODE] V
JOIN [TIREPLAC] T ON [V].[CS_ID] = [T].[CS_ID] AND [V].[VEHNO] = [T].[VEHNO]
WHERE [MKE] = 'HONDA' AND [MODL] = 'CIVIC' AND [MODLYR] < 2012
;

-- 88: How many vehicles had wrangler model tires?
SELECT COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHCOUNT
FROM [TR]
WHERE [TIREMODL] = 'WRANGLER'
;

-- 89: List the tire model names found on Jeep Wranglers. Ensure only one row per model name.
SELECT DISTINCT [TIREMODL]
FROM [TR] T
JOIN [VPICDECODE] V ON [T].[CS_ID] = [V].[CS_ID] AND [T].[VEHNO] = [V].[VEHNO]
WHERE [MKE] = 'JEEP' AND [MODL] = 'WRANGLER'
;

-- 90: Make a list of tire models and the number of vehicles that had them installed. Display them from most to least common models.
SELECT [TIREMODL], COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) VEHCOUNT
FROM [TR] T
GROUP BY [TIREMODL]
ORDER BY COUNT (DISTINCT CONCAT ([CS_ID], [VEHNO])) DESC
;

-- 91: Make a list of tire models and the number of vehicles with those tires installed where tire damage was observed on at least one tire, as indicated by category values other than 0. Display them from most to least common models. Do not include the unknown damage category value 9.
SELECT [TIREMODL], COUNT (DISTINCT CONCAT ([T].[CS_ID], [T].[VEHNO])) VEHCOUNT
FROM [TR] T LEFT
JOIN [TIRE_DAM] TD ON [T].[CS_ID] = [TD].[CS_ID] AND [T].[VEHNO] = [TD].[VEHNO]
WHERE [DAMG] > 0 AND [DAMG] <> 9
GROUP BY [TIREMODL]
ORDER BY COUNT (DISTINCT CONCAT ([T].[CS_ID], [T].[VEHNO])) DESC
;

-- 92: List the case IDs and vehicle number, recommended and actual tire sizes for vehicles that had a left front tire size that matched the manufacturers first recommended front tire size.
SELECT [T].[CS_ID], [T].[VEHNO], [TIRESZ], [RECMND_FRONT1]
FROM [TR] T
JOIN [TIREPLAC] TP ON [T].[CS_ID] = [TP].[CS_ID] AND [T].[VEHNO] = [TP].[VEHNO]
WHERE [TIRELOC] = 'LF' AND [TIRESZ] = [RECMND_FRONT1]
;

-- 93: List the case IDs, make, model, recommended and actual tire sizes for vehicles that had a left front tire size that did not match the manufacturers first recommended front tire size.
SELECT [T].[CS_ID], [MKE], [MODL], [T].[VEHNO], [TIRESZ], [RECMND_FRONT1]
FROM [TR] T
JOIN [TIREPLAC] TP ON [T].[CS_ID] = [TP].[CS_ID] AND [T].[VEHNO] = [TP].[VEHNO]
JOIN [VPICDECODE] V ON [T].[CS_ID] = [V].[CS_ID] AND [T].[VEHNO] = [V].[VEHNO]
WHERE [TIRELOC] = 'LF' AND [TIRESZ] <> [RECMND_FRONT1]
;

-- 94: Which vehicle make has the most instances of mismatched front left tires? That is, where the left front tire size on the vehicle does not match the manufacturers first recommended front tire size.
SELECT TOP 1 [MKE]
FROM [TR] T
JOIN [TIREPLAC] TP ON [T].[CS_ID] = [TP].[CS_ID] AND [T].[VEHNO] = [TP].[VEHNO]
JOIN [VPICDECODE] V ON [T].[CS_ID] = [V].[CS_ID] AND [T].[VEHNO] = [V].[VEHNO]
WHERE [TIRELOC] = 'LF' AND [TIRESZ] <> [RECMND_FRONT1]
GROUP BY [MKE]
ORDER BY COUNT (DISTINCT [T].[CS_ID]) DESC
;

-- 95: How many accidents were related to distracted driving?
SELECT COUNT (DISTINCT [CS_ID]) DISTRACTACCIDENTCOUNT
FROM [DISTRCT] D
;

-- 96: How many accidents with occupied child seats were related to distracted driving?
SELECT COUNT (DISTINCT [D].[CS_ID]) ACCIDENTCOUNT
FROM [DISTRCT] D
JOIN (SELECT DISTINCT [CS_ID]
FROM [CHLDST]
WHERE [OCCNO] IS NOT NULL) S ON [D].[CS_ID] = [S].[CS_ID]
;

-- 97: List vehicles by make and model and the count of the vehicles that had car seats; order from highest to lowest count.
SELECT [MKE], [MODL], COUNT (*) AS VEHICLE_COUNT
FROM [VPICDECODE] V
JOIN [CHLDST] C ON [V].[CS_ID] = [C].[CS_ID] AND [V].[VEHNO] = [C].[VEHNO]
GROUP BY [MKE], [MODL]
ORDER BY [VEHICLE_COUNT] DESC
;

-- 98: List vehicles by make and model and the count of the vehicles that had child car seats; Provide a separate count of how many of these vehicles had distracted drivers.
SELECT [MKE], [MODL], COUNT (*) AS VEHICLE_COUNT, COUNT ([DISTRACTN]) AS DISTRACTION_COUNT
FROM [VPICDECODE] V
JOIN [CHLDST] C ON [V].[CS_ID] = [C].[CS_ID] AND [V].[VEHNO] = [C].[VEHNO] LEFT
JOIN [DISTRCT] D ON [D].[CS_ID] = [V].[CS_ID] AND [D].[VEHNO] = [V].[VEHNO]
GROUP BY [MKE], [MODL]
ORDER BY [DISTRACTION_COUNT] DESC
;

-- 99: Which vehicle make with more than 5 vehicles in the database has the highest number of distracted drivers in proportion to the total number of the make and model in the data?
SELECT [MKE], COUNT (*) AS VEHICLE_COUNT, COUNT ([DISTRACTN]) AS DISTRACT_COUNT, CAST (COUNT ([DISTRACTN]) AS FLOAT) / CAST (COUNT (*) AS FLOAT) AS PROP_DISTRACT
FROM [VPICDECODE] V LEFT
JOIN [DISTRCT] D ON [V].[CS_ID] = [D].[CS_ID] AND [V].[VEHNO] = [D].[VEHNO]
GROUP BY [MKE]
HAVING COUNT (*) > 5
ORDER BY [PROP_DISTRACT] DESC
;

-- 100: List the number of crashes by vehicle make from most to least. Show how many of these crashes resulted in a fire. Calculate the proportion of total crashes by make to crashes with a fire
SELECT [MKE], COUNT (*) AS CASE_COUNT, SUM ([FIR]) AS FIRE_COUNT, (CAST (SUM ([FIR]) AS FLOAT) / CAST (COUNT (*) AS FLOAT)) AS FIRE_PROPORTION
FROM [VPICDECODE] VD
JOIN [FIR] F ON [F].[CS_ID] = [VD].[CS_ID] AND [F].[VEHNO] = [VD].[VEHNO]
GROUP BY [MKE]
ORDER BY [FIRE_PROPORTION] DESC
;

