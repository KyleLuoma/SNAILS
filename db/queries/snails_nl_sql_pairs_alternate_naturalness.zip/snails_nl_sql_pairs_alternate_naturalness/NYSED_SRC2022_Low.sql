-- 1: What are the accountability level of the indicators 'HS Grad Rate' for the multiracial subgroup for all schools with the word friendship in their name? Include the institution ID, entity name, and accountability level in the result.
SELECT [INSTN_ID], [ENTITY_NAME], [LEVL]
FROM [ACCOUNTABILITY_LEVELS]
WHERE [SUBGRP_NM] = 'Multiracial' AND [INDCTR] = 'HS Grad Rate' AND [ENTITY_NAME] LIKE '%friendship%'
;

-- 2: Show the percent not tested in 2021 on english language assessment ELA4, for each demographic subgroup at PEMBROKE INTERMEDIATE SCHOOL
SELECT [SUBGRP_NM], [PCT_NOT_TESTED]
FROM [ANNUAL_EM_ELA]
WHERE [ENTITY_NAME] = 'PEMBROKE INTERMEDIATE SCHOOL' AND [ASMT_NAME] = 'ELA4' AND [YR] = 2021
;

-- 3: What is the total number of new york state alternate assessment records for assessments performed in 2022
SELECT COUNT (*) ENTRYCOUNT
FROM [ANNUAL_NYSAA]
WHERE [YR] = 2022
;

-- 4: Show the student count, federal expenditure, and federal expenditure per student in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT [PUPIL_COUNT_TOT], [FEDERAL_EXP], [PER_FEDERAL_EXP]
FROM [EXPENDITURES_PER_PUPIL]
WHERE [ENTITY_NAME] = 'MONTESSORI MAGNET SCHOOL' AND [YR] = 2022
;

-- 5: Show the student count, federal expenditure, federal expenditure per student, subgroup name, and mean math assessment score for the MATH5 assessment in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT [PUPIL_COUNT_TOT], [FEDERAL_EXP], [PER_FEDERAL_EXP], [SUBGRP_NM], [MEAN_SCORE]
FROM [EXPENDITURES_PER_PUPIL] EX
JOIN [ANNUAL_EM_MATH] MTH ON [EX].[ENTITY_CD] = [MTH].[ENTITY_CD] AND [EX].[YR] = [MTH].[YR]
WHERE [EX].[ENTITY_NAME] = 'MONTESSORI MAGNET SCHOOL' AND [ASMT_NAME] = 'MATH5' AND [EX].[YR] = 2022
;

-- 6: Show the 2022 high school participation rates and graduation rates for the subgroup 'All Students' who attended Brooklyn Collegiate.
SELECT [RT], [GRAD_RATE]
FROM [ACC_HS_PARTICIPATION_RATE] P
JOIN [ACC_HS_GRADUATION_RATE] G ON [P].[ENTITY_CD] = [G].[ENTITY_CD] AND [P].[SUBGRP_NM] = [G].[SUBGRP_NM] AND [P].[YR] = [G].[YR] AND [P].[ENTITY_NAME] = [G].[ENTITY_NAME] AND [P].[INSTN_ID] = [G].[INSTN_ID]
WHERE [P].[ENTITY_NAME] = 'Brooklyn Collegiate' AND [P].[SUBGRP_NM] = 'All Students' AND [P].[YR] = 2022
;

-- 7: What is Kenney Middle School's 2021 enrollment, absentee count, and absentee rate for the subgroup of students with disabilities?
SELECT [ENRLMNT], [ABSENT_COUNT], [ABSENT_RATE]
FROM [ACC_EM_CHRONIC_ABSENTEEISM]
WHERE [ENTITY_NAME] = 'KENNEY MIDDLE SCHOOL' AND [YR] = 2021 AND [SUBGRP_NM] = 'Students with disabilities'
;

-- 8: Show the annual regents exam percent of LONGWOOD HIGH SCHOOL students at each level from 1 to 5 for the Regents Common Core Algebra I subject taken in 2022. Include the subgroup name, number of students tested, and all of the appropriate percent level score columns.
SELECT [SUBGRP_NM], [TSTD], [PER_LEVEL1], [PER_LEVEL2], [PER_LEVEL3], [PER_LEVEL4], [PER_LEVEL5]
FROM [ANNUAL_REGENTS_EXAMS]
WHERE [ENTITY_NAME] LIKE '%LONGWOOD HIGH SCHOOL%' AND [YR] = 2022 AND [SBJCT] = 'Regents Common Core Algebra I'
;

-- 9: How many public school entities are in each accountability status in the year 2022?
SELECT [OVRLL_STS], COUNT (*) STATUSCOUNT
FROM [ACCOUNTABILITY_STATUS]
WHERE [YR] = 2022 AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
GROUP BY [OVRLL_STS]
;

-- 10: What is the accountability status and progress status of the  bronx career and college prep HS in 2022?
SELECT [OVRLL_STS], [MD_PRGS]
FROM [ACCOUNTABILITY_STATUS]
WHERE [ENTITY_NAME] = 'bronx career and college prep hs' AND [YR] = 2022
;

-- 11: what are the combined subject, core and weighted, performance scores for elementary students with disabilities who attended May Moore Primary School?
SELECT [CORE_COHORT], [WGT_COHT]
FROM [ACC_EM_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [ENTITY_NAME] = 'May Moore Primary School' AND [SBJCT] = 'combined' AND [SUBGRP_NM] = 'Students with Disabilities'
;

-- 12: Make a list of public elementary school entities that do not have the subgroup 'students with disabilities' in the elementary core and weighted performance data.
SELECT DISTINCT [ENTITY_NAME]
FROM [ACC_EM_CORE_AND_WEIGHTED_PERFORMANCE] P
WHERE NOT EXISTS (SELECT [ENTITY_CD]
FROM [ACC_EM_CORE_AND_WEIGHTED_PERFORMANCE] Q
WHERE [SUBGRP_NM] = 'Students with Disabilities' AND [P].[ENTITY_CD] = [Q].[ENTITY_CD]) AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 13: How many public elementary school entities have the subgroup 'multiracial' included in the core and weighted performance data?
SELECT COUNT (DISTINCT [ENTITY_CD]) SCHOOLCOUNT
FROM [ACC_EM_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [SUBGRP_NM] = 'multiracial' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 14: Show the school name and english language learner count for the subgroup 'all students' for public school entities that have the word preparatory in their name.
SELECT [ENTITY_NAME], [ENG_LANG_LEARN_COUNT]
FROM [ACC_EM_ELP]
WHERE [SUBGRP_NM] = 'all students' AND [ENTITY_NAME] LIKE '%preparatory%'
;

-- 15: How many public elementary school entities have white student subgroups who are english language learners?
SELECT COUNT (*) SCHOOLCOUNT
FROM [ACC_EM_ELP]
WHERE [SUBGRP_NM] = 'white' AND [ENG_LANG_LEARN_COUNT] <> '0' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 16: What is the english language learner count, benchmark, progress rate, and success ratio for the sub group all students at 'pine bush' elementary school?
SELECT [ENG_LANG_LEARN_COUNT], [BENCHMK], [PRGS_RATE], [SUCC_RATIO]
FROM [ACC_EM_ELP]
WHERE [ENTITY_NAME] = 'PINE BUSH' AND [SUBGRP_NM] = 'All Students'
;

-- 17: How many public elementary school entities had 0 participation in the new york state english as a second language achievement test?
SELECT COUNT (DISTINCT [ENTITY_CD]) NOPARTCOUNT
FROM [ACC_EM_NYSESLAT_FOR_PARTICIPATION]
WHERE [NYSTATENGSECLANGASMTTSTS_PART] = '0' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 18: How many different new york state english as a second language achievement test elementary school subjects are there?
SELECT COUNT (DISTINCT [SBJCT]) SUBJECTCOUNT
FROM [ACC_EM_NYSESLAT_FOR_PARTICIPATION]
;

-- 19: Show the names of the public elementary school entities with level 2 english learner programs that have a non-zero number of english language learners in the all students subgroup, who did not participate in the new york state english as a second language achievement test. Include only one row per school name.
SELECT DISTINCT [ENTITY_NAME]
FROM [ACC_EM_ELP]
WHERE [ENTITY_CD] IN (SELECT DISTINCT [ENTITY_CD]
FROM [ACC_EM_NYSESLAT_FOR_PARTICIPATION]
WHERE [NYSTATENGSECLANGASMTTSTS_PART] = '0') AND [ENG_LANG_LEARN_COUNT] <> '0' AND [SUBGRP_NM] = 'all students' AND [LEVL] = '2' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 20: What is the 2022 cohort size and student participation rate for all sub groups and subjects at elmwood elementary school?
SELECT [SUBGRP_NM], [SBJCT], [COHRT], [RT]
FROM [ACC_EM_PARTICIPATION_RATE]
WHERE [ENTITY_NAME] = 'elmwood elementary school' AND [YR] = 2022
;

-- 21: How many public elementary school entities met a 95 percent participation rate in at least one subject?
SELECT COUNT (DISTINCT [ENTITY_CD]) SCHOOLCOUNT
FROM [ACC_EM_PARTICIPATION_RATE]
WHERE [MET_95PCT] = 'Y' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 22: For public elementary school participation rates not equal to s, calculate the average participation rate.
SELECT AVG (CAST ([RT] AS FLOAT)) AS AVGRATE
FROM [ACC_EM_PARTICIPATION_RATE]
WHERE [RT] <> 's' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
;

-- 23: For each subject, show the average public high school entity chronic absence rate for records where the rate does not equal 's'.
SELECT [SBJCT], AVG (CAST ([ABSENT_RATE] AS FLOAT)) AVGRATE
FROM [ACC_EM_CHRONIC_ABSENTEEISM]
WHERE [ABSENT_RATE] <> 's' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School')
GROUP BY [SBJCT]
;

-- 24: Show the name of the public elementary school entity that has the lowest chronic absence rate of students with disabilities. Exclude data where the rate value is 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [ACC_EM_CHRONIC_ABSENTEEISM]
WHERE [SUBGRP_NM] = 'students with disabilities' AND [ABSENT_RATE] <> 's'
ORDER BY CAST ([ABSENT_RATE] AS FLOAT) DESC
;

-- 25: show the school name, sub group name, and total enrollment at public elementary school entities that have the highest absenteeism rate in 2022. Exclude data where the absenteeism rate is 's'.
SELECT [A].[ENTITY_NAME], [SUBGRP_NM], [ENRLMNT]
FROM [ACC_EM_CHRONIC_ABSENTEEISM] A
JOIN [INSTITUTION_GROUPING] G ON [A].[ENTITY_CD] = [G].[ENTITY_CD]
WHERE CAST ([ABSENT_RATE] AS FLOAT) = (SELECT MAX (CAST ([ABSENT_RATE] AS FLOAT))
FROM [ACC_EM_CHRONIC_ABSENTEEISM]
WHERE [ABSENT_RATE] <> 's' AND [YR] = 2022) AND [ABSENT_RATE] <> 's' AND [YR] = 2022 AND [GRP_NM] = 'public school'
;

-- 26: What is the average public high school entity chronic absenteeism rate by student sub group in 2021? Do not include rows where the rate is 's'.
SELECT [SUBGRP_NM], AVG (CAST ([ABSENT_RATE] AS FLOAT)) AVGRATE
FROM [ACC_HS_CHRONIC_ABSENTEEISM] A
JOIN [INSTITUTION_GROUPING] G ON [A].[ENTITY_CD] = [G].[ENTITY_CD]
WHERE [ABSENT_RATE] <> 's' AND [GRP_NM] = 'Public School'
GROUP BY [SUBGRP_NM]
;

-- 27: What is the 2021 chronic absenteeism count and rate for the sub group 'All students' at the public high school entity with the highest enrollment? Exclude enrollment data that has the value 's'. Include the school name in the result.
SELECT TOP 1 [ENTITY_NAME], [ABSENT_COUNT], [ABSENT_RATE]
FROM [ACC_HS_CHRONIC_ABSENTEEISM]
WHERE [ENRLMNT] <> 's' AND [YR] = 2021 AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'Public School') AND [SUBGRP_NM] = 'All Students'
ORDER BY CAST ([ENRLMNT] AS FLOAT) DESC
;

-- 28: What are the core and weighted cohorts, and the core and weighted performance indexes of Economically Disadvantaged Students at Albany High School in the Math subject in 2022?
SELECT [CORE_COHORT], [WGT_COHT], [CR_IDX], [WGT_INDEX]
FROM [ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [YR] = 2022 AND [SBJCT] = 'MATH' AND [SUBGRP_NM] = 'Economically Disadvantaged' AND [ENTITY_NAME] = 'ALBANY HIGH SCHOOL'
;

-- 29: What are the names of the five public high school entity that have the highest weighted performance index score in math for the all student sub group in 2022? Exclude the value 's' from the index score.
SELECT TOP 5 [P].[ENTITY_NAME]
FROM [ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE] P
JOIN [INSTITUTION_GROUPING] G ON [P].[ENTITY_CD] = [G].[ENTITY_CD]
WHERE [WGT_INDEX] <> 's' AND [GRP_NM] = 'Public School' AND [SBJCT] = 'MATH' AND [SUBGRP_NM] = 'All Students' AND [YR] = 2022
ORDER BY CAST ([WGT_INDEX] AS FLOAT) DESC
;

-- 30: Show the school name and the average weighted index subject score for science for the five lowest scoring public school districts. Exclude weighted index scores with the value 's'.
SELECT TOP 5 [ENTITY_NAME], AVG (CAST ([WGT_INDEX] AS FLOAT)) AVERAGESCIENCESCORE
FROM [ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE]
WHERE [WGT_INDEX] <> 's' AND [SBJCT] = 'SCIENCE' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school district')
GROUP BY [ENTITY_NAME]
ORDER BY AVG (CAST ([WGT_INDEX] AS FLOAT)) ASC
;

-- 31: What is the 2022 english language learner count, benchmark size, progress rate, success ration, and level of the english language program at Alfred E Smith Career-Tech HS for the all students subgroup?
SELECT [ENG_LANG_LEARN_COUNT], [BENCHMK], [PRGS_RATE], [SUCC_RATIO], [LEVL]
FROM [ACC_HS_ELP]
WHERE [ENTITY_NAME] = 'ALFRED E SMITH CAREER-TECH HS' AND [SUBGRP_NM] = 'All Students' AND [YR] = 2022
;

-- 32: What is the average english language learner count at public high schools for each student subgroup?
SELECT [SUBGRP_NM], AVG (CAST ([ENG_LANG_LEARN_COUNT] AS FLOAT)) ELLAVG
FROM [ACC_HS_ELP]
WHERE [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school')
GROUP BY [SUBGRP_NM]
;

-- 33: What is the 2022 federal expenditure per student at the public high school with the highest english language learner count in the All Students sub group in their english language program? Include the school name, language learner count, and federal expenditure per student in the result.
SELECT TOP 1 [EL].[ENTITY_NAME], [ENG_LANG_LEARN_COUNT], [PER_FEDERAL_STATE_LOCAL_EXP]
FROM [ACC_HS_ELP] EL
JOIN [EXPENDITURES_PER_PUPIL] EX ON [EL].[ENTITY_CD] = [EX].[ENTITY_CD] AND [EL].[YR] = [EX].[YR]
WHERE [SUBGRP_NM] = 'All Students' AND [ENG_LANG_LEARN_COUNT] <> 's' AND [EX].[YR] = 2022 AND [EL].[ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school district')
ORDER BY CAST ([ENG_LANG_LEARN_COUNT] AS FLOAT) DESC
;

-- 34: For each year and status type, what is the number of entities in accountability each status for the all students subgroup?
SELECT [YR], [OVRLL_STS], COUNT (*) ENTCOUNT
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [SUBGRP_NM] = 'All Students'
GROUP BY [YR], [OVRLL_STS]
;

-- 35: How many high schools (HS) had an accountability status of good standing in 2021 for the Multiracial sub group?
SELECT COUNT (*) HSCOUNT
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [SCHL_TYPE] = 'HS' AND [SUBGRP_NM] = 'Multiracial' AND [YR] = 2021
;

-- 36: What is the overall acountability status for each school type and student subgroup in 2021 for the entity named 'albany city SD'?
SELECT [SCHL_TYPE], [SUBGRP_NM], [OVRLL_STS]
FROM [ACCOUNTABILITY_STATUS_BY_SUBGROUP]
WHERE [YR] = 2021 AND [ENTITY_NAME] = 'ALBANY CITY SD'
;

-- 37: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each science assessment? Exclude scores with the value 's'.
SELECT [ASMT_NAME], AVG (CAST ([LVL1_%TSTD] AS FLOAT)) L1, AVG (CAST ([LVL2_%TSTD] AS FLOAT)) L2, AVG (CAST ([LEVEL3_%TESTED] AS FLOAT)) L3, AVG (CAST ([LVL4_%TSTD] AS FLOAT)) L4
FROM [ANNUAL_EM_SCIENCE]
WHERE [LVL1_%TSTD] <> 's' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school')
GROUP BY [ASMT_NAME]
;

-- 38: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each sub group for the Science8 assessment? Exclude scores with the value 's'.
SELECT [SUBGRP_NM], AVG (CAST ([LVL1_%TSTD] AS FLOAT)) L1, AVG (CAST ([LVL2_%TSTD] AS FLOAT)) L2, AVG (CAST ([LEVEL3_%TESTED] AS FLOAT)) L3, AVG (CAST ([LVL4_%TSTD] AS FLOAT)) L4
FROM [ANNUAL_EM_SCIENCE]
WHERE [LVL1_%TSTD] <> 's' AND [ASMT_NAME] = 'Science8' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school')
GROUP BY [SUBGRP_NM]
;

-- 39: How many different subjects are present in the new york state english as a second language achievement test data?
SELECT COUNT (DISTINCT [SBJCT]) SUBJECTCOUNT
FROM [ANNUAL_NYSESLAT]
;

-- 40: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the expanding level on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [PREXP]
FROM [ANNUAL_NYSESLAT]
WHERE [SUBGRP_NM] = 'Parent Not In Armed Forces' AND [SBJCT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YR] = 2021
;

-- 41: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [PER_ENT], [PER_EMER], [PER_TRAN], [PREXP]
FROM [ANNUAL_NYSESLAT]
WHERE [SUBGRP_NM] = 'Parent Not In Armed Forces' AND [SBJCT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YR] = 2021
;

-- 42: For each subject, what is the average percent of students scoring at the entering level on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT [SBJCT], AVG (CAST ([PER_ENT] AS FLOAT)) AVGSCORE
FROM [ANNUAL_NYSESLAT]
WHERE [PER_ENT] <> 's' AND [YR] = 2021 AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school district')
GROUP BY [SBJCT]
;

-- 43: For each subject, what is the average percent of students scoring at the entering level, the emerging level, the transitioning level, the expanding level, or the commanding level, on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT [SBJCT], AVG (CAST ([PER_ENT] AS FLOAT)) AVGENT, AVG (CAST ([PER_EMER] AS FLOAT)) AVGEMER, AVG (CAST ([PER_TRAN] AS FLOAT)) AVGTRAN, AVG (CAST ([PREXP] AS FLOAT)) AVGEXP, AVG (CAST ([PER_COM] AS FLOAT)) AVGCOM
FROM [ANNUAL_NYSESLAT]
WHERE [PER_ENT] <> 's' AND [YR] = 2021 AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school district')
GROUP BY [SBJCT]
;

-- 44: What is the number of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT [NUM_ENT], [NUM_EMER], [NUM_TRAN], [NUM_EXP]
FROM [ANNUAL_NYSESLAT]
WHERE [SUBGRP_NM] = 'Parent Not In Armed Forces' AND [SBJCT] = 'TS_6' AND [ENTITY_NAME] = 'JOHANNA PERRIN MIDDLE SCHOOL' AND [YR] = 2021
;

-- 45: How many schools are a part of each board of cooperative educational services in 2020? Show the board name and the count of schools.
SELECT [BRD_OF_COOP_ED_SVS_NAME], COUNT (DISTINCT [SCHL_NM]) SCHOOLCOUNT
FROM [BOCES_AND_N/RC]
WHERE [YR] = 2020
GROUP BY [BRD_OF_COOP_ED_SVS_NAME]
;

-- 46: How many schools are a part of each county in 2020? Show the county name and the count of schools.
SELECT [CNTY_NM], COUNT (DISTINCT [SCHL_NM]) SCHOOLCOUNT
FROM [BOCES_AND_N/RC]
WHERE [YR] = 2020
GROUP BY [CNTY_NM]
;

-- 47: For each board of cooperative educational services in 2021, show the average federal and state and local expenditures_per_pupil. Include the board name and average expenditures in the result.
SELECT [BRD_OF_COOP_ED_SVS_NAME], AVG (CAST ([PER_FEDERAL_EXP] AS FLOAT)) AVGFEDEXP, AVG (CAST ([PER_STATE_LOCAL_EXP] AS FLOAT)) AVGLOCEXP
FROM [BOCES_AND_N/RC] B
JOIN [EXPENDITURES_PER_PUPIL] E ON [B].[ENTITY_CD] = [E].[ENTITY_CD] AND [B].[YR] = [E].[YR]
WHERE [B].[YR] = 2021
GROUP BY [BRD_OF_COOP_ED_SVS_NAME]
;

-- 48: How many board of cooperative educational services are there?
SELECT COUNT (DISTINCT [BRD_OF_COOP_ED_SVS_NAME]) BOCESCOUNT
FROM [BOCES_AND_N/RC]
;

-- 49: Show the names of the board of cooperative educational services and the number of counties, for boards that have more than one county.
SELECT [BRD_OF_COOP_ED_SVS_NAME], COUNT (DISTINCT [CNTY_NM]) COUNTYCOUNT
FROM [BOCES_AND_N/RC]
GROUP BY [BRD_OF_COOP_ED_SVS_NAME]
HAVING COUNT (DISTINCT [CNTY_NM]) > 1
;

-- 50: Show the number of teachers, number of inexperienced teaches, and percentage of inexperienced teaches at sheridan prep academy in 2021.
SELECT [NUM_TEACH], [NUM_TEACH_INEXP], [PER_TEACH_INEXP]
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS]
WHERE [ENTITY_NAME] = 'SHERIDAN PREP ACADEMY' AND [YR] = 2021
;

-- 51: What are the entity codes, names and percentage inexperience teachers, of the five public schools with the highest percentage of inexperienced teachers in 2021?
SELECT TOP 5 [I].[ENTITY_CD], [I].[ENTITY_NAME], [PER_TEACH_INEXP]
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS] I
JOIN [INSTITUTION_GROUPING] G ON [I].[ENTITY_CD] = [G].[ENTITY_CD]
WHERE [YR] = 2021 AND [GRP_NM] = 'public school'
ORDER BY [PER_TEACH_INEXP] DESC
;

-- 52: What is the average percantage of inexperienced teachers for the five school districts with the highest average? Include the district name in the result.
SELECT TOP 5 [DSTRCT_NM], AVG ([PER_TEACH_INEXP]) TEACHCOUNT
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS] I
JOIN [BOCES_AND_N/RC] B ON [I].[ENTITY_CD] = [B].[ENTITY_CD]
GROUP BY [DSTRCT_NM]
ORDER BY AVG ([PER_TEACH_INEXP]) DESC
;

-- 53: What is the average of the total number of teachers and principals in low-poverty schools statewide?
SELECT AVG ([TOT_PRINC_LOW]) PRINCLOW, AVG ([TOT_TEACH_LOW]) TEACHLOW
FROM [INEXPERIENCED_TEACHERS_AND_PRINCIPALS]
;

-- 54: In 2022, How many students in either the male or the female subgroup at Brocton Middle High School attended an out of state, four-year postsecondary institution?
SELECT SUM (CAST ([CNT_ENR_OUT_ST_4YR_INST] AS INT)) STUDENTCOUNT
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [SUBGRP_NM] IN ('male', 'female') AND [ENTITY_NAME] = 'BROCTON MIDDLE HIGH SCHOOL'
;

-- 55: For the 2022 subgroup 'All Students' at Oneida Senior High School, what is the total graduate count, the percent of graduates who enrolled in a new york state public two-year postsecondary institution, and the percent of graduates who enrolled in a new york state public four-year postsecondary institution?
SELECT [PERCT_ENR_NY_ST_PUBL_2YR_INST], [PERCT_ENR_NY_ST_PUBL_4YR_INST]
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [YR] = 2022 AND [ENTITY_NAME] = 'ONEIDA SENIOR HIGH SCHOOL' AND [SUBGRP_NM] = 'All Students'
;

-- 56: What is the name of the public school district that had the most teachers teaching out of certification in 2021?
SELECT TOP 1 [ENTITY_NAME]
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION]
WHERE [YR] = 2021 AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school district')
ORDER BY [NUM_OUT_CERT] DESC
;

-- 57: In 2021, what was the number and percentage of teachers out of certification at bolton central school?
SELECT [NUM_OUT_CERT], [PER_OUT_CERT]
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION]
WHERE [ENTITY_NAME] = 'BOLTON CENTRAL SCHOOL' AND [YR] = 2021
;

-- 58: Show the county name and total number of teachers teaching out of certification in each county.
SELECT [CNTY_NM], SUM ([NUM_OUT_CERT]) OOCCOUNT
FROM [TEACHERS_TEACHING_OUT_OF_CERTIFICATION] C
JOIN [BOCES_AND_N/RC] B ON [C].[ENTITY_CD] = [B].[ENTITY_CD]
GROUP BY [CNTY_NM]
;

-- 59: Show the subgroup name, cohort count, the number of students with a valid score, the number of students scoring at levels 1 through 4 for the male and female subgroups at waverly high school in the 2017 cohort.
SELECT [SUBGRP_NM], [COHRT_CNT], [TST_CNT], [LEVEL1_COUNT], [LEVEL2_COUNT], [LEVEL3_COUNT], [LEVEL4_COUNT]
FROM [TOTAL_COHORT_REGENTS_EXAMS]
WHERE [ENTITY_NAME] = 'WAVERLY HIGH SCHOOL' AND [COHRT] = 2017 AND [SUBGRP_NM] IN ('female', 'male') AND [SBJCT] = 'MATH'
;

-- 60: What is the name of the public school entity that had the highest percent of level four regents math exam scores in the 2017 student cohort and in the 'all students' sub group? Exclude score percentage values of 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [TOTAL_COHORT_REGENTS_EXAMS]
WHERE [COHRT] = 2017 AND [SUBGRP_NM] = 'All Students' AND [SBJCT] = 'MATH' AND [LEVEL4_%COHORT] <> 's' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school')
ORDER BY CAST ([LEVEL4_%COHORT] AS INT) DESC
;

-- 61: How many different elementary school math assessment types are there?
SELECT COUNT (DISTINCT [ASMT_NAME]) ASSESSMENTCOUNT
FROM [ANNUAL_EM_MATH]
;

-- 62: How many  elementary students in the male sub group were given the Science4 assessment in 2021 at FORTS FERRY SCHOOL?
SELECT [TTL_CNT]
FROM [ANNUAL_EM_SCIENCE]
WHERE [YR] = 2021 AND [SUBGRP_NM] = 'male' AND [ASMT_NAME] = 'Science4' AND [ENTITY_NAME] = 'FORTS FERRY SCHOOL'
;

-- 63: What is the name of the public school entity that had the highest percentage of out-of-state four year postsecondary enrollments in 2022? Exclude percantage values of 's'.
SELECT TOP 1 [ENTITY_NAME]
FROM [POSTSECONDARY_ENROLLMENT]
WHERE [YR] = 2022 AND [SUBGRP_NM] = 'All Students' AND [PERCT_ENR_OUT_ST_4YR_INST] <> 's' AND [ENTITY_CD] IN (SELECT [ENTITY_CD]
FROM [INSTITUTION_GROUPING]
WHERE [GRP_NM] = 'public school')
ORDER BY CAST ([PERCT_ENR_OUT_ST_4YR_INST] AS INT) DESC
;

