-- 1: How many different internal reconciliation types are there?
SELECT COUNT (DISTINCT [RECONCILIATION_TYPE]) NUMTYPES
FROM [INTERNAL_RECONCILIATION_TABLE]
;

-- 2: Show the payee names, zip, city, street, country, and states for the payees with the user department named 'General'
SELECT [PAYEENAME], [PAYEEZIP], [PAYEECITY], [PAYEE_STREET], [PAYCOUNTRY], [PAYEESTATE]
FROM [DEPARTMENTS_TABLE] DEPARTMENTS
JOIN [PAYMENT_RESULTS_TABLE] PAYMENTRESULTSTABLE ON [DEPARTMENTS].[CODE] = [PAYMENTRESULTSTABLE].[DEPARTMENT]
WHERE [DEPARTMENTS].[NAME] = 'General'
;

-- 3: What are the account numbers that have checks for payment with more than one line? Include only one entry per account number.
SELECT DISTINCT [ACCOUNT_NUMBER]
FROM [CHECKS_FOR_PAYMENT_TABLE] O
JOIN [CHECKS_FOR_PAYMENT_ROWS] ON [O].[CHECKKEY] = [CHECKS_FOR_PAYMENT_ROWS].[CHECKKEY]
GROUP BY [ACCOUNT_NUMBER], [O].[CHECKKEY]
HAVING COUNT (*) > 1
;

-- 4: What are the witholding tax deduction amounts and percents for checks for payment associated with the account with account number '100-3443-7867'?
SELECT [DEDUCTION], [WITHHOLDING_TAX_DEDUCTION_PERCENTAGE]
FROM [CHECKS_FOR_PAYMENT_TABLE]
WHERE [ACCOUNT_NUMBER] = '100-3443-7867'
;

-- 5: What is the card code, card name, address, and functional currency transfer amount for the incoming payments created in the year 2012 where the document summary currency code is 'EUR'
SELECT [CARDCODE], [CARDNAME], [ADDRESS], [TRANSFER_AMOUNT_FUNCTIONAL_CURRENCY]
FROM [INCOMING_PAYMENT_TABLE]
WHERE YEAR ([CREATEDATE]) = 2012 AND [DOCUMENTCURRENCY] = 'EUR'
;

-- 6: What is the Withholding tax posted, account number, and functional currency sum for the incoming checks with the country code 'CA'
SELECT [WITHHOLDING_TAX_POSTED], [ACCOUNT_NUMBER], [CHECK_AMOUNT_FUNCTIONAL_CURRENCY]
FROM [INCOMING_PAYMENT_TABLE]
JOIN [INCOMING_PAYMENT_CHECKS] ON [INCOMING_PAYMENT_TABLE].[DOCUMENT_NUMBER] = [INCOMING_PAYMENT_CHECKS].[DOCUMENT_NUMBER]
WHERE [COUNTRY_CODE] = 'CA'
;

-- 7: How many incoming invoices document an applied value added tax of more than 700?
SELECT COUNT (*) INVOICECOUNT
FROM [INCOMING_PAYMENTS_INVOICES_TABLE]
WHERE [VALUE_ADDED_TAX_APPLIED] > 700
;

-- 8: For incoming payments processed with credit vouchers, show the average of the sums of the first partial payments.
SELECT AVG ([FIRST_PARTIAL_PAYMENT]) FIRSTPMTAVG
FROM [INCOMING_PAYMENT_TABLE]
JOIN [INCOMING_PAYMENT_CREDIT_VOUCHERS] ON [INCOMING_PAYMENT_TABLE].[DOCUMENT_NUMBER] = [INCOMING_PAYMENT_CREDIT_VOUCHERS].[DOCUMENT_NUMBER]
;

-- 9: List the receipt number, card payment internal ID, and card account code for the credit card deposit deposited on 2012-01-31.
SELECT [RECEIPT_NUMBER_ABSTRACT], [DEPOSIT_NUMBER], [CARDCODE]
FROM [CREDIT_CARD_MANAGEMENT_TABLE]
WHERE [DEPOSIT_DATE] = '2012-01-31'
;

-- 10: For the payment term with the term group code 'Net30', show the number of additional days, number of installments, and whether or not value added tax is applied on the first installment.
SELECT [EXTRADAYS], [NUMBER_OF_INSTALLMENTS], [APPLY_TAX_ON_FIRST_INSTALLMENT]
FROM [PAYMENT_TERMS_TABLE]
WHERE [PAYMENT_GROUP] = 'Net30'
;

