-- 1: Show the group name and count of business partners in each card group
SELECT [G_NM], COUNT (*) PARTNERCOUNT
FROM [OCRG]
JOIN [OCRD] ON [OCRG].[GP_CD] = [OCRD].[GP_CD]
GROUP BY [G_NM]
;

-- 2: Make a contact roster that includes the name, address, cell phone number, and email address of all persons currently in either a CEO or COO position.
SELECT [NM], [ADDR], [CEL], [E_MAILL]
FROM [OCPR]
WHERE [PSN] = 'CEO' OR [PSN] = 'COO'
;

-- 3: What is the commission rate of the sales employee named Bill Levine?
SELECT [CMSSN]
FROM [OSLP]
WHERE [SENM] = 'Bill Levine'
;

-- 4: What are the names of sales employees in the high commission group?
SELECT [SENM]
FROM [OSLP]
JOIN [OCOG] ON [OSLP].[GP_CD] = [OCOG].[GP_CD]
WHERE [G_NM] = 'High Commission'
;

-- 5: What are the names, mobile phone numbers, and email addresses of sales employees in the high commission group?
SELECT [SENM], [MBL], [EML]
FROM [OSLP]
JOIN [OCOG] ON [OSLP].[GP_CD] = [OCOG].[GP_CD]
WHERE [G_NM] = 'High Commission'
;

-- 6: Display the payment code and tax code for current business partners whos closing date procedure number is lower than 35
SELECT [PMC], [TX_CD]
FROM [OCRD]
JOIN [CRD1] ON [OCRD].[CRD_C] = [CRD1].[CRD_C]
WHERE [CDPNUM] < 35
;

-- 7: List the activity number, contact time and date, and the details of all activities created in the year 2021
SELECT [CLG_CD], [CT_DT], [CTTM], [DTLS]
FROM [OCLG]
WHERE YEAR ([CRTDT]) = '2021'
;

-- 8: Show the bank details, to include bank code, country, account number, branch, and city, for the business partner with the card name Microchips
SELECT [OCRB].[B_CD], [OCRB].[CTRY], [ACCT], [BCH], [OCRB].[CT]
FROM [OCRD]
JOIN [OCRB] ON [OCRD].[CRD_C] = [OCRD].[CRD_C]
WHERE [CD_NM] = 'Microchips'
;

-- 9: what is the account balance of the business partner with the payment method code 'Incoming BT' and a currency type that is either 'EUR' or 'CAN'
SELECT [BAL]
FROM [OCRD]
WHERE [CUR] IN ('EUR', 'CAN') AND [OCRD].[PMC] = 'Incoming BT'
;

-- 10: What is the email address and federal tax ID of the target with the position of CIO that is of target type C?
SELECT [E_ML], [LTN]
FROM [TGG1]
JOIN [OTGG] ON [TGG1].[TGTCD] = [OTGG].[TGTCD]
WHERE [PSN] = 'CIO' AND [TGTTYP] = 'C'
;

