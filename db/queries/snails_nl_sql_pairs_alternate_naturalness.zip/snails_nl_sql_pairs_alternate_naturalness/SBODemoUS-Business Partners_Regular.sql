-- 1: Show the group name and count of business partners in each card group
SELECT [GROUPNAME], COUNT (*) PARTNERCOUNT
FROM [CARD_GROUPS]
JOIN [BUSINESS_PARTNER_TABLE] ON [CARD_GROUPS].[GROUPCODE] = [BUSINESS_PARTNER_TABLE].[GROUPCODE]
GROUP BY [GROUPNAME]
;

-- 2: Make a contact roster that includes the name, address, cell phone number, and email address of all persons currently in either a CEO or COO position.
SELECT [NAME], [ADDRESS], [MOBILE_PHONE_NUMBER], [E_MAIL_ADDRESS]
FROM [CONTACT_PERSONS_TABLE]
WHERE [POSITION] = 'CEO' OR [POSITION] = 'COO'
;

-- 3: What is the commission rate of the sales employee named Bill Levine?
SELECT [COMMISSION]
FROM [SALES_EMPLOYEE_TABLE]
WHERE [SALES_EMPLOYEE_NAME] = 'Bill Levine'
;

-- 4: What are the names of sales employees in the high commission group?
SELECT [SALES_EMPLOYEE_NAME]
FROM [SALES_EMPLOYEE_TABLE]
JOIN [COMMISSION_GROUPS] ON [SALES_EMPLOYEE_TABLE].[GROUPCODE] = [COMMISSION_GROUPS].[GROUPCODE]
WHERE [GROUPNAME] = 'High Commission'
;

-- 5: What are the names, mobile phone numbers, and email addresses of sales employees in the high commission group?
SELECT [SALES_EMPLOYEE_NAME], [MOBIL], [EMAIL]
FROM [SALES_EMPLOYEE_TABLE]
JOIN [COMMISSION_GROUPS] ON [SALES_EMPLOYEE_TABLE].[GROUPCODE] = [COMMISSION_GROUPS].[GROUPCODE]
WHERE [GROUPNAME] = 'High Commission'
;

-- 6: Display the payment code and tax code for current business partners whos closing date procedure number is lower than 35
SELECT [PAYMENT_CODE], [TAXCODE]
FROM [BUSINESS_PARTNER_TABLE]
JOIN [BUSINESS_PARTNERS_ADDRESSES] ON [BUSINESS_PARTNER_TABLE].[CARDCODE] = [BUSINESS_PARTNERS_ADDRESSES].[CARDCODE]
WHERE [CLOSING_DATE_PROCEDURE_NUMBER] < 35
;

-- 7: List the activity number, contact time and date, and the details of all activities created in the year 2021
SELECT [ACTIVITY_NUMBER], [SYSTEM_DATE], [CONTACT_TIME], [DETAILS]
FROM [ACTIVITIES_TABLE]
WHERE YEAR ([CREATEDATE]) = '2021'
;

-- 8: Show the bank details, to include bank code, country, account number, branch, and city, for the business partner with the card name Microchips
SELECT [BUSINESS_PARTNER_BANK_ACCOUNT].[BANKCODE], [BUSINESS_PARTNER_BANK_ACCOUNT].[COUNTRY], [ACCOUNT], [BRANCH], [BUSINESS_PARTNER_BANK_ACCOUNT].[CITY]
FROM [BUSINESS_PARTNER_TABLE]
JOIN [BUSINESS_PARTNER_BANK_ACCOUNT] ON [BUSINESS_PARTNER_TABLE].[CARDCODE] = [BUSINESS_PARTNER_TABLE].[CARDCODE]
WHERE [CARDNAME] = 'Microchips'
;

-- 9: what is the account balance of the business partner with the payment method code 'Incoming BT' and a currency type that is either 'EUR' or 'CAN'
SELECT [BALANCE]
FROM [BUSINESS_PARTNER_TABLE]
WHERE [CURRENCY] IN ('EUR', 'CAN') AND [BUSINESS_PARTNER_TABLE].[PAYMENT_CODE] = 'Incoming BT'
;

-- 10: What is the email address and federal tax ID of the target with the position of CIO that is of target type C?
SELECT [EMAIL_ADDRESS], [LICENCED_TRADER_NUMBER]
FROM [TARGET_GROUP_DETAILS]
JOIN [TARGET_GROUP_TABLE] ON [TARGET_GROUP_DETAILS].[TARGETCODE] = [TARGET_GROUP_TABLE].[TARGETCODE]
WHERE [POSITION] = 'CIO' AND [TARGETTYPE] = 'C'
;

