-- 1: Show the account name and number of journal entries for the general ledger account with code '_SYS00000000002'.
SELECT [BANK_ACCOUNT_NAME], COUNT (*) ENTRYCOUNT
FROM [GENERAL_LEDGER_ACCOUNTS_TABLE] O
JOIN [JOURNAL_ENTRY_ROWS] J ON [O].[ACCOUNT_CODE] = [J].[ACCOUNT]
WHERE [ACCOUNT] = '_SYS00000000002'
GROUP BY [BANK_ACCOUNT_NAME]
;

-- 2: What is the sum of journal entry debits and sum of journal entry credits due in 2021?
SELECT SUM ([DEBIT]) DEBITSUM, SUM ([CREDIT]) CREDITSUM
FROM [JOURNAL_ENTRY_ROWS]
WHERE YEAR ([DUEDATE]) = '2021'
;

-- 3: Show the account name, the average monthly budget debit, and average monthly budget credit totals for general ledger accounts with the words 'Travel Expense' in their account name.
SELECT [BANK_ACCOUNT_NAME], AVG ([MONTHLY_BUDGET_DEBIT]) AS AVGDEB, AVG ([MONTHLY_BUDGET_CREDIT]) AS AVGCRED
FROM [GENERAL_LEDGER_ACCOUNTS_TABLE]
JOIN [BUDGET_ROWS] ON [GENERAL_LEDGER_ACCOUNTS_TABLE].[ACCOUNT_CODE] = [BUDGET_ROWS].[ACCOUNT_CODE]
WHERE [BANK_ACCOUNT_NAME] LIKE '%Travel Expense%'
GROUP BY [BANK_ACCOUNT_NAME]
;

-- 4: Show the account name and current total balance of accounts with the category name cash
SELECT [BANK_ACCOUNT_NAME], [CURRENT_BALANCE]
FROM [GENERAL_LEDGER_ACCOUNTS_TABLE]
JOIN [ACCOUNT_CATEGORY_TABLE] ON [GENERAL_LEDGER_ACCOUNTS_TABLE].[CATEGORY] = [ACCOUNT_CATEGORY_TABLE].[ABSTRACT_ID]
WHERE [ACCOUNT_CATEGORY_TABLE].[NAME] = 'cash'
;

-- 5: For all rows associated with the value added tax transactions that have source object type 18, show the Tax Code, value added tax percent, and the value added tax sum.
SELECT [TAXCODE], [VALUE_ADDED_TAX_PERCENTAGE], [VALUE_ADDED_TAX_SUMMARY]
FROM [VAT_TRANSACTIONS]
JOIN [TAX1] ON [VAT_TRANSACTIONS].[ID_INTERNAL_NUMBER] = [TAX1].[ID_INTERNAL_NUMBER]
WHERE [SOURCE_OBJECT_INTERNAL_ID] = 18
;

-- 6: What year had the highest rate for currency type 'CAN' from data source I?
SELECT TOP 1 YEAR ([RATEDATE]) HIGHYEAR
FROM [CPI_FUNCTIONAL_CURRENCY_RATES]
WHERE [DATASOURCE] = 'I'
ORDER BY [RATE] DESC
;

-- 7: Get a count of recurring postings by year of the next execution
SELECT YEAR ([NEXT_EXECUTION_DATE]) NEXTYEAR, COUNT (*) NUMPOSTINGS
FROM [RECURRING_POSTINGS]
GROUP BY YEAR ([NEXT_EXECUTION_DATE])
;

-- 8: Show the names of the financial report categories that have father number 10
SELECT [NAME]
FROM [FINANCIAL_REPORT_CATEGORIES]
WHERE [PARENT_ACCOUNT_KEY] = 10
;

-- 9: show the report category name and the three different calculation methods for extended category f financial reports with a cash flow line item ids greater than 30
SELECT [NAME], [CALCULATION_METHOD], [CALMETHOD2], [CALMETHOD3]
FROM [EXTEND_CATEGORY_FOR_FINANCIAL_REPORTING]
JOIN [FINANCIAL_REPORT_CATEGORIES] ON [EXTEND_CATEGORY_FOR_FINANCIAL_REPORTING].[CATEGORY_ID] = [FINANCIAL_REPORT_CATEGORIES].[CATEGORY_ID]
WHERE [CASH_FLOW_LINE_ITEM_ID] > 30
;

-- 10: What is the project code and name of the projects valid after 2020?
SELECT [PROJECT_CODE], [PROJECT_NAME]
FROM [PROJECT_CODES]
WHERE YEAR ([VALIDFROM]) > 2020
;

