-- 1: Show the description and expected costs of project management stages with start dates before october 20th, 2021.
SELECT [DSCRIPTION], [EXPCOSTS]
FROM [PROJ_MNGMNT_STGS]
WHERE [STRT] < '2021-10-20'
;

-- 2: What values are associated with the dictionary key 'HomePage'?
SELECT [_VAL]
FROM [DICT_TBL]
WHERE [_KY] LIKE 'HomePage'
;

-- 3: How many queries does the dashboard entry with code DAB002 have?
SELECT COUNT (*) QUERYCOUNT
FROM [DASH_TBL]
JOIN [DASH_QUERIES] ON [DASH_TBL].[ABSENTRY] = [DASH_QUERIES].[DSBENTRY]
WHERE [DASHBDCODE] = 'DAB002'
;

-- 4: Show the Dashboard name, dashboard path, status, and query name for dashboards and their queries where the query category is 2
SELECT [DASHBDNAME], [DASHBDPATH], [STTUS], [QRYNAME]
FROM [DASH_TBL]
JOIN [DASH_QUERIES] ON [DASH_TBL].[ABSENTRY] = [DASH_QUERIES].[DSBENTRY]
WHERE [QRYCTGRY] = 2
;

-- 5: Show the code, name, and number of fields for key performance indicator sets of type P
SELECT [KPSCODE], [KPSNAME], [FIELDSNUM]
FROM [KEY_PERF_IND_SET]
WHERE [KPSTYPE] = 'P'
;

-- 6: What is the resource name, type, group code, and resource cost 1 of the employee resource with employee ID 9?
SELECT [RESNAME], [RESTYPE], [RESGRPCOD], [STDCOST1]
FROM [RESRCS_TBL]
JOIN [RES_EMPLOYEES] ON [RESRCS_TBL].[RESCODE] = [RES_EMPLOYEES].[RESCODE]
WHERE [EMPID] = 9
;

-- 7: what is the average daily capacity factor 1 of the resource named 'Testing Machine' on weekdays 1 through 5?
SELECT AVG ([CAPFACTOR1]) AVGCAPACITY
FROM [RESRCS_TBL]
JOIN [RESRCS_DLY_CAP] ON [RESRCS_TBL].[RESCODE] = [RESRCS_DLY_CAP].[RESCODE]
WHERE [RESNAME] = 'Testing Machine' AND [WKDAY] > = 1 AND [WKDAY] < = 5
;

-- 8: Show the project name and open issue remarks, and open issue solution for projects that have open issues.
SELECT [NM], [RMKS], [SOLN]
FROM [PROJ_MNGT_DOC]
JOIN [PM_STAGES_OPEN_ISSUES] ON [PROJ_MNGT_DOC].[ABSENTRY] = [PM_STAGES_OPEN_ISSUES].[ABSENTRY]
;

-- 9: Show the cockpit subtable left, right, top, and bottom values for the cockpit named purchase
SELECT [CKPT_SUBTBL].[_LFT], [CKPT_SUBTBL].[_RT], [CKPT_SUBTBL].[_TP], [CKPT_SUBTBL].[_BTM]
FROM [CKPT_MAIN_TBL]
JOIN [CKPT_SUBTBL] ON [CKPT_MAIN_TBL].[ABSENTRY] = [CKPT_SUBTBL].[ABSENTRY]
WHERE [NM] = 'Purchase'
;

-- 10: What are the table names of business object briefs with the description fields that have the word Memo in them?
SELECT [TBLNM]
FROM [BUS_OBJ_BRF]
WHERE [DESCFIELD] LIKE '%Memo%'
;

