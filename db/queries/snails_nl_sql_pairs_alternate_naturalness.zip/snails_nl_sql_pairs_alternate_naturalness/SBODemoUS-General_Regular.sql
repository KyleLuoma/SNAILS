-- 1: Show the description and expected costs of project management stages with start dates before october 20th, 2021.
SELECT [ELEMENT_DESCRIPTION], [PLANNED_COST]
FROM [PROJECT_MANAGEMENT_STAGES]
WHERE [START] < '2021-10-20'
;

-- 2: What values are associated with the dictionary key 'HomePage'?
SELECT [_VALUE]
FROM [DICTIONARY_TABLE]
WHERE [_KEY] LIKE 'HomePage'
;

-- 3: How many queries does the dashboard entry with code DAB002 have?
SELECT COUNT (*) QUERYCOUNT
FROM [DASHBOARD_TABLE]
JOIN [DASHBOARD_QUERIES] ON [DASHBOARD_TABLE].[ID_INTERNAL_NUMBER] = [DASHBOARD_QUERIES].[DASHBOARD_ENTRY]
WHERE [DASHBOARD_CODE] = 'DAB002'
;

-- 4: Show the Dashboard name, dashboard path, status, and query name for dashboards and their queries where the query category is 2
SELECT [DASHBOARD_NAME], [DASHBOARD_PATH], [STATUS], [QUERYNAME]
FROM [DASHBOARD_TABLE]
JOIN [DASHBOARD_QUERIES] ON [DASHBOARD_TABLE].[ID_INTERNAL_NUMBER] = [DASHBOARD_QUERIES].[DASHBOARD_ENTRY]
WHERE [QUERYCATEGORY] = 2
;

-- 5: Show the code, name, and number of fields for key performance indicator sets of type P
SELECT [KEY_PERFORMANCE_INDICATOR_SET_CODE], [KEY_PERFORMANCE_INDICATOR_SET_NAME], [KEY_PERFORMANCE_INDICATOR_SET_FIELDS_NUMBER]
FROM [KEY_PERFORMANCE_INDICATOR_SET]
WHERE [KEY_PERFORMANCE_INDICATOR_SET_TYPE] = 'P'
;

-- 6: What is the resource name, type, group code, and resource cost 1 of the employee resource with employee ID 9?
SELECT [RESOURCE_DESCRIPTION], [RESOURCE_TYPE], [RESOURCE_GROUP_CODE], [RESOURCE_COST_1]
FROM [RESOURCES_TABLE]
JOIN [RESOURCES_EMPLOYEES] ON [RESOURCES_TABLE].[RESOURCE_CODE] = [RESOURCES_EMPLOYEES].[RESOURCE_CODE]
WHERE [EMPLOYEE_ID] = 9
;

-- 7: what is the average daily capacity factor 1 of the resource named 'Testing Machine' on weekdays 1 through 5?
SELECT AVG ([DAY1_CAPACITY_FACTOR1]) AVGCAPACITY
FROM [RESOURCES_TABLE]
JOIN [RESOURCES_DAILY_CAPACITIES] ON [RESOURCES_TABLE].[RESOURCE_CODE] = [RESOURCES_DAILY_CAPACITIES].[RESOURCE_CODE]
WHERE [RESOURCE_DESCRIPTION] = 'Testing Machine' AND [WEEKDAY] > = 1 AND [WEEKDAY] < = 5
;

-- 8: Show the project name and open issue remarks, and open issue solution for projects that have open issues.
SELECT [NAME], [REMARKS], [SOLUTION]
FROM [PROJECT_MANAGEMENT_DOCUMENT]
JOIN [PROJECT_MANAGEMENT_STAGES_OPEN_ISSUES] ON [PROJECT_MANAGEMENT_DOCUMENT].[ID_INTERNAL_NUMBER] = [PROJECT_MANAGEMENT_STAGES_OPEN_ISSUES].[ID_INTERNAL_NUMBER]
;

-- 9: Show the cockpit subtable left, right, top, and bottom values for the cockpit named purchase
SELECT [COCKPIT_SUBTABLE].[_LEFT], [COCKPIT_SUBTABLE].[_RIGHT], [COCKPIT_SUBTABLE].[_TOP], [COCKPIT_SUBTABLE].[_BOTTOM]
FROM [COCKPIT_MAIN_TABLE]
JOIN [COCKPIT_SUBTABLE] ON [COCKPIT_MAIN_TABLE].[ID_INTERNAL_NUMBER] = [COCKPIT_SUBTABLE].[ID_INTERNAL_NUMBER]
WHERE [NAME] = 'Purchase'
;

-- 10: What are the table names of business object briefs with the description fields that have the word Memo in them?
SELECT [TABLENAME]
FROM [BUSINESS_OBJECT_BRIEF]
WHERE [DESCRIPTION_FIELD] LIKE '%Memo%'
;

