-- 1: What are the first and last names of employees on the Sales team?
SELECT [LNAME], [FNAME]
FROM [OHEM] EMPLOYEES
JOIN [HTM1] TEAMMEMBERS ON [EMPLOYEES].[EID] = [TEAMMEMBERS].[EID]
JOIN [OHTM] EMPLTEAMS ON [TEAMMEMBERS].[TMID] = [EMPLTEAMS].[TMID]
WHERE [EMPLTEAMS].[NM] = 'Sales'
;

-- 2: Get a list of all of the holiday start and end dates and remarks for holidays in 2014.
SELECT [ST_DT], [D_DT], [RMRKS]
FROM [HLD1]
WHERE [ST_DT] > = '20140101 00:00:00.000' AND [D_DT] < = '20141231 23:59:59.000'
;

-- 3: What is the average salary of employees on the purchasing team?
SELECT AVG ([SAL]) AS AVGSALARY
FROM [OHEM]
JOIN [HTM1] ON [OHEM].[EID] = [HTM1].[EID]
JOIN [OHTM] ON [OHTM].[TMID] = [HTM1].[TMID]
WHERE [OHTM].[NM] = 'Purchasing'
;

-- 4: What is the office phone number, mobile phone number, pager number, and home phone number of the employee named George Keeng?
SELECT [OFCTEL], [MB], [PGR], [H_TL]
FROM [OHEM]
WHERE [LNAME] = 'Keeng' AND [FNAME] = 'George'
;

-- 5: What is the first and last name of the spouse of employee Maria Bridi?
SELECT [FNSP], [SRNSP]
FROM [OHEM]
WHERE [LNAME] = 'Bridi' AND [FNAME] = 'Maria'
;

-- 6: Show the last name, education status, and number of children for employees of type Technician
SELECT [LNAME], [SOE], [NCHLD]
FROM [OHEM]
JOIN [OHTY] ON [OHTY].[TP_ID] = [OHEM].[TY]
WHERE [OHTY].[NM] = 'Technician'
;

-- 7: Show the type ID and name of each employee type
SELECT [TP_ID], [NM]
FROM [OHTY]
;

-- 8: Make an employee health insurance list that includes their employee ID, last name,  insurance company name, insurance code, and type of insurance.
SELECT [EID], [LNAME], [HIN], [HIC], [HIT]
FROM [OHEM]
;

-- 9: What is the job title code of the employee with the last name  Chan?
SELECT [JTC]
FROM [OHEM]
WHERE [LNAME] = 'Chan'
;

-- 10: What are the average vacation days in the current year for employees on the sales team?
SELECT AVG ([VCY])
FROM [OHEM] EMPLOYEES
JOIN [HTM1] TEAMMEMBERS ON [EMPLOYEES].[EID] = [TEAMMEMBERS].[EID]
JOIN [OHTM] EMPLTEAMS ON [TEAMMEMBERS].[TMID] = [EMPLTEAMS].[TMID]
WHERE [EMPLTEAMS].[NM] = 'Sales'
;

-- 11: Show the team ID of the team that has the employee with the personal fiscal ID 51B.
SELECT [TMID]
FROM [HTM1]
JOIN [OHEM] ON [HTM1].[EID] = [OHEM].[EID]
WHERE [CPF] = '51B'
;

-- 12: Show the municipality key, tax class, and income tax liability for all of the employees of type accountant.
SELECT [MK], [TX_CL], [ITL]
FROM [OHEM]
JOIN [OHTY] ON [OHEM].[TY] = [OHTY].[TP_ID]
WHERE [OHTY].[NM] = 'Accountant'
;

-- 13: What are the role IDs of employees whos' salaries are less than 5000?
SELECT [R_ID]
FROM [HEM6]
JOIN [OHEM] ON [HEM6].[EID] = [OHEM].[EID]
WHERE [SAL] < 5000
;

-- 14: Show the date of birth, country of birth, home city, home county, and home country for the employees with the job title of accountant
SELECT [B_DT], [BTH_CT], [HCITY], [HCNTY], [H_CTR]
FROM [OHEM]
WHERE [JT] = 'Accountant'
;

-- 15: Show the professional status, citizenship and passport number  of the employee whos last name is Buyer
SELECT [SOP], [CTZSHP], [P_NO]
FROM [OHEM]
WHERE [LNAME] = 'Buyer'
;

-- 16: Show the first name, last name, home city, and work city of employees whos costs are higher than 4000.
SELECT [FNAME], [LNAME], [HCITY], [W_CTY]
FROM [OHEM]
WHERE [EM_C] > 4000
;

-- 17: Show the municipality key, home city, home phone number, work city and office phone number of employees on the sales team.
SELECT [MK], [HCITY], [H_TL], [W_CTY], [OFCTEL]
FROM [OHEM] EMPLOYEES
JOIN [HTM1] TEAMMEMBERS ON [EMPLOYEES].[EID] = [TEAMMEMBERS].[EID]
JOIN [OHTM] EMPLTEAMS ON [TEAMMEMBERS].[TMID] = [EMPLTEAMS].[TMID]
WHERE [EMPLTEAMS].[NM] = 'Sales'
;

-- 18: Show the professional status and educational statuses as well as the home and work street numbers of employees on the purchasing team.
SELECT [SOP], [SOE], [SNW], [STNOH]
FROM [OHEM] EMPLOYEES
JOIN [HTM1] TEAMMEMBERS ON [EMPLOYEES].[EID] = [TEAMMEMBERS].[EID]
JOIN [OHTM] EMPLTEAMS ON [TEAMMEMBERS].[TMID] = [EMPLTEAMS].[TMID]
WHERE [EMPLTEAMS].[NM] = 'Purchasing'
;

-- 19: What is the payment method, exemption amount currency, and additional amount currency, for the employee who's tax office name is baltimore?
SELECT [P_MTH], [EXMPTCURR], [ADCR]
FROM [OHEM]
WHERE [TONM] = 'baltimore'
;

-- 20: What is the marital status, home street, home block, home zip code, and home state of the employee with the last name Bridi?
SELECT [MRTSTS], [HSTR], [HBLK], [HZP], [H_ST]
FROM [OHEM]
WHERE [LNAME] = 'Bridi'
;

