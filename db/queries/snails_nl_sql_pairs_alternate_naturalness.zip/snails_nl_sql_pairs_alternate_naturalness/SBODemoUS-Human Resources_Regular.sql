-- 1: What are the first and last names of employees on the Sales team?
SELECT [LASTNAME], [FIRSTNAME]
FROM [EMPLOYEES_TABLE] EMPLOYEES
JOIN [TEAM_MEMBERS_TABLE] TEAMMEMBERS ON [EMPLOYEES].[EMPLOYEE_ID] = [TEAMMEMBERS].[EMPLOYEE_ID]
JOIN [EMPLOYEE_TEAMS] EMPLTEAMS ON [TEAMMEMBERS].[TEAMID] = [EMPLTEAMS].[TEAMID]
WHERE [EMPLTEAMS].[NAME] = 'Sales'
;

-- 2: Get a list of all of the holiday start and end dates and remarks for holidays in 2014.
SELECT [START_DATE], [ENDDATE], [ENTRY_REMARKS]
FROM [HOLIDAY_DATES]
WHERE [START_DATE] > = '20140101 00:00:00.000' AND [ENDDATE] < = '20141231 23:59:59.000'
;

-- 3: What is the average salary of employees on the purchasing team?
SELECT AVG ([SALARY]) AS AVGSALARY
FROM [EMPLOYEES_TABLE]
JOIN [TEAM_MEMBERS_TABLE] ON [EMPLOYEES_TABLE].[EMPLOYEE_ID] = [TEAM_MEMBERS_TABLE].[EMPLOYEE_ID]
JOIN [EMPLOYEE_TEAMS] ON [EMPLOYEE_TEAMS].[TEAMID] = [TEAM_MEMBERS_TABLE].[TEAMID]
WHERE [EMPLOYEE_TEAMS].[NAME] = 'Purchasing'
;

-- 4: What is the office phone number, mobile phone number, pager number, and home phone number of the employee named George Keeng?
SELECT [OFFICE_PHONE], [MOBILE], [PAGER], [HOME_PHONE]
FROM [EMPLOYEES_TABLE]
WHERE [LASTNAME] = 'Keeng' AND [FIRSTNAME] = 'George'
;

-- 5: What is the first and last name of the spouse of employee Maria Bridi?
SELECT [SPOUSE_FIRST_NAME], [SPOUSE_LAST_NAME]
FROM [EMPLOYEES_TABLE]
WHERE [LASTNAME] = 'Bridi' AND [FIRSTNAME] = 'Maria'
;

-- 6: Show the last name, education status, and number of children for employees of type Technician
SELECT [LASTNAME], [EDUCATIONAL_STATUS], [NUMBER_OF_CHILDREN]
FROM [EMPLOYEES_TABLE]
JOIN [EMPLOYEE_TYPES] ON [EMPLOYEE_TYPES].[TYPEID] = [EMPLOYEES_TABLE].[TYPE]
WHERE [EMPLOYEE_TYPES].[NAME] = 'Technician'
;

-- 7: Show the type ID and name of each employee type
SELECT [TYPEID], [NAME]
FROM [EMPLOYEE_TYPES]
;

-- 8: Make an employee health insurance list that includes their employee ID, last name,  insurance company name, insurance code, and type of insurance.
SELECT [EMPLOYEE_ID], [LASTNAME], [HEALTH_INSURANCE_COMPANY_NAME], [HEALTH_INSURANCE_CODE], [HEALTH_INSURANCE_TYPE]
FROM [EMPLOYEES_TABLE]
;

-- 9: What is the job title code of the employee with the last name  Chan?
SELECT [JOB_TITLE_CODE]
FROM [EMPLOYEES_TABLE]
WHERE [LASTNAME] = 'Chan'
;

-- 10: What are the average vacation days in the current year for employees on the sales team?
SELECT AVG ([VACATION_CURRENT_YEAR])
FROM [EMPLOYEES_TABLE] EMPLOYEES
JOIN [TEAM_MEMBERS_TABLE] TEAMMEMBERS ON [EMPLOYEES].[EMPLOYEE_ID] = [TEAMMEMBERS].[EMPLOYEE_ID]
JOIN [EMPLOYEE_TEAMS] EMPLTEAMS ON [TEAMMEMBERS].[TEAMID] = [EMPLTEAMS].[TEAMID]
WHERE [EMPLTEAMS].[NAME] = 'Sales'
;

-- 11: Show the team ID of the team that has the employee with the personal fiscal ID 51B.
SELECT [TEAMID]
FROM [TEAM_MEMBERS_TABLE]
JOIN [EMPLOYEES_TABLE] ON [TEAM_MEMBERS_TABLE].[EMPLOYEE_ID] = [EMPLOYEES_TABLE].[EMPLOYEE_ID]
WHERE [PERSONAL_FISCAL_ID] = '51B'
;

-- 12: Show the municipality key, tax class, and income tax liability for all of the employees of type accountant.
SELECT [MUNICIPALITY_KEY], [TAXCLASS], [INCOME_TAX_LIABILITY]
FROM [EMPLOYEES_TABLE]
JOIN [EMPLOYEE_TYPES] ON [EMPLOYEES_TABLE].[TYPE] = [EMPLOYEE_TYPES].[TYPEID]
WHERE [EMPLOYEE_TYPES].[NAME] = 'Accountant'
;

-- 13: What are the role IDs of employees whos' salaries are less than 5000?
SELECT [ROLEID]
FROM [EMPLOYEE_ROLES_TABLE]
JOIN [EMPLOYEES_TABLE] ON [EMPLOYEE_ROLES_TABLE].[EMPLOYEE_ID] = [EMPLOYEES_TABLE].[EMPLOYEE_ID]
WHERE [SALARY] < 5000
;

-- 14: Show the date of birth, country of birth, home city, home county, and home country for the employees with the job title of accountant
SELECT [BIRTHDATE], [COUNTRY_OF_BIRTH], [HOMECITY], [HOMECOUNTY], [HOME_COUNTRY]
FROM [EMPLOYEES_TABLE]
WHERE [JOBTITLE] = 'Accountant'
;

-- 15: Show the professional status, citizenship and passport number  of the employee whos last name is Buyer
SELECT [PROFESSIONAL_STATUS], [CITIZENSHIP], [PASSPORTNO]
FROM [EMPLOYEES_TABLE]
WHERE [LASTNAME] = 'Buyer'
;

-- 16: Show the first name, last name, home city, and work city of employees whos costs are higher than 4000.
SELECT [FIRSTNAME], [LASTNAME], [HOMECITY], [WORKCITY]
FROM [EMPLOYEES_TABLE]
WHERE [EMPLOYEE_COSTS] > 4000
;

-- 17: Show the municipality key, home city, home phone number, work city and office phone number of employees on the sales team.
SELECT [MUNICIPALITY_KEY], [HOMECITY], [HOME_PHONE], [WORKCITY], [OFFICE_PHONE]
FROM [EMPLOYEES_TABLE] EMPLOYEES
JOIN [TEAM_MEMBERS_TABLE] TEAMMEMBERS ON [EMPLOYEES].[EMPLOYEE_ID] = [TEAMMEMBERS].[EMPLOYEE_ID]
JOIN [EMPLOYEE_TEAMS] EMPLTEAMS ON [TEAMMEMBERS].[TEAMID] = [EMPLTEAMS].[TEAMID]
WHERE [EMPLTEAMS].[NAME] = 'Sales'
;

-- 18: Show the professional status and educational statuses as well as the home and work street numbers of employees on the purchasing team.
SELECT [PROFESSIONAL_STATUS], [EDUCATIONAL_STATUS], [WORK_STREET_NUMBER], [HOME_STREET_NUMBER]
FROM [EMPLOYEES_TABLE] EMPLOYEES
JOIN [TEAM_MEMBERS_TABLE] TEAMMEMBERS ON [EMPLOYEES].[EMPLOYEE_ID] = [TEAMMEMBERS].[EMPLOYEE_ID]
JOIN [EMPLOYEE_TEAMS] EMPLTEAMS ON [TEAMMEMBERS].[TEAMID] = [EMPLTEAMS].[TEAMID]
WHERE [EMPLTEAMS].[NAME] = 'Purchasing'
;

-- 19: What is the payment method, exemption amount currency, and additional amount currency, for the employee who's tax office name is baltimore?
SELECT [PAYMENTMETHOD], [EXEMPTION_AMOUNT_CURRENCY], [ADDITIONAL_AMOUNT_CURRENCY]
FROM [EMPLOYEES_TABLE]
WHERE [TAX_OFFICE_NAME] = 'baltimore'
;

-- 20: What is the marital status, home street, home block, home zip code, and home state of the employee with the last name Bridi?
SELECT [MARITAL_STATUS], [HOMESTREET], [HOMEBLOCK], [HOMEZIP], [HOMESTATE]
FROM [EMPLOYEES_TABLE]
WHERE [LASTNAME] = 'Bridi'
;

