-- 1: How many items with the name 'USB Flashdrive 128GB' are on hand, committed, and on order?
SELECT [OH], [ISCMT], [OO]
FROM [OITM]
WHERE [INM] = 'USB Flashdrive 128GB'
;

-- 2: What is the number of commited items, the price-per-item, and the total price of the commited items for the item called 'Memory Chip?
SELECT [ISCMT], [PRC], [ISCMT] * [PRC] AS TOTALPRICE
FROM [OITM]
JOIN [ITM1] ON [OITM].[ITM_C] = [ITM1].[ITM_C]
WHERE [INM] = 'Memory Chip'
;

-- 3: For the vendor with vendor code V1010, show item names, consignment numbers, and last purchase price for items where the vendor is preferred.
SELECT [INM], [CSG], [LPP]
FROM [ITM2]
JOIN [OITM] ON [ITM2].[ITM_C] = [OITM].[ITM_C]
WHERE [V_CD] = 'V1010'
;

-- 4: For the item named 'Printer Paper A4 White', show the package dimensions including height 1, width 1, length 1, and volume, for the packaging that holds a quantity of 24.
SELECT [H1], [WD1], [L1], [VOL]
FROM [ITM4]
JOIN [OITM] ON [ITM4].[ITM_C] = [OITM].[ITM_C]
WHERE [INM] = 'Printer Paper A4 White' AND [QPP] = 24
;

-- 5: What is the useful life, remaining life, and remaining day parameters for the item that uses depreciation area 'GAAP'?
SELECT [U_LF], [RL], [R_DYS]
FROM [ITM7]
WHERE [DPR_AR] = 'GAAP'
;

-- 6: What is the volume of the box package type?
SELECT [VOL]
FROM [OPKG]
WHERE [PKGTP] = 'Box'
;

-- 7: What are the barcodes for the item named 'Printer Paper A4 White' with unit of measurement entries that are either 3 or 4?
SELECT [BCDCD]
FROM [OITM]
JOIN [OBCD] ON [OITM].[ITM_C] = [OBCD].[ITM_C]
WHERE [INM] = 'Printer Paper A4 White' AND [UOM_E] IN (3, 4)
;

-- 8: Show the display names, data source, and updated date of bin field configurations that are activated (activated code = 'Y')
SELECT [DSPNM], [D_SRC], [U_DT]
FROM [OBFC]
WHERE [ACTVTD] = 'Y'
;

-- 9: Display a count of items for each item group. Include the item group name and count of items in the result.
SELECT [ITMS_GN], COUNT (*) ITMCT
FROM [OITM]
JOIN [OITB] ON [OITM].[IGC] = [OITB].[IGC]
GROUP BY [ITMS_GN]
;

-- 10: What is the average volume of items in the 'Items' Item group?
SELECT AVG ([VOL]) AVGVOLUME
FROM [OITM]
JOIN [OITB] ON [OITM].[IGC] = [OITB].[IGC]
JOIN [ITM4] ON [OITM].[ITM_C] = [ITM4].[ITM_C]
WHERE [ITMS_GN] = 'Items'
;

