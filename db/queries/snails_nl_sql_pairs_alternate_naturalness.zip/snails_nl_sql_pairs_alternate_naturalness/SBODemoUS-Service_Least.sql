-- 1: How many service contract items are there for each service contract? Include the contract ID in the result.
SELECT [OCTR].[CT_ID], COUNT (*) ITEMCOUNT
FROM [OCTR]
JOIN [CTR1] ON [OCTR].[CT_ID] = [CTR1].[CT_ID]
GROUP BY [OCTR].[CT_ID]
;

-- 2: What is the renewal status of the contracts with the customer named 'Maxi-Teq'? Include the contract ID and the status in the result.
SELECT [CT_ID], [RNW]
FROM [OCTR]
WHERE [CSTMRNM] = 'Maxi-Teq'
;

-- 3: For each state in the country US, show a count of entries in the customer equipment card table
SELECT [ST], COUNT (*) ENTRYCOUNT
FROM [OINS]
WHERE [CTRY] = 'US'
GROUP BY [ST]
;

-- 4: What is the customer equipment item name of the item with code S10000? Include only one result in the output.
SELECT DISTINCT [INM]
FROM [OINS]
WHERE [ITM_C] = 'S10000'
;

-- 5: For each queue, show the description, manager, and email address
SELECT [DSCPT], [MGR], [EML]
FROM [OQUE]
;

-- 6: How many service calls are there per customer where the priority is medium? (value M) Include the custmer ID and customer name
SELECT [CUST], [CUSTNM], COUNT (*) CALLCOUNT
FROM [OSCL]
WHERE [PTY] = 'M'
GROUP BY [CUST], [CUSTNM]
;

-- 7: Show the assigned date, response date, and resolved date of service calls that originated on the web
SELECT [ASDT], [RSP_OD], [RESL_OD]
FROM [OSCL]
JOIN [OSCO] ON [OSCL].[ORG] = [OSCO].[O_ID]
WHERE [OSCO].[NM] = 'Web'
;

-- 8: what is the business partner shipping and billing address and email for the customer named 'Aquent Systems'. Display only one row per unique result.
SELECT DISTINCT [BPSA], [BPBA], [BPE_ML]
FROM [OSCL]
WHERE [CUSTNM] = 'Aquent Systems'
;

-- 9: Show the number of service calls for customer with the 'Silver Warranty' contract template. Include the customer name and count of calls in the result.
SELECT [CSTMRNM], COUNT (*) CALLCOUNT
FROM [OCTR]
JOIN [OSCL] ON [OCTR].[CSTM_CD] = [OSCL].[CUST]
GROUP BY [CSTMRNM]
;

-- 10: What are the internal serial numbers of the service contract with the customer named microhips and the iten code A00006?
SELECT [ISN]
FROM [OINS]
WHERE [CUSTNM] = 'Microchips' AND [ITM_C] = 'A00006'
;

