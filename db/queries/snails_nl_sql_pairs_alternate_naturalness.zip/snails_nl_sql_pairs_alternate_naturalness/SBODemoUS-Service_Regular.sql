-- 1: How many service contract items are there for each service contract? Include the contract ID in the result.
SELECT [SERVICE_CONTRACTS_TABLE].[CONTRACTID], COUNT (*) ITEMCOUNT
FROM [SERVICE_CONTRACTS_TABLE]
JOIN [SERVICE_CONTRACT_ITEMS_CTR] ON [SERVICE_CONTRACTS_TABLE].[CONTRACTID] = [SERVICE_CONTRACT_ITEMS_CTR].[CONTRACTID]
GROUP BY [SERVICE_CONTRACTS_TABLE].[CONTRACTID]
;

-- 2: What is the renewal status of the contracts with the customer named 'Maxi-Teq'? Include the contract ID and the status in the result.
SELECT [CONTRACTID], [RENEWAL]
FROM [SERVICE_CONTRACTS_TABLE]
WHERE [CUSTOMER_NAME] = 'Maxi-Teq'
;

-- 3: For each state in the country US, show a count of entries in the customer equipment card table
SELECT [STATE], COUNT (*) ENTRYCOUNT
FROM [CUSTOMER_EQUIPMENT_CARD]
WHERE [COUNTRY] = 'US'
GROUP BY [STATE]
;

-- 4: What is the customer equipment item name of the item with code S10000? Include only one result in the output.
SELECT DISTINCT [ITEMNAME]
FROM [CUSTOMER_EQUIPMENT_CARD]
WHERE [ITEMCODE] = 'S10000'
;

-- 5: For each queue, show the description, manager, and email address
SELECT [DESCRIPT], [MANAGER], [EMAIL]
FROM [QUEUE_TABLE]
;

-- 6: How many service calls are there per customer where the priority is medium? (value M) Include the custmer ID and customer name
SELECT [CUSTOMER], [BUSINESS_PARTNER_NAME], COUNT (*) CALLCOUNT
FROM [SERVICE_CALLS_TABLE_SCL]
WHERE [PRIORITY] = 'M'
GROUP BY [CUSTOMER], [BUSINESS_PARTNER_NAME]
;

-- 7: Show the assigned date, response date, and resolved date of service calls that originated on the web
SELECT [ASSIGNDATE], [RESPONSE_ON_DATE], [RESOLUTION_ON_DATE]
FROM [SERVICE_CALLS_TABLE_SCL]
JOIN [SERVICE_CALL_ORIGINS] ON [SERVICE_CALLS_TABLE_SCL].[ORIGIN] = [SERVICE_CALL_ORIGINS].[ORIGINID]
WHERE [SERVICE_CALL_ORIGINS].[NAME] = 'Web'
;

-- 8: what is the business partner shipping and billing address and email for the customer named 'Aquent Systems'. Display only one row per unique result.
SELECT DISTINCT [BUSINESS_PARTNER_SHIP_TO_ADDRESS], [BUSINESS_PARTNER_BILL_TO_ADDRESS], [BUSINESS_PARTNER_EMAIL]
FROM [SERVICE_CALLS_TABLE_SCL]
WHERE [BUSINESS_PARTNER_NAME] = 'Aquent Systems'
;

-- 9: Show the number of service calls for customer with the 'Silver Warranty' contract template. Include the customer name and count of calls in the result.
SELECT [CUSTOMER_NAME], COUNT (*) CALLCOUNT
FROM [SERVICE_CONTRACTS_TABLE]
JOIN [SERVICE_CALLS_TABLE_SCL] ON [SERVICE_CONTRACTS_TABLE].[CUSTOMERCODE] = [SERVICE_CALLS_TABLE_SCL].[CUSTOMER]
GROUP BY [CUSTOMER_NAME]
;

-- 10: What are the internal serial numbers of the service contract with the customer named microhips and the iten code A00006?
SELECT [INTERNAL_SERIAL_NUMBER]
FROM [CUSTOMER_EQUIPMENT_CARD]
WHERE [BUSINESS_PARTNER_NAME] = 'Microchips' AND [ITEMCODE] = 'A00006'
;

