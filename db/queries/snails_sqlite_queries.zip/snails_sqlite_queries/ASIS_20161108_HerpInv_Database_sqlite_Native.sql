-- 1: How many five year old turtles were measured?
select count(*) turtleCount  from tblFieldDataTurtleMeasurements where age = '5' 
;

-- 2: How many turtles were measured at each location where turtles were measured?
select locationID, count(*) turtleCount from tblFieldDataTurtleMeasurements group by locationID 
;

-- 3: what is the average weight of all turtles?
select avg(weight) turtleWeight from tblFieldDataTurtleMeasurements 
;

-- 4: at which locations were both snakes and turtles measured?
select distinct t.locationID from tblFieldDataTurtleMeasurements t join tblFieldDataSnakeDataCollection s on t.LocationID = s.LocationID 
;

-- 5: How many minnow traps are there at each location?
select locationID, count(distinct [trap_#]) trapCount from tblFieldDataMinnowTrapSurveys group by locationID 
;

-- 6: show the total number of minnows counted at each location
select locationid, sum(count) minnowCountSum from tblFieldDataMinnowTrapSurveys group by LocationID 
;

-- 7: show the total number of minnows counted at each trap by location. Each location has multiple traps.
select locationID, [Trap_#], sum(count) minnowCountSum from tblFieldDataMinnowTrapSurveys group by locationID, [Trap_#] 
;

-- 8: show how many minnows of each stage were counted at the location ASIS_HERPS_20H
select stage, sum(count) minnowCountSum from tblFieldDataMinnowTrapSurveys where locationID = 'ASIS_HERPS_20H' group by stage 
;

-- 9: What is the average water temperature (celcius) at locations where amphibians were counted?
select avg(tempc) avgTemp from tblFieldDataWaterProperties where locationId in ( 	select locationId  	from tblFieldDataAmphibianCallCounts ) 
;

-- 10: Show the average temperature, salinity, conductivity, and pH level of the water at locations corresponding to turtle observation records.
select avg(tempc) avgTempC, avg(salinity) avgSalinity, avg(conductivity) avgConduct, avg(pH) avgPH from tblFieldDataWaterProperties w, tblFieldDataTurtleTrapSurveys t where w. recordid in ( 	select recordid from tblFieldDataTurtleTrapSurveys )  
;

-- 11: Make a list of turtle record IDs and measurement comments where the trap survey sex data did not match the measurement sex data.
select t.RecordID, m.comments from tblFieldDataTurtleTrapSurveys t join tblFieldDataTurtleMeasurements m on t.RecordID = m.RecordID  	and m.sex <> t.sex 
;

-- 12: show the heaviest turtle for each sex
select sex, max(weight) heaviestWeight from tblFieldDataTurtleMeasurements group by sex 
;

-- 13: what is the highest snake snout-to-vent length recorded?
select  svl  from tblFieldDataSnakeDataCollection order by svl desc limit 1
;

-- 14: Show the average snake weight and snout-to-vent length by sex.
select sex, avg(weight) avgWeight, avg(svl) avgSvl from tblFieldDataSnakeDataCollection group by sex 
;

-- 15: show the average snake total length and weight by species.
select [Species_Code], avg(TLength) avgTLength, avg(Weight) avgWeight from tblFieldDataSnakeDataCollection group by [Species_Code] 
;

-- 16: Show a count of turtle measurements made by each agency.
select [Agency/Title], count(distinct recordID) from tblFieldDataTurtleMeasurements t join tlinkObservers ol on t.EventID = ol.EventID join Observer_LU o on o.obsinits = ol.obsinits group by [Agency/Title] 
;

-- 17: Make a list of all event IDs from 2004 that were observed by Allison Turner
select e.Eventid  from tblEvents e join tblEventDataHerps ed on e.eventid = ed.EventID join tlinkObservers ol on ed.EventID = ol.EventID join Observer_LU o on ol.ObsInits = o.ObsInits where year = 2004  	and firstName = 'allison' 	and lastName = 'turner' 
;

-- 18: Which observers participated in events where measurements of turtle were made? Show their initials, and first and last names.
select distinct o.ObsInits, firstName, lastName  from tlinkObservers ol join Observer_LU o on ol.ObsInits = o.ObsInits join tblFieldDataTurtleMeasurements tm on tm.EventID = ol.EventID 
;

-- 19: how many distinct species were documented on a reptile survey green card?
select count(distinct [species_code]) speciesCount from tblFieldDataGreenCardObservations 
;

-- 20: what are the Universal Transverse Mercator x and y coordinates for locations where time constrained searches were conducted? Include the location ID and x and y point coordinate averages in the result.
select l.locationId, avg(UTMX) X, avg(UTMY) Y from tblFieldDataTimeConstrainedSearches df join tblLocationsPoints l on df.LocationID = l.LocationID group by l.locationId 
;

-- 21: show a count of minnow measurements by stage description
select description, count(*) minnowCount from tlustage s join tblFieldDataMinnowTrapSurveys m on s.stage = m.stage group by description 
;

-- 22: What is the ID and description of the occasional abundance category?
select AbundanceID, AbundanceText from tblAbundance_LU where Abundance = 'Occasional' 
;

-- 23: What are the location IDs of locations that have covers made out of wood? Only include one row per location ID.
select distinct LocationID  from tblFieldDataCoverBoard where type = 'Wood' 
;

-- 24: Show the board number and types for boards at site with ID 18CB1. Ignore boards with a number 0.
select [Board_#], type  from tblFieldDataCoverBoard cb join tblLocations l on cb.LocationID = l.LocationID where siteid = '18CB1' and [Board_#] <> 0 
;

-- 25: Show the average air temperature on cloudy days that correspond to cover board  data where the board material is wood at the site with id 30CB2
select avg(AirTemp) as avgTemp  from tblFieldDataCoverBoard cb join tblEventDataHerps ev on cb.EventID = ev.EventID join tblLocations l on cb.LocationID = l.LocationID where Type = 'Metal' and SiteId = '30CB2' and weather = 'cloudy' 
;

-- 26: For each behavior type, how many records were documented for snakes captured using the coverboard method?
select behavior, count(*) as recordCount from tblFieldDataSnakeDataCollection where capturemethod = 'coverboard' group by behavior 
;

-- 27: what were the behaviors and capture methods of snakes where the record notes include the word rafters?
select Behavior, CaptureMethod  from tblFieldDataSnakeDataCollection where notes like '%rafters%' 
;

-- 28: for location points associated with records relating to cover boards, at the site with id 18CB1, what are the point IDs, snake ids, board numbers, and UTM X and Y coordinates?
select PointID, SnakeID, [Board_#], UTMX, UTMY from tblFieldDataCoverBoard cb join tblLocations l on cb.LocationID = l.LocationID join tblLocationsPoints lp on l.LocationID = lp.LocationID where Recapture = 'new' and siteid = '18CB1' 
;

-- 29: What are the initials of observers who logged events relating to cover board observations? Include only one row per initials.
select distinct o.ObsInits from Observer_LU o join tlinkObservers tlo on o.ObsInits = tlo.ObsInits join tblEvents e on tlo.EventID = e.EventID join tblFieldDataCoverBoard cb on e.EventID = cb.EventID 
;

-- 30: Show a count of events in the herpetological survey table, group the counts by weather condition. Also include the average air and water temperatures.
select weather, count(*) eventCount, avg(airtemp) avgAirTemp, avg(watertemp) avgWaterTemp  from tblEventDataHerps group by weather 
;

-- 31: Show the average air temperature for herpetological surveys for each observer. Group them by the initials of the observer who logged the event.
select o.ObsInits, avg(airtemp) avgAirTemp from Observer_LU o join tlinkObservers tlo on o.ObsInits = tlo.ObsInits join tblEventDataHerps e on tlo.EventID = e.EventID group by o.ObsInits 
;

-- 32: what is the average air temperature for each weather type for herpetological survey events?
select weather, avg(airtemp) avgAirTemp  from tblEventDataHerps group by weather 
;

-- 33: what is the description of project code WQ?
select description  from tluProject where project = 'WQ' 
;

-- 34: What type of park is the park with code ASIS?
select parktype  from tluParkCode where parkcode = 'ASIS' 
;

-- 35: What does the evidence code DOR mean?
select text  from tluEvidenceCode where [evidence_code] = 'DOR' 
;

-- 36: Show the habitat names and descriptions of the 'Temporary Pond' and 'Permanent Pond' micro habitats.
select habitat, description  from tluMicroHabitat where habitat in ('Temporary Pond', 'Permanent Pond') 
;

-- 37: How many records are logged for each turtle trap type?
select [trap_type], count(*) recordCount from tblFieldDataTurtleTrapSurveys group by [Trap_Type] 
;

-- 38: Which location IDs have crab type turtle traps? Include only one row per location.
select distinct t.locationid from tblLocations l join tblFieldDataTurtleTrapSurveys t on l.LocationID = t.LocationID where [trap_type] = 'crab' 
;

-- 39: What are the average turtle dimensions by sex? Include carapace length and width, plastron length and width, and weight.
select sex, avg([carapace_length]) avgCarLen, avg([carapace_width]) avgCarWid,  			avg([plastron_length]) avgPlasLen, avg([plastron_width]) avgPlasWid, 			avg(weight) avgWeight from tblFieldDataTurtleMeasurements group by sex 
;

-- 40: how many turtle measurements were of turtles carrying eggs or young? This is indicated by the value 1.
select count(*) gravidCount from tblFieldDataTurtleMeasurements where gravid = 1 
;

