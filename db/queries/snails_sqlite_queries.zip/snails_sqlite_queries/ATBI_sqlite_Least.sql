-- 1: What tree species have been observed within nested subplots? Show the species code, genus, sub genus, and common name.
SELECT DISTINCT `CMNM`, `SPC`, `GNS`, `SG`
FROM `NSTS`
JOIN `PLTSPC` ON `NSTS`.`SPC` = `PLTSPC`.`SC`
ORDER BY `CMNM`
;

-- 2: Are there any tree species that have not been observed within nested subplots? What are their common names?
SELECT DISTINCT `CMNM`
FROM `PLTSPC`
WHERE `SC` NOT IN (SELECT DISTINCT `SPC`
FROM `NSTS`)
;

-- 3: What are the five most common geni observed in nested subplots and how many nested subplotes have they been observed in?
SELECT `GNS`, COUNT (*) AS NESTCOUNT
FROM `PLTSPC`
JOIN `NSTS` ON `PLTSPC`.`SC` = `NSTS`.`SPC`
GROUP BY `GNS`
ORDER BY `NESTCOUNT` DESC LIMIT 5
;

-- 4: Show me the different decay stages and their descriptions
SELECT *
FROM `DCYSTG`
;

-- 5: How many events observed at least some stage of decay?
SELECT COUNT (DISTINCT `E_ID`)
FROM `DWOOD`
;

-- 6: How many different decayed logs were found in each event where decay was observed?
SELECT `E_ID`, COUNT (*)
FROM `DWOOD`
GROUP BY `E_ID`
;

-- 7: For the event that observed the most decayed logs, how many of each stage of decay were observed? Show the description of each decay stage in the result.
SELECT `DCSTGDESCR`, COUNT (*) AS NUMLOGS
FROM `DWOOD`
JOIN `DCYSTG` ON `DWOOD`.`DCY` = `DCYSTG`.`DS_ID`
WHERE `E_ID` IN (SELECT `E_ID`
FROM `DWOOD`
GROUP BY `E_ID`
ORDER BY COUNT (*) DESC LIMIT 1)
GROUP BY `DCSTGDESCR`
;

-- 8: Show me the events where both nested subplots and decayed logs were observed. Include the number of decayed logs, and the number of nested subplots were observed.
SELECT `E`.`E_ID`, `DEADWOOD_COUNT`, `NEST_COUNT`
FROM `EVS` AS E
JOIN (SELECT `E_ID`, COUNT (*) AS DEADWOOD_COUNT
FROM `DWOOD`
GROUP BY `E_ID`) AS DW ON `E`.`E_ID` = `DW`.`E_ID`
JOIN (SELECT `E_ID`, COUNT (*) AS NEST_COUNT
FROM `NSTS`
GROUP BY `E_ID`) AS NE ON `E`.`E_ID` = `NE`.`E_ID`
ORDER BY `DEADWOOD_COUNT` DESC
;

-- 9: Get the Plot ID, x and y coordinates, and directions for the location with the event that has the most nested subplot observations
SELECT `PL_ID`, `X_C`, `Y_C`, `DIR`
FROM `LOCS` L
JOIN `EVS` E ON `E`.`L_ID` = `L`.`L_ID`
WHERE `E`.`E_ID` IN (SELECT `E_ID`
FROM `NSTS`
GROUP BY `E_ID`
ORDER BY COUNT (*) LIMIT 1)
;

-- 10: What is the average diameter at breast height for  trees of the Acer genus?
SELECT AVG (`DBH`) AVGDBH
FROM `OVRSTRY` O
JOIN `PLTSPC` P ON `O`.`SPC` = `P`.`SC`
WHERE `GNS` = 'Acer'
;

-- 11: What is the canopy position name and the count of trees for each canopy position
SELECT `CANPOS_NM`, COUNT (*) AS TREECOUNT
FROM `CNPS` P
JOIN `OVRSTRY` O ON `P`.`CANPOS_NUM` = `O`.`CPOS`
GROUP BY `CANPOS_NM`
;

-- 12: Create a list of trees where their condition is 'down'. Include the tree tag number, and species common name.
SELECT `CMNM`, `TT`
FROM `PLTSPC` S
JOIN `OVRSTRY` O ON `S`.`SC` = `O`.`SPC`
JOIN `TRCND` C ON `O`.`TRCOND` = `C`.`TCN`
WHERE `TC_TEXT` = 'down'
;

-- 13: Get a count of saplings entries for each species code for species with more than 20 saplings entries
SELECT `SPC`, COUNT (*) AS SAPLINGCOUNT
FROM `SPLG`
GROUP BY `SPC`
HAVING COUNT (*) > 20
;

-- 14: How many saplings records are there that have an entry higher than 10 in the diameter class 3 field?
SELECT COUNT (*) AS SAPLINGCOUNT
FROM `SPLG`
WHERE `DCLASS3` > 10
;

-- 15: What is the highest seedling density for each species code?
SELECT `SPC`, MAX (`DNS`) SEEDLINGDENSITY
FROM `SDLG`
GROUP BY `SPC`
;

-- 16: How many events recorded seedling density data?
SELECT COUNT (DISTINCT `E_ID`) EVENTCOUNT
FROM `SDLG`
;

-- 17: What are the directions to the plot where the tree with tag number 6 is located?
SELECT `DIR`
FROM `TTGS` T
JOIN `LOCS` L ON `T`.`L_ID` = `L`.`L_ID`
WHERE `TTID` = 6
;

-- 18: Show the description and location notes for locations higher than 4000 feet in elevation
SELECT `SD`, `L_NOTES`
FROM `LOCS`
WHERE `ELV` > 4000
;

-- 19: For each event ID, show the count of nested sub plots for each cover class text description.
SELECT `E_ID`, `CC_TXT`, COUNT (*) NESTCOUNT
FROM `CVCLS` CC
JOIN `NSTS` N ON `CC`.`CCN` = `N`.`CVR`
GROUP BY `E_ID`, `CC_TXT`
;

-- 20: Show the azimuth and distance from the witness tree stake to the tree for trees with a diameter at breast height of less than 30
SELECT `W_AZ`, `W_STK`
FROM `WTNSTRS`
WHERE `WITNESS_DBH` < 30
;

-- 21: For each genus and species, get the total number of witness trees observed.
SELECT `GNS`, `SPCS`, COUNT (*) TREECOUNT
FROM `PLTSPC` S
JOIN `WTNSTRS` W ON `S`.`SC` = `W`.`WITSPCD`
GROUP BY `GNS`, `SPCS`
;

-- 22: What are the listed and valid names of the trail adjacent to the location associated with event id 2?
SELECT `LSTNM`, `V_NM`
FROM `RDSTRL` RT
JOIN `LOCS` L ON `L`.`TR` = `RT`.`LSTNM`
JOIN `EVS` E ON `E`.`L_ID` = `L`.`L_ID`
WHERE `E`.`E_ID` = 2
;

-- 23: Show a count of tree tags by state and county.
SELECT `ST`, `CTY`, COUNT (*) TAGCOUNT
FROM `PLNM` PN
JOIN `LOCS` L ON `PN`.`ID` = `L`.`PNID`
JOIN `TTGS` TG ON `L`.`L_ID` = `TG`.`L_ID`
GROUP BY `ST`, `CTY`
;

-- 24: What are the East and North Universal Transverse Mercator coordinates for the locations in Blount county? Include the location name.
SELECT `NM`, `UTME`, `UTMN`
FROM `PLNM`
WHERE `CTY` = 'Blount'
;

-- 25: Show the topographic position description from the topographic position lookup table for the location with X coordinate 269647 and Y coordinate 3943851
SELECT `T`.`TPPOS`
FROM `TOPPOS` T
JOIN `LOCS` L ON `L`.`TP_POS` = `T`.`ID`
WHERE `X_C` = 269647 AND `Y_C` = 3943851
;

-- 26: what is the condition number for the 'Dead' condition text entry?
SELECT `CNUM`
FROM `LV_DD`
WHERE `CTXT` = 'Dead'
;

-- 27: What is the text entry for presence number 3?
SELECT `PTXT`
FROM `PRSNC`
WHERE `PNUM` = 3
;

-- 28: What is the default datum for this project?
SELECT `DM`
FROM `TADEF`
;

-- 29: Make a list of genus, species, and common name, for overstory (trees) in Swain county. Include only one row per distinct combination.
SELECT DISTINCT `GNS`, `SPCS`, `CMNM`
FROM `PLTSPC` SP
JOIN `OVRSTRY` OS ON `SP`.`SC` = `OS`.`SPC`
JOIN `TTGS` TT ON `TT`.`TTID` = `OS`.`TT`
JOIN `LOCS` L ON `L`.`L_ID` = `TT`.`L_ID`
JOIN `PLNM` PN ON `PN`.`ID` = `L`.`PNID`
WHERE `CTY` = 'Swain'
;

-- 30: Which tree species were recorded as mature overstory but not as saplings? Include the species name and common name.
SELECT `SPCS`, `CMNM`
FROM `PLTSPC` SP
WHERE EXISTS (SELECT `O_ID`
FROM `OVRSTRY`
WHERE `SPC` = `SP`.`SC`) AND NOT EXISTS (SELECT `SDL_ID`
FROM `SDLG`
WHERE `SPC` = `SP`.`SC`)
;

-- 31: What are the x an y coordinates for the tree with tag 652?
SELECT `XC`, `YC`
FROM `TTGS`
WHERE `T` = 652
;

-- 32: For each cover class text description, how many nested subplots records are there?
SELECT `CC_TXT`, COUNT (*) NESTEDSUBPLOTCOUNT
FROM `NSTS` N
JOIN `CVCLS` R2 ON `N`.`R2` = `R2`.`CCN`
GROUP BY `CC_TXT`
;

-- 33: For each presence class text description, how many nested subplots records are there where the presence class is the presence class of species in the firsted nested corner within a module?
SELECT `PTXT`, COUNT (*) NESTEDSUBPLOTCOUNT
FROM `NSTS` N
JOIN `PRSNC` P ON `N`.`P_FST` = `P`.`PNUM`
GROUP BY `PTXT`
;

-- 34: What is the highest midpoint diameter (in meters) for each type of deadwood decay?
SELECT `DCY`, MAX (`MPD`) MAXMPD
FROM `DWOOD`
GROUP BY `DCY`
;

-- 35: What is the longest length for each type of deadwood decay?
SELECT `DCY`, MAX (`LN`) MAXLENGTH
FROM `DWOOD`
GROUP BY `DCY`
;

-- 36: What is the decay stage description for the decay stage associated with the lowest recorded midpoint diameter (in meters)?
SELECT `DCSTGDESCR`
FROM `DCYSTG` DS
WHERE `DS`.`DS_ID` IN (SELECT `DCY`
FROM `DWOOD`
ORDER BY `MPD` ASC LIMIT 1)
;

-- 37: What is the decay stage description for the decay stage associated with the shortest recorded length?
SELECT `DCSTGDESCR`
FROM `DCYSTG` DS
WHERE `DS`.`DS_ID` IN (SELECT `DCY`
FROM `DWOOD`
ORDER BY `LN` ASC LIMIT 1)
;

-- 38: Show the site description, slope, aspect, location notes, and accuracy notes, for locations with a convex slope shape.
SELECT `SD`, `SL`, `ASP`, `L_NOTES`, `A_NT`
FROM `LOCS`
WHERE `S_SHP` = 'convex'
;

-- 39: What is the quad name for the location with a topographic position of 7?
SELECT `QN`
FROM `LOCS`
WHERE `TP_POS` = 7
;

-- 40: For each tree condition text description, show a count of the number of sapling records.
SELECT `TC_TEXT`, COUNT (*) SAPLINGCOUNT
FROM `SPLG` S
JOIN `TRCND` C ON `S`.`CND` = `C`.`TCN`
GROUP BY `TC_TEXT`
;

