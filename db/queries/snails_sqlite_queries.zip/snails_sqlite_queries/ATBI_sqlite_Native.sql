-- 1: What tree species have been observed within nested subplots? Show the species code, genus, sub genus, and common name.
select distinct CommonName, SpCode, genus, subgenus  from tbl_Nests join tlu_PlantSpecies on tbl_Nests.SpCode = tlu_PlantSpecies.SpeciesCode order by CommonName 
;

-- 2: Are there any tree species that have not been observed within nested subplots? What are their common names?
select distinct CommonName  from tlu_PlantSpecies where SpeciesCode not in ( 	select distinct SpCode from tbl_Nests 	) 
;

-- 3: What are the five most common geni observed in nested subplots and how many nested subplotes have they been observed in?
select  genus, count(*) as NestCount  from tlu_PlantSpecies join tbl_Nests on tlu_PlantSpecies.SpeciesCode = tbl_Nests.SpCode group by genus order by NestCount desc limit 5
;

-- 4: Show me the different decay stages and their descriptions
select *  from tlu_DecayStage 
;

-- 5: How many events observed at least some stage of decay?
select count(distinct Event_ID)  from tbl_Deadwood 
;

-- 6: How many different decayed logs were found in each event where decay was observed?
select Event_ID, count(*)  from tbl_Deadwood  group by Event_ID 
;

-- 7: For the event that observed the most decayed logs, how many of each stage of decay were observed? Show the description of each decay stage in the result.
select DecayStage_Descr, count(*) as numLogs  from tbl_Deadwood join tlu_DecayStage on tbl_Deadwood.Decay = tlu_DecayStage.DecayStage_ID where Event_ID in ( 	select Event_ID from tbl_Deadwood group by Event_ID order by count(*) desc limit 1 ) group by DecayStage_Descr 
;

-- 8: Show me the events where both nested subplots and decayed logs were observed. Include the number of decayed logs, and the number of nested subplots were observed.
SELECT e.Event_ID, Deadwood_Count, Nest_Count  FROM tbl_Events AS e JOIN (     SELECT Event_ID, COUNT(*) AS Deadwood_Count     FROM tbl_Deadwood     GROUP BY Event_ID ) AS dw ON e.Event_ID = dw.Event_ID JOIN (     SELECT Event_ID, COUNT(*) AS Nest_Count     FROM tbl_Nests     GROUP BY Event_ID ) AS ne ON e.Event_ID = ne.Event_ID order by Deadwood_Count desc 
;

-- 9: Get the Plot ID, x and y coordinates, and directions for the location with the event that has the most nested subplot observations
SELECT Plot_ID, X_Coord, Y_Coord, Directions  from tbl_Locations l JOIN tbl_Events e on e.Location_ID = l.Location_ID WHERE e.Event_ID in ( 	SELECT Event_ID  	from tbl_Nests  	group by Event_ID  	order by count(*) limit 1  ) 
;

-- 10: What is the average diameter at breast height for  trees of the Acer genus?
select avg(DBH) AvgDBH from tbl_Overstory o join tlu_PlantSpecies p on o.SpCode = p.SpeciesCode where genus = 'Acer' 
;

-- 11: What is the canopy position name and the count of trees for each canopy position
select CanPos_Name, count(*) as treeCount from tlu_Can_Pos p join tbl_Overstory o on p.CanPos_Num = o.CanPos group by CanPos_Name 
;

-- 12: Create a list of trees where their condition is 'down'. Include the tree tag number, and species common name.
select CommonName, TreeTag from tlu_PlantSpecies s join tbl_Overstory o on s.SpeciesCode = o.SpCode join tlu_Tree_Cond c on o.TreeCond = c.TreeCond_Num where TreeCond_Text = 'down' 
;

-- 13: Get a count of saplings entries for each species code for species with more than 20 saplings entries
select spcode, count(*) as saplingCount from tbl_Saplings group by spcode having count(*) > 20 
;

-- 14: How many saplings records are there that have an entry higher than 10 in the diameter class 3 field?
select count(*) as SaplingCount from tbl_Saplings where DClass3 > 10 
;

-- 15: What is the highest seedling density for each species code?
select SpCode, max(Density) seedlingDensity from tbl_Seedlings group by SpCode 
;

-- 16: How many events recorded seedling density data?
select count(distinct Event_ID) EventCount from tbl_Seedlings 
;

-- 17: What are the directions to the plot where the tree with tag number 6 is located?
select directions  from tbl_Tree_Tags t join tbl_Locations l on t.Location_ID = l.Location_ID where Tree_Tag_ID = 6 
;

-- 18: Show the description and location notes for locations higher than 4000 feet in elevation
select SiteDescription, Loc_Notes  from tbl_locations where Elevation > 4000 
;

-- 19: For each event ID, show the count of nested sub plots for each cover class text description.
select Event_ID, CoverClass_Text, count(*) NestCount from tlu_Cover_Cls cc join tbl_Nests n on cc.CoverClass_Num = n.Cover group by Event_ID, CoverClass_Text 
;

-- 20: Show the azimuth and distance from the witness tree stake to the tree for trees with a diameter at breast height of less than 30
select Witness_Azimuth, Witness_stake from tbl_WitnessTrees where Witness_DBH < 30 
;

-- 21: For each genus and species, get the total number of witness trees observed.
select genus, species, count(*) treeCount from tlu_PlantSpecies s join tbl_WitnessTrees w on s.SpeciesCode = w.Witness_SpCode group by genus, species 
;

-- 22: What are the listed and valid names of the trail adjacent to the location associated with event id 2?
select ListedName, ValidName  from tlu_Roads_and_Trails rt join tbl_locations l on l.Trail = rt.ListedName join tbl_Events e on e.Location_ID = l.Location_ID where e.Event_ID = 2 
;

-- 23: Show a count of tree tags by state and county.
select State, County, count(*) tagCount from tlu_PlaceNames pn join tbl_locations l on pn.id = l.PlaceNameID join tbl_Tree_Tags tg on l.Location_ID = tg.Location_ID group by State, County 
;

-- 24: What are the East and North Universal Transverse Mercator coordinates for the locations in Blount county? Include the location name.
 select Name, utmE, utmN   from tlu_PlaceNames  where county = 'Blount' 
;

-- 25: Show the topographic position description from the topographic position lookup table for the location with X coordinate 269647 and Y coordinate 3943851
select t.TopoPosition from tlu_topo_position t join tbl_Locations l on l.Topo_Position = t.ID where x_coord = 269647 and y_coord = 3943851 
;

-- 26: what is the condition number for the 'Dead' condition text entry?
select Cond_Num from tlu_live_dead where Cond_Text = 'Dead' 
;

-- 27: What is the text entry for presence number 3?
select pres_text  from tlu_presence where pres_num = 3 
;

-- 28: What is the default datum for this project?
select Datum  from tsys_App_Defaults  
;

-- 29: Make a list of genus, species, and common name, for overstory (trees) in Swain county. Include only one row per distinct combination.
select distinct genus, species, CommonName from tlu_PlantSpecies sp join tbl_Overstory os on sp.SpeciesCode = os.SpCode join tbl_Tree_Tags tt on tt.Tree_Tag_ID = os.TreeTag join tbl_locations l on l.Location_ID = tt.Location_ID join tlu_PlaceNames pn on pn.ID = l.PlaceNameID where county = 'Swain' 
;

-- 30: Which tree species were recorded as mature overstory but not as saplings? Include the species name and common name.
select species, CommonName from tlu_PlantSpecies sp where exists( 	select overstory_id  	from tbl_Overstory  	where SpCode = sp.SpeciesCode ) and not exists ( 	select Seedlings_ID  	from tbl_Seedlings  	where SpCode = sp.SpeciesCode ) 
;

-- 31: What are the x an y coordinates for the tree with tag 652?
select Xcoord, Ycoord  from tbl_Tree_Tags where tag = 652 
;

-- 32: For each cover class text description, how many nested subplots records are there?
select CoverClass_Text, count(*) NestedSubplotCount from tbl_nests n join tlu_Cover_Cls r2 on n.r2 = r2.CoverClass_Num group by CoverClass_Text 
;

-- 33: For each presence class text description, how many nested subplots records are there where the presence class is the presence class of species in the firsted nested corner within a module?
select pres_text, count(*) NestedSubplotCount from tbl_nests n join tlu_Presence p on n.Presence_First = p.Pres_Num group by pres_text 
;

-- 34: What is the highest midpoint diameter (in meters) for each type of deadwood decay?
select decay, max(MPD) maxMPD from tbl_Deadwood group by decay 
;

-- 35: What is the longest length for each type of deadwood decay?
select decay, max(length) maxLength from tbl_Deadwood group by decay 
;

-- 36: What is the decay stage description for the decay stage associated with the lowest recorded midpoint diameter (in meters)?
select DecayStage_Descr from tlu_DecayStage ds where ds.DecayStage_ID in ( 	select decay 	from tbl_Deadwood 	order by MPD asc limit 1 ) 
;

-- 37: What is the decay stage description for the decay stage associated with the shortest recorded length?
select DecayStage_Descr from tlu_DecayStage ds where ds.DecayStage_ID in ( 	select decay 	from tbl_Deadwood 	order by Length asc limit 1 ) 
;

-- 38: Show the site description, slope, aspect, location notes, and accuracy notes, for locations with a convex slope shape.
select SiteDescription, slope, Aspect, Loc_Notes, Accuracy_Notes from tbl_Locations where slope_shape = 'convex' 
;

-- 39: What is the quad name for the location with a topographic position of 7?
select QuadName from tbl_Locations where Topo_Position = 7 
;

-- 40: For each tree condition text description, show a count of the number of sapling records.
select TreeCond_Text, count(*) saplingCount from tbl_Saplings s join tlu_Tree_Cond c on s.Condition = c.TreeCond_Num group by TreeCond_Text 
;

