-- 1: Show the event notes and location IDs from events that started on August 5th, 2011
SELECT `E_NTS`, `L_ID`
FROM `EDTL` D
JOIN `EVS` E ON `E`.`E_ID` = `D`.`E_ID`
WHERE DATE (`ST_DT`) BETWEEN DATE ('2011-08-05') AND DATE ('2011-08-05')
;

-- 2: Show the event notes and location Names from events that started on August 5th, 2011
SELECT `E_NTS`, `LCNM`
FROM `EDTL` D
JOIN `EVS` E ON `E`.`E_ID` = `D`.`E_ID`
JOIN `LOCS` L ON `E`.`L_ID` = `L`.`L_ID`
WHERE DATE (`ST_DT`) BETWEEN DATE ('2011-08-05') AND DATE ('2011-08-05')
;

-- 3: How many events are there?
SELECT COUNT (*) EVENTCOUNT
FROM `EVS`
;

-- 4: How many events have both micro habitat and macro habitat observations?
SELECT COUNT (*)
FROM `MACHAB` MAC
JOIN `MICHAB` MIC ON `MAC`.`E_ID` = `MIC`.`E_ID`
;

-- 5: Show the average slope of macro habitat events with Upland hydrology
SELECT AVG (`SLP`) AVGSLOPE
FROM `MACHAB`
WHERE `HDLGY` = 'Upland'
;

-- 6: What is the reason for the most-recent database edit, and what table and field was edited, and when was it changed?
SELECT `RSN`, `TBL`, `FD`, `D_CHG`
FROM `EL`
ORDER BY `D_CHG` DESC LIMIT 1
;

-- 7: What is the average percent soil disturbance of micro habitats with surface water?
SELECT AVG (`SLTDST`) AVGSOILDISTURBANCE
FROM `MICHAB`
WHERE `SFCW` > 0
;

-- 8: For the event at the highest elevation recorded on July 28 2009, show the light index, evergreen coverage, litter coverage, vegetation height, and elevation
SELECT `LIDX`, `EVGN`, `LTR`, `VGHT`, `ELV`
FROM `MICHAB` M
JOIN `EVS` E ON `M`.`E_ID` = `E`.`E_ID`
JOIN `LOCS` L ON `E`.`L_ID` = `L`.`L_ID`
WHERE DATE (`ST_DT`) BETWEEN DATE ('2009-07-28') AND DATE ('2009-07-28')
ORDER BY `ELV` DESC LIMIT 1
;

-- 9: How many species are included in the crater lakes lookup species lookup table?
SELECT COUNT (DISTINCT `SP`) SPECIESCOUNT
FROM `TS_CRLA`
;

-- 10: Show all of the species listed in the Lava Beds National Monument species lookup table in 2017
SELECT `SP`
FROM `TLUSPLAB`
WHERE `S_YR` = 2017
;

-- 11: For each year, display a count of distinct species in the oregon caves national monument and preserve species lookup table.
SELECT `S_YR`, COUNT (DISTINCT `SP`) SPECIESCOUNT
FROM `TLU_SPC_ORC`
GROUP BY `S_YR`
;

-- 12: For each year, display a count of distinct species in the Redwood National Parks species lookup table.
SELECT `S_YR`, COUNT (DISTINCT `SP`) SPECIESCOUNT
FROM `TS_REDW`
GROUP BY `S_YR`
;

-- 13: Make a list of species that are in the Redwood national parks species lookup table that are not in the Whiskeytown National Recreation area species lookup table. Include only one row per species.
SELECT DISTINCT `SP`
FROM `TS_REDW`
WHERE `SP` NOT IN (SELECT `SP`
FROM `TSW`)
;

-- 14: Which species are in both the Oregon Caves National Monument species lookup table and the Lassen Volcanic National Park species lookup table? Include only one row per species.
SELECT DISTINCT `SP`
FROM `TS_LAVO`
WHERE `SP` IN (SELECT `SP`
FROM `TLU_SPC_ORC`)
;

-- 15: What is the position title, city, state, and zip code, of the contact with the first name Ivan and the last name C?
SELECT `P_TTL`, `CY`, `S_CD`, `ZPCD`
FROM `TC`
WHERE `F_NM` = 'Ivan' AND `L_NM` = 'C'
;

-- 16: What is Dominic D's position title?
SELECT `P_TTL`
FROM `TC`
WHERE `F_NM` = 'Dominic' AND `L_NM` = 'D'
;

-- 17: How many different enumeration groups are there?
SELECT COUNT (DISTINCT `EG`) ENUMCOUNT
FROM `TLU_ENUM`
;

-- 18: What is the description of the Logging code in the Land Use enumeration group?
SELECT `EDESC`
FROM `TLU_ENUM`
WHERE `EG` = 'Land Use' AND `EC` = 'Logging'
;

-- 19: How many different codes are there for each enumeration group?
SELECT `EG`, COUNT (*) CODECOUNT
FROM `TLU_ENUM`
GROUP BY `EG`
;

-- 20: What is the revision reason and description for revisions made by Allison S?
SELECT `RVRSN`, `RVDSC`
FROM `TDR` R
JOIN `TC` C ON `R`.`R_CTID` = `C`.`C_ID`
WHERE `F_NM` = 'Allison' AND `L_NM` = 'S'
;

-- 21: For each year, show how many revisions were made to the database.
SELECT STRFTIME ('%Y', `RVDT`) YEARREVISED, COUNT (*) REVISIONCOUNT
FROM `TDR`
GROUP BY STRFTIME ('%Y', `RVDT`)
;

-- 22: Show the name, ID, description, length, and route of the site with the highest starting Y coordinate.
SELECT `S_ID`, `S_NM`, `SD`, `LN`, `RT`
FROM `TSITES`
ORDER BY `S_ST_Y` DESC LIMIT 1
;

-- 23: Show the starting and ending X and Y coordinates for the site named Nobles Pass C
SELECT `S_ST_X`, `S_DN_X`, `S_ST_Y`, `S_EN_Y`
FROM `TSITES`
WHERE `S_NM` = 'Nobles Pass C'
;

-- 24: What is the name and number of sites of the site with the most locations?
SELECT `S_NM`, COUNT (*) LOCATIONCOUNT
FROM `TSITES` S
JOIN `LOCS` L ON `S`.`S_ID` = `L`.`S_ID`
GROUP BY `S_NM`
ORDER BY COUNT (*) DESC LIMIT 1
;

-- 25: Show location name and the X and Y coordinates of all the locations at the site named North A
SELECT `LCNM`, `XC`, `YC`
FROM `TSITES` S
JOIN `LOCS` L ON `S`.`S_ID` = `L`.`S_ID`
WHERE `S_NM` = 'North A'
;

-- 26: What is the first name of the contact associated with the highest number of unique events?
SELECT `F_NM`
FROM `TC` C
JOIN `XEVCTCS` X ON `C`.`C_ID` = `X`.`C_ID`
GROUP BY `F_NM`
ORDER BY COUNT (DISTINCT `E_ID`) DESC LIMIT 1
;

-- 27: What are the First names, last names, and position titles of contacts who uploaded an event that started in August of 2021? Include only one row per contact
SELECT DISTINCT `F_NM`, `L_NM`, `P_TTL`
FROM `TC` C
JOIN `XEVCTCS` X ON `C`.`C_ID` = `X`.`C_ID`
JOIN `EVS` E ON `X`.`E_ID` = `E`.`E_ID`
WHERE DATE (`ST_DT`) >= DATE ('2021-08-01') AND DATE (`ST_DT`) <= DATE ('2021-08-31')
;

-- 28: How many events were documented at each location? Show the location name and count of events. Only show the 10 locations with the highest number of events.
SELECT `LCNM`, COUNT (*) EVENTCOUNT
FROM `LOCS` L
JOIN `EVS` E ON `L`.`L_ID` = `E`.`L_ID`
GROUP BY `LCNM`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 29: How many events were documented at each site? Show the site name, site description, and count of events. Only show the 10 sites with the highest number of events.
SELECT `S_NM`, `SD`, COUNT (*) EVENTCOUNT
FROM `LOCS` L
JOIN `EVS` E ON `L`.`L_ID` = `E`.`L_ID`
JOIN `TSITES` S ON `L`.`S_ID` = `S`.`S_ID`
GROUP BY `S_NM`, `SD`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 30: What is the trimble position dilution of position, the horizontal dilution of position, and the estimated position error of the locations at the site named Mule Town B?
SELECT `PDOP`, `HDOP`, `EPE`
FROM `LOCS` L
JOIN `TSITES` S ON `L`.`S_ID` = `S`.`S_ID`
WHERE `S_NM` = 'Mule Town B'
;

-- 31: How many locations are there in Shasta count?
SELECT COUNT (*) LOCCOUNT
FROM `LOCS`
WHERE `CTY` = 'Shasta'
;

-- 32: For each location type, show a count of locations in shasta county.
SELECT `LCTP`, COUNT (*) LOCCOUNT
FROM `LOCS`
WHERE `CTY` = 'Shasta'
GROUP BY `LCTP`
;

-- 33: Show the names of the ten sites and the count of infested sites, of the sites with the most locations of type infestation
SELECT `S_NM`, COUNT (*) SITECOUNT
FROM `LOCS` L
JOIN `TSITES` S ON `L`.`S_ID` = `S`.`S_ID`
WHERE `LCTP` = 'Infestation'
GROUP BY `S_NM`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 34: Show a list of event IDs for events that were documented at the Wood River watershed and the Annie Creek sub watershed
SELECT `E_ID`
FROM `EVS` E
JOIN `LOCS` L ON `E`.`L_ID` = `L`.`L_ID`
WHERE `WSHD` = 'Wood River' AND `SBWS` = 'Annie Creek'
;

-- 35: What is the average elevation of the Annie Creek Subwatershed?
SELECT AVG (`ELV`) AVGELEVATION
FROM `LOCS`
WHERE `SBWS` = 'Annie Creek'
;

-- 36: How many locations were a randomly generated plot that was found to have an infestation?
SELECT COUNT (*) LOCCOUNT
FROM `LOCS`
WHERE `RPI` = 'Yes'
;

-- 37: Show the X and Y coordinates, the coordinate units, the coordinate system and datum, the horizontal error, accuracy notes and location type of the location named CRLA-Infestation-3924
SELECT `LCNM`, `XC`, `YC`, `CRDUNTS`, `CRDSYS`, `DM`, `EST_H_ERROR`, `A_NT`, `LCTP`
FROM `LOCS`
WHERE `LCNM` = 'CRLA-Infestation-3924'
;

-- 38: How many events are logged for each Hydrology type?
SELECT `HDLGY`, COUNT (*) EVENTCOUNT
FROM `MACHAB`
GROUP BY `HDLGY`
;

-- 39: Show the Macro Habitat, Micro Habitat, Hydrology, Land Use, Slope, and Aspect of the Macro Habitats associated with events started in July of 2015
SELECT `MAHAB`, `MIHAB`, `HDLGY`, `LU`, `SLP`, `ASP`
FROM `MACHAB` MH
JOIN `EVS` E ON `MH`.`E_ID` = `E`.`E_ID`
WHERE DATE (`ST_DT`) >= DATE ('2015-07-01') AND DATE (`ST_DT`) <= DATE ('2015-07-31')
;

-- 40: What is the deciduous, shrub, herb, debris, litter, ground, and rock coverage of micro habitatis with a Flowering Phenology and a cover percentage greater than 90
SELECT `DCDS`, `SHB`, `HRB`, `WD`, `LTR`, `BRGND`, `RK`
FROM `MICHAB`
WHERE `PHNLGY` = 'Flowering' AND CAST (`CVRPCT` AS FLOAT) > 90
;

