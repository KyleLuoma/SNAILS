-- 1: Show the event notes and location IDs from events that started on August 5th, 2011
SELECT `EVENT_NOTES`, `LOCATION_ID`
FROM `TABLE_EVENT_DETAILS` D
JOIN `TABLE_EVENTS` E ON `E`.`EVENT_ID` = `D`.`EVENT_ID`
WHERE DATE (`START_DATE`) BETWEEN DATE ('2011-08-05') AND DATE ('2011-08-05')
;

-- 2: Show the event notes and location Names from events that started on August 5th, 2011
SELECT `EVENT_NOTES`, `LOCATION_NAME`
FROM `TABLE_EVENT_DETAILS` D
JOIN `TABLE_EVENTS` E ON `E`.`EVENT_ID` = `D`.`EVENT_ID`
JOIN `TABLE_LOCATIONS` L ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE DATE (`START_DATE`) BETWEEN DATE ('2011-08-05') AND DATE ('2011-08-05')
;

-- 3: How many events are there?
SELECT COUNT (*) EVENTCOUNT
FROM `TABLE_EVENTS`
;

-- 4: How many events have both micro habitat and macro habitat observations?
SELECT COUNT (*)
FROM `TABLE_MACROHABITAT` MAC
JOIN `TABLE_MICROHABITAT` MIC ON `MAC`.`EVENT_ID` = `MIC`.`EVENT_ID`
;

-- 5: Show the average slope of macro habitat events with Upland hydrology
SELECT AVG (`SLOPE`) AVGSLOPE
FROM `TABLE_MACROHABITAT`
WHERE `HYDROLOGY` = 'Upland'
;

-- 6: What is the reason for the most-recent database edit, and what table and field was edited, and when was it changed?
SELECT `REASON`, `TABLE`, `FIELD`, `DATE_CHANGE`
FROM `TABLE_EDIT_LOG`
ORDER BY `DATE_CHANGE` DESC LIMIT 1
;

-- 7: What is the average percent soil disturbance of micro habitats with surface water?
SELECT AVG (`SOIL_DISTURBANCE`) AVGSOILDISTURBANCE
FROM `TABLE_MICROHABITAT`
WHERE `SURFACEWATER` > 0
;

-- 8: For the event at the highest elevation recorded on July 28 2009, show the light index, evergreen coverage, litter coverage, vegetation height, and elevation
SELECT `LIGHTINDEX`, `EVERGREEN`, `LITTER`, `VEGETATION_HEIGHT`, `ELEVATION`
FROM `TABLE_MICROHABITAT` M
JOIN `TABLE_EVENTS` E ON `M`.`EVENT_ID` = `E`.`EVENT_ID`
JOIN `TABLE_LOCATIONS` L ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE DATE (`START_DATE`) BETWEEN DATE ('2009-07-28') AND DATE ('2009-07-28')
ORDER BY `ELEVATION` DESC LIMIT 1
;

-- 9: How many species are included in the crater lakes lookup species lookup table?
SELECT COUNT (DISTINCT `SPECIES`) SPECIESCOUNT
FROM `TABLE_LOOKUP_SPECIES_CRATER_LAKE_NP`
;

-- 10: Show all of the species listed in the Lava Beds National Monument species lookup table in 2017
SELECT `SPECIES`
FROM `TABLE_LOOKUP_SPECIES_LABEL`
WHERE `SAMPLEYEAR` = 2017
;

-- 11: For each year, display a count of distinct species in the oregon caves national monument and preserve species lookup table.
SELECT `SAMPLEYEAR`, COUNT (DISTINCT `SPECIES`) SPECIESCOUNT
FROM `TABLE_LOOKUP_SPECIES_ORCA`
GROUP BY `SAMPLEYEAR`
;

-- 12: For each year, display a count of distinct species in the Redwood National Parks species lookup table.
SELECT `SAMPLEYEAR`, COUNT (DISTINCT `SPECIES`) SPECIESCOUNT
FROM `TABLE_LOOKUP_SPECIES_REDWOOD_NSP`
GROUP BY `SAMPLEYEAR`
;

-- 13: Make a list of species that are in the Redwood national parks species lookup table that are not in the Whiskeytown National Recreation area species lookup table. Include only one row per species.
SELECT DISTINCT `SPECIES`
FROM `TABLE_LOOKUP_SPECIES_REDWOOD_NSP`
WHERE `SPECIES` NOT IN (SELECT `SPECIES`
FROM `TABLE_LOOKUP_SPECIES_WHISKEYTOWN_NRA`)
;

-- 14: Which species are in both the Oregon Caves National Monument species lookup table and the Lassen Volcanic National Park species lookup table? Include only one row per species.
SELECT DISTINCT `SPECIES`
FROM `TABLE_LOOKUP_SPECIES_LASSEN_VOLCANIC_NP`
WHERE `SPECIES` IN (SELECT `SPECIES`
FROM `TABLE_LOOKUP_SPECIES_ORCA`)
;

-- 15: What is the position title, city, state, and zip code, of the contact with the first name Ivan and the last name C?
SELECT `POSITION_TITLE`, `CITY`, `STATE_CODE`, `ZIP_CODE`
FROM `TABLE_LOOKUP_CONTACTS`
WHERE `FIRST_NAME` = 'Ivan' AND `LAST_NAME` = 'C'
;

-- 16: What is Dominic D's position title?
SELECT `POSITION_TITLE`
FROM `TABLE_LOOKUP_CONTACTS`
WHERE `FIRST_NAME` = 'Dominic' AND `LAST_NAME` = 'D'
;

-- 17: How many different enumeration groups are there?
SELECT COUNT (DISTINCT `CATEGORY_LOOKUP`) ENUMCOUNT
FROM `TABLE_LOOKUP_ENUMERATIONS`
;

-- 18: What is the description of the Logging code in the Land Use enumeration group?
SELECT `ENUMERATION_DESCRIPTION`
FROM `TABLE_LOOKUP_ENUMERATIONS`
WHERE `CATEGORY_LOOKUP` = 'Land Use' AND `ENUMERATION_CODE` = 'Logging'
;

-- 19: How many different codes are there for each enumeration group?
SELECT `CATEGORY_LOOKUP`, COUNT (*) CODECOUNT
FROM `TABLE_LOOKUP_ENUMERATIONS`
GROUP BY `CATEGORY_LOOKUP`
;

-- 20: What is the revision reason and description for revisions made by Allison S?
SELECT `REVISION_REASON`, `REVISION_DESCRIPTION`
FROM `TABLE_DB_REVISIONS` R
JOIN `TABLE_LOOKUP_CONTACTS` C ON `R`.`REVISION_CONTACT_ID` = `C`.`CONTACT_ID`
WHERE `FIRST_NAME` = 'Allison' AND `LAST_NAME` = 'S'
;

-- 21: For each year, show how many revisions were made to the database.
SELECT STRFTIME ('%Y', `REVISION_DATE`) YEARREVISED, COUNT (*) REVISIONCOUNT
FROM `TABLE_DB_REVISIONS`
GROUP BY STRFTIME ('%Y', `REVISION_DATE`)
;

-- 22: Show the name, ID, description, length, and route of the site with the highest starting Y coordinate.
SELECT `SITE_ID`, `SITE_NAME`, `SITE_DESCRIPTION`, `LENGTH`, `ROUTE`
FROM `TABLE_SITES`
ORDER BY `SITE_START_Y` DESC LIMIT 1
;

-- 23: Show the starting and ending X and Y coordinates for the site named Nobles Pass C
SELECT `SITE_START_X`, `SITE_END_X`, `SITE_START_Y`, `SITE_END_Y`
FROM `TABLE_SITES`
WHERE `SITE_NAME` = 'Nobles Pass C'
;

-- 24: What is the name and number of sites of the site with the most locations?
SELECT `SITE_NAME`, COUNT (*) LOCATIONCOUNT
FROM `TABLE_SITES` S
JOIN `TABLE_LOCATIONS` L ON `S`.`SITE_ID` = `L`.`SITE_ID`
GROUP BY `SITE_NAME`
ORDER BY COUNT (*) DESC LIMIT 1
;

-- 25: Show location name and the X and Y coordinates of all the locations at the site named North A
SELECT `LOCATION_NAME`, `X_COORDINATE`, `Y_COORDINATE`
FROM `TABLE_SITES` S
JOIN `TABLE_LOCATIONS` L ON `S`.`SITE_ID` = `L`.`SITE_ID`
WHERE `SITE_NAME` = 'North A'
;

-- 26: What is the first name of the contact associated with the highest number of unique events?
SELECT `FIRST_NAME`
FROM `TABLE_LOOKUP_CONTACTS` C
JOIN `CROSS_REFERENCE_EVENT_CONTACTS` X ON `C`.`CONTACT_ID` = `X`.`CONTACT_ID`
GROUP BY `FIRST_NAME`
ORDER BY COUNT (DISTINCT `EVENT_ID`) DESC LIMIT 1
;

-- 27: What are the First names, last names, and position titles of contacts who uploaded an event that started in August of 2021? Include only one row per contact
SELECT DISTINCT `FIRST_NAME`, `LAST_NAME`, `POSITION_TITLE`
FROM `TABLE_LOOKUP_CONTACTS` C
JOIN `CROSS_REFERENCE_EVENT_CONTACTS` X ON `C`.`CONTACT_ID` = `X`.`CONTACT_ID`
JOIN `TABLE_EVENTS` E ON `X`.`EVENT_ID` = `E`.`EVENT_ID`
WHERE DATE (`START_DATE`) >= DATE ('2021-08-01') AND DATE (`START_DATE`) <= DATE ('2021-08-31')
;

-- 28: How many events were documented at each location? Show the location name and count of events. Only show the 10 locations with the highest number of events.
SELECT `LOCATION_NAME`, COUNT (*) EVENTCOUNT
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_EVENTS` E ON `L`.`LOCATION_ID` = `E`.`LOCATION_ID`
GROUP BY `LOCATION_NAME`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 29: How many events were documented at each site? Show the site name, site description, and count of events. Only show the 10 sites with the highest number of events.
SELECT `SITE_NAME`, `SITE_DESCRIPTION`, COUNT (*) EVENTCOUNT
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_EVENTS` E ON `L`.`LOCATION_ID` = `E`.`LOCATION_ID`
JOIN `TABLE_SITES` S ON `L`.`SITE_ID` = `S`.`SITE_ID`
GROUP BY `SITE_NAME`, `SITE_DESCRIPTION`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 30: What is the trimble position dilution of position, the horizontal dilution of position, and the estimated position error of the locations at the site named Mule Town B?
SELECT `POSITION_DILUTION_OF_PRECISION`, `HORIZONTAL_DILUTION_OF_PRECISION`, `ESTIMATED_POSITION_ERROR`
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_SITES` S ON `L`.`SITE_ID` = `S`.`SITE_ID`
WHERE `SITE_NAME` = 'Mule Town B'
;

-- 31: How many locations are there in Shasta count?
SELECT COUNT (*) LOCCOUNT
FROM `TABLE_LOCATIONS`
WHERE `COUNTY` = 'Shasta'
;

-- 32: For each location type, show a count of locations in shasta county.
SELECT `LOCATION_TYPE`, COUNT (*) LOCCOUNT
FROM `TABLE_LOCATIONS`
WHERE `COUNTY` = 'Shasta'
GROUP BY `LOCATION_TYPE`
;

-- 33: Show the names of the ten sites and the count of infested sites, of the sites with the most locations of type infestation
SELECT `SITE_NAME`, COUNT (*) SITECOUNT
FROM `TABLE_LOCATIONS` L
JOIN `TABLE_SITES` S ON `L`.`SITE_ID` = `S`.`SITE_ID`
WHERE `LOCATION_TYPE` = 'Infestation'
GROUP BY `SITE_NAME`
ORDER BY COUNT (*) DESC LIMIT 10
;

-- 34: Show a list of event IDs for events that were documented at the Wood River watershed and the Annie Creek sub watershed
SELECT `EVENT_ID`
FROM `TABLE_EVENTS` E
JOIN `TABLE_LOCATIONS` L ON `E`.`LOCATION_ID` = `L`.`LOCATION_ID`
WHERE `WATERSHED` = 'Wood River' AND `SUBWATERSHED` = 'Annie Creek'
;

-- 35: What is the average elevation of the Annie Creek Subwatershed?
SELECT AVG (`ELEVATION`) AVGELEVATION
FROM `TABLE_LOCATIONS`
WHERE `SUBWATERSHED` = 'Annie Creek'
;

-- 36: How many locations were a randomly generated plot that was found to have an infestation?
SELECT COUNT (*) LOCCOUNT
FROM `TABLE_LOCATIONS`
WHERE `RANDOM_PLOT_INDICATOR` = 'Yes'
;

-- 37: Show the X and Y coordinates, the coordinate units, the coordinate system and datum, the horizontal error, accuracy notes and location type of the location named CRLA-Infestation-3924
SELECT `LOCATION_NAME`, `X_COORDINATE`, `Y_COORDINATE`, `COORDINATE_UNITS`, `COORDINATE_SYSTEM`, `DATUM`, `ESTIMATED_HORIZONTAL_GPS_ERROR`, `ACCURACY_NOTES`, `LOCATION_TYPE`
FROM `TABLE_LOCATIONS`
WHERE `LOCATION_NAME` = 'CRLA-Infestation-3924'
;

-- 38: How many events are logged for each Hydrology type?
SELECT `HYDROLOGY`, COUNT (*) EVENTCOUNT
FROM `TABLE_MACROHABITAT`
GROUP BY `HYDROLOGY`
;

-- 39: Show the Macro Habitat, Micro Habitat, Hydrology, Land Use, Slope, and Aspect of the Macro Habitats associated with events started in July of 2015
SELECT `MACROHABITAT`, `MICROHABITAT`, `HYDROLOGY`, `LANDUSE`, `SLOPE`, `ASPECT`
FROM `TABLE_MACROHABITAT` MH
JOIN `TABLE_EVENTS` E ON `MH`.`EVENT_ID` = `E`.`EVENT_ID`
WHERE DATE (`START_DATE`) >= DATE ('2015-07-01') AND DATE (`START_DATE`) <= DATE ('2015-07-31')
;

-- 40: What is the deciduous, shrub, herb, debris, litter, ground, and rock coverage of micro habitatis with a Flowering Phenology and a cover percentage greater than 90
SELECT `DECIDUOUS`, `SHRUB`, `HERB`, `WOODYDEBRIS`, `LITTER`, `BAREGROUND`, `ROCK`
FROM `TABLE_MICROHABITAT`
WHERE `PHENOLOGY` = 'Flowering' AND CAST (`COVERPERCENT` AS FLOAT) > 90
;

