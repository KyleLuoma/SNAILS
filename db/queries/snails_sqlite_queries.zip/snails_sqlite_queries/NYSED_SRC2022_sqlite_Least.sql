-- 1: What are the accountability level of the indicators 'HS Grad Rate' for the multiracial subgroup for all schools with the word friendship in their name? Include the institution ID, entity name, and accountability level in the result.
SELECT `IN_ID`, `EN`, `LVL`
FROM `ACCOUNTABILITY_LEVELS`
WHERE `SG_NM` = 'Multiracial' AND `IND` = 'HS Grad Rate' AND `EN` LIKE '%friendship%'
;

-- 2: Show the percent not tested in 2021 on english language assessment ELA4, for each demographic subgroup at PEMBROKE INTERMEDIATE SCHOOL
SELECT `SG_NM`, `PNTST`
FROM `ANNUAL_EM_ELA`
WHERE `EN` = 'PEMBROKE INTERMEDIATE SCHOOL' AND `ASN` = 'ELA4' AND `YR` = 2021
;

-- 3: What is the total number of new york state alternate assessment records for assessments performed in 2022
SELECT COUNT (*) ENTRYCOUNT
FROM `ANNUAL_NYSAA`
WHERE `YR` = 2022
;

-- 4: Show the student count, federal expenditure, and federal expenditure per student in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT `PCT`, `FED_EXP`, `PPEFF`
FROM `EPP`
WHERE `EN` = 'MONTESSORI MAGNET SCHOOL' AND `YR` = 2022
;

-- 5: Show the student count, federal expenditure, federal expenditure per student, subgroup name, and mean math assessment score for the MATH5 assessment in 2022 for the school named 'MONTESSORI MAGNET SCHOOL'.
SELECT `PCT`, `FED_EXP`, `PPEFF`, `SG_NM`, `MS`
FROM `EPP` EX
JOIN `ANNUAL_EM_MATH` MTH ON `EX`.`ENT_CD` = `MTH`.`ENT_CD` AND `EX`.`YR` = `MTH`.`YR`
WHERE `EX`.`EN` = 'MONTESSORI MAGNET SCHOOL' AND `ASN` = 'MATH5' AND `EX`.`YR` = 2022
;

-- 6: Show the 2022 high school participation rates and graduation rates for the subgroup 'All Students' who attended Brooklyn Collegiate.
SELECT `RT`, `GRD_RT`
FROM `ACC_HS_PARTICIPATION_RATE` P
JOIN `ACC_HS_GRADUATION_RATE` G ON `P`.`ENT_CD` = `G`.`ENT_CD` AND `P`.`SG_NM` = `G`.`SG_NM` AND `P`.`YR` = `G`.`YR` AND `P`.`EN` = `G`.`EN` AND `P`.`IN_ID` = `G`.`IN_ID`
WHERE `P`.`EN` = 'Brooklyn Collegiate' AND `P`.`SG_NM` = 'All Students' AND `P`.`YR` = 2022
;

-- 7: What is Kenney Middle School's 2021 enrollment, absentee count, and absentee rate for the subgroup of students with disabilities?
SELECT `ENR`, `ABS_CNT`, `ABS_R`
FROM `ACCEMCA`
WHERE `EN` = 'KENNEY MIDDLE SCHOOL' AND `YR` = 2021 AND `SG_NM` = 'Students with disabilities'
;

-- 8: Show the annual regents exam percent of LONGWOOD HIGH SCHOOL students at each level from 1 to 5 for the Regents Common Core Algebra I subject taken in 2022. Include the subgroup name, number of students tested, and all of the appropriate percent level score columns.
SELECT `SG_NM`, `TST`, `P_L1`, `P_L2`, `P_L3`, `P_L4`, `P_L5`
FROM `ANNUAL_REGENTS_EXAMS`
WHERE `EN` LIKE '%LONGWOOD HIGH SCHOOL%' AND `YR` = 2022 AND `SBJCT` = 'Regents Common Core Algebra I'
;

-- 9: How many public school entities are in each accountability status in the year 2022?
SELECT `OVR_STS`, COUNT (*) STATUSCOUNT
FROM `ACCOUNTABILITY_STATUS`
WHERE `YR` = 2022 AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
GROUP BY `OVR_STS`
;

-- 10: What is the accountability status and progress status of the  bronx career and college prep HS in 2022?
SELECT `OVR_STS`, `MP`
FROM `ACCOUNTABILITY_STATUS`
WHERE `EN` = 'bronx career and college prep hs' AND `YR` = 2022
;

-- 11: what are the combined subject, core and weighted, performance scores for elementary students with disabilities who attended May Moore Primary School?
SELECT `CRCH`, `W_COH`
FROM `AECWP`
WHERE `EN` = 'May Moore Primary School' AND `SBJCT` = 'combined' AND `SG_NM` = 'Students with Disabilities'
;

-- 12: Make a list of public elementary school entities that do not have the subgroup 'students with disabilities' in the elementary core and weighted performance data.
SELECT DISTINCT `EN`
FROM `AECWP` P
WHERE `P`.`ENT_CD` NOT IN (SELECT `ENT_CD`
FROM `AECWP` Q
WHERE `SG_NM` = 'Students with Disabilities') AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 13: How many public elementary school entities have the subgroup 'multiracial' included in the core and weighted performance data?
SELECT COUNT (DISTINCT `ENT_CD`) SCHOOLCOUNT
FROM `AECWP`
WHERE `SG_NM` = 'multiracial' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 14: Show the school name and english language learner count for the subgroup 'all students' for public school entities that have the word preparatory in their name.
SELECT `EN`, `ELL_COUNT`
FROM `ACC_EM_ELP`
WHERE `SG_NM` = 'all students' AND `EN` LIKE '%preparatory%'
;

-- 15: How many public elementary school entities have white student subgroups who are english language learners?
SELECT COUNT (*) SCHOOLCOUNT
FROM `ACC_EM_ELP`
WHERE `SG_NM` = 'white' AND `ELL_COUNT` <> '0' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 16: What is the english language learner count, benchmark, progress rate, and success ratio for the sub group all students at 'pine bush' elementary school?
SELECT `ELL_COUNT`, `BMK`, `PR`, `S_RATIO`
FROM `ACC_EM_ELP`
WHERE `EN` = 'PINE BUSH' AND `SG_NM` = 'All Students'
;

-- 17: How many public elementary school entities had 0 participation in the new york state english as a second language achievement test?
SELECT COUNT (DISTINCT `ENT_CD`) NOPARTCOUNT
FROM `ACC_EM_NYSESLAT_FOR_PARTICIPATION`
WHERE `NYSESLAT_PART` = '0' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 18: How many different new york state english as a second language achievement test elementary school subjects are there?
SELECT COUNT (DISTINCT `SBJCT`) SUBJECTCOUNT
FROM `ACC_EM_NYSESLAT_FOR_PARTICIPATION`
;

-- 19: Show the names of the public elementary school entities with level 2 english learner programs that have a non-zero number of english language learners in the all students subgroup, who did not participate in the new york state english as a second language achievement test. Include only one row per school name.
SELECT DISTINCT `EN`
FROM `ACC_EM_ELP`
WHERE `ENT_CD` IN (SELECT DISTINCT `ENT_CD`
FROM `ACC_EM_NYSESLAT_FOR_PARTICIPATION`
WHERE `NYSESLAT_PART` = '0') AND `ELL_COUNT` <> '0' AND `SG_NM` = 'all students' AND `LVL` = '2' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 20: What is the 2022 cohort size and student participation rate for all sub groups and subjects at elmwood elementary school?
SELECT `SG_NM`, `SBJCT`, `COH`, `RT`
FROM `ACC_EM_PARTICIPATION_RATE`
WHERE `EN` = 'elmwood elementary school' AND `YR` = 2022
;

-- 21: How many public elementary school entities met a 95 percent participation rate in at least one subject?
SELECT COUNT (DISTINCT `ENT_CD`) SCHOOLCOUNT
FROM `ACC_EM_PARTICIPATION_RATE`
WHERE `M95P` = 'Y' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 22: For public elementary school participation rates not equal to s, calculate the average participation rate.
SELECT AVG (CAST (`RT` AS FLOAT)) AS AVGRATE
FROM `ACC_EM_PARTICIPATION_RATE`
WHERE `RT` <> 's' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
;

-- 23: For each subject, show the average public high school entity chronic absence rate for records where the rate does not equal 's'.
SELECT `SBJCT`, AVG (CAST (`ABS_R` AS FLOAT)) AVGRATE
FROM `ACCEMCA`
WHERE `ABS_R` <> 's' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School')
GROUP BY `SBJCT`
;

-- 24: Show the name of the public elementary school entity that has the lowest chronic absence rate of students with disabilities. Exclude data where the rate value is 's'.
SELECT `EN`
FROM `ACCEMCA`
WHERE `SG_NM` = 'students with disabilities' AND `ABS_R` <> 's'
ORDER BY CAST (`ABS_R` AS FLOAT) DESC LIMIT 1
;

-- 25: show the school name, sub group name, and total enrollment at public elementary school entities that have the highest absenteeism rate in 2022. Exclude data where the absenteeism rate is 's'.
SELECT `A`.`EN`, `SG_NM`, `ENR`
FROM `ACCEMCA` A
JOIN `IG` G ON `A`.`ENT_CD` = `G`.`ENT_CD`
WHERE CAST (`ABS_R` AS FLOAT) = (SELECT MAX (CAST (`ABS_R` AS FLOAT))
FROM `ACCEMCA`
WHERE `ABS_R` <> 's' AND `YR` = 2022) AND `ABS_R` <> 's' AND `YR` = 2022 AND `G_NM` = 'public school'
;

-- 26: What is the average public high school entity chronic absenteeism rate by student sub group in 2021? Do not include rows where the rate is 's'.
SELECT `SG_NM`, AVG (CAST (`ABS_R` AS FLOAT)) AVGRATE
FROM `ACC_HS_CHRONIC_ABSENTEEISM` A
JOIN `IG` G ON `A`.`ENT_CD` = `G`.`ENT_CD`
WHERE `ABS_R` <> 's' AND `G_NM` = 'Public School'
GROUP BY `SG_NM`
;

-- 27: What is the 2021 chronic absenteeism count and rate for the sub group 'All students' at the public high school entity with the highest enrollment? Exclude enrollment data that has the value 's'. Include the school name in the result.
SELECT `EN`, `ABS_CNT`, `ABS_R`
FROM `ACC_HS_CHRONIC_ABSENTEEISM`
WHERE `ENR` <> 's' AND `YR` = 2021 AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'Public School') AND `SG_NM` = 'All Students'
ORDER BY CAST (`ENR` AS FLOAT) DESC LIMIT 1
;

-- 28: What are the core and weighted cohorts, and the core and weighted performance indexes of Economically Disadvantaged Students at Albany High School in the Math subject in 2022?
SELECT `CRCH`, `W_COH`, `CI`, `W_IDX`
FROM `ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE`
WHERE `YR` = 2022 AND `SBJCT` = 'MATH' AND `SG_NM` = 'Economically Disadvantaged' AND `EN` = 'ALBANY HIGH SCHOOL'
;

-- 29: What are the names of the five public high school entity that have the highest weighted performance index score in math for the all student sub group in 2022? Exclude the value 's' from the index score.
SELECT `P`.`EN`
FROM `ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE` P
JOIN `IG` G ON `P`.`ENT_CD` = `G`.`ENT_CD`
WHERE `W_IDX` <> 's' AND `G_NM` = 'Public School' AND `SBJCT` = 'MATH' AND `SG_NM` = 'All Students' AND `YR` = 2022
ORDER BY CAST (`W_IDX` AS FLOAT) DESC LIMIT 5
;

-- 30: Show the school name and the average weighted index subject score for science for the five lowest scoring public school districts. Exclude weighted index scores with the value 's'.
SELECT `EN`, AVG (CAST (`W_IDX` AS FLOAT)) AVERAGESCIENCESCORE
FROM `ACC_HS_CORE_AND_WEIGHTED_PERFORMANCE`
WHERE `W_IDX` <> 's' AND `SBJCT` = 'SCIENCE' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school district')
GROUP BY `EN`
ORDER BY AVG (CAST (`W_IDX` AS FLOAT)) ASC LIMIT 5
;

-- 31: What is the 2022 english language learner count, benchmark size, progress rate, success ration, and level of the english language program at Alfred E Smith Career-Tech HS for the all students subgroup?
SELECT `ELL_COUNT`, `BMK`, `PR`, `S_RATIO`, `LVL`
FROM `ACC_HS_ELP`
WHERE `EN` = 'ALFRED E SMITH CAREER-TECH HS' AND `SG_NM` = 'All Students' AND `YR` = 2022
;

-- 32: What is the average english language learner count at public high schools for each student subgroup?
SELECT `SG_NM`, AVG (CAST (`ELL_COUNT` AS FLOAT)) ELLAVG
FROM `ACC_HS_ELP`
WHERE `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school')
GROUP BY `SG_NM`
;

-- 33: What is the 2022 federal expenditure per student at the public high school with the highest english language learner count in the All Students sub group in their english language program? Include the school name, language learner count, and federal expenditure per student in the result.
SELECT `EL`.`EN`, `ELL_COUNT`, `PER_FED_STATE_LOCAL_EXP`
FROM `ACC_HS_ELP` EL
JOIN `EPP` EX ON `EL`.`ENT_CD` = `EX`.`ENT_CD` AND `EL`.`YR` = `EX`.`YR`
WHERE `SG_NM` = 'All Students' AND `ELL_COUNT` <> 's' AND `EX`.`YR` = 2022 AND `EL`.`ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school district')
ORDER BY CAST (`ELL_COUNT` AS FLOAT) DESC LIMIT 1
;

-- 34: For each year and status type, what is the number of entities in accountability each status for the all students subgroup?
SELECT `YR`, `OVR_STS`, COUNT (*) ENTCOUNT
FROM `ACCOUNTABILITY_STATUS_BY_SUBGROUP`
WHERE `SG_NM` = 'All Students'
GROUP BY `YR`, `OVR_STS`
;

-- 35: How many high schools (HS) had an accountability status of good standing in 2021 for the Multiracial sub group?
SELECT COUNT (*) HSCOUNT
FROM `ACCOUNTABILITY_STATUS_BY_SUBGROUP`
WHERE `S_TP` = 'HS' AND `SG_NM` = 'Multiracial' AND `YR` = 2021
;

-- 36: What is the overall acountability status for each school type and student subgroup in 2021 for the entity named 'albany city SD'?
SELECT `S_TP`, `SG_NM`, `OVR_STS`
FROM `ACCOUNTABILITY_STATUS_BY_SUBGROUP`
WHERE `YR` = 2021 AND `EN` = 'ALBANY CITY SD'
;

-- 37: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each science assessment? Exclude scores with the value 's'.
SELECT `ASN`, AVG (CAST (`L1_TST` AS FLOAT)) L1, AVG (CAST (`L2_TST` AS FLOAT)) L2, AVG (CAST (`L3_TST` AS FLOAT)) L3, AVG (CAST (`L4_TST` AS FLOAT)) L4
FROM `ANNUAL_EM_SCIENCE`
WHERE `L1_TST` <> 's' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school')
GROUP BY `ASN`
;

-- 38: What are the average public elementary school level 1, level 2, level 3, and level 4 percent tested for each sub group for the Science8 assessment? Exclude scores with the value 's'.
SELECT `SG_NM`, AVG (CAST (`L1_TST` AS FLOAT)) L1, AVG (CAST (`L2_TST` AS FLOAT)) L2, AVG (CAST (`L3_TST` AS FLOAT)) L3, AVG (CAST (`L4_TST` AS FLOAT)) L4
FROM `ANNUAL_EM_SCIENCE`
WHERE `L1_TST` <> 's' AND `ASN` = 'Science8' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school')
GROUP BY `SG_NM`
;

-- 39: How many different subjects are present in the new york state english as a second language achievement test data?
SELECT COUNT (DISTINCT `SBJCT`) SUBJECTCOUNT
FROM `ANNUAL_NYSESLAT`
;

-- 40: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the expanding level on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT `PER_EX`
FROM `ANNUAL_NYSESLAT`
WHERE `SG_NM` = 'Parent Not In Armed Forces' AND `SBJCT` = 'TS_6' AND `EN` = 'JOHANNA PERRIN MIDDLE SCHOOL' AND `YR` = 2021
;

-- 41: What percent of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT `P_EN`, `P_EM`, `P_TR`, `PER_EX`
FROM `ANNUAL_NYSESLAT`
WHERE `SG_NM` = 'Parent Not In Armed Forces' AND `SBJCT` = 'TS_6' AND `EN` = 'JOHANNA PERRIN MIDDLE SCHOOL' AND `YR` = 2021
;

-- 42: For each subject, what is the average percent of students scoring at the entering level on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT `SBJCT`, AVG (CAST (`P_EN` AS FLOAT)) AVGSCORE
FROM `ANNUAL_NYSESLAT`
WHERE `P_EN` <> 's' AND `YR` = 2021 AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school district')
GROUP BY `SBJCT`
;

-- 43: For each subject, what is the average percent of students scoring at the entering level, the emerging level, the transitioning level, the expanding level, or the commanding level, on the new york state english as a second language achievement test in 2021 for students at public schools? Exclude score values of 's'.
SELECT `SBJCT`, AVG (CAST (`P_EN` AS FLOAT)) AVGENT, AVG (CAST (`P_EM` AS FLOAT)) AVGEMER, AVG (CAST (`P_TR` AS FLOAT)) AVGTRAN, AVG (CAST (`PER_EX` AS FLOAT)) AVGEXP, AVG (CAST (`P_COH` AS FLOAT)) AVGCOM
FROM `ANNUAL_NYSESLAT`
WHERE `P_EN` <> 's' AND `YR` = 2021 AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school district')
GROUP BY `SBJCT`
;

-- 44: What is the number of students in the 'parent not in armed forces' subgroup enrolled at JOHANNA PERRIN MIDDLE SCHOOL scored in the entering level, the emerging level, the transitioning level, or the expanding level, on the TS_6 subject on the new york state english as a second language achievement test in 2021?
SELECT `N_EN`, `N_EM`, `N_TR`, `N_EX`
FROM `ANNUAL_NYSESLAT`
WHERE `SG_NM` = 'Parent Not In Armed Forces' AND `SBJCT` = 'TS_6' AND `EN` = 'JOHANNA PERRIN MIDDLE SCHOOL' AND `YR` = 2021
;

-- 45: How many schools are a part of each board of cooperative educational services in 2020? Show the board name and the count of schools.
SELECT `BOCES_NAME`, COUNT (DISTINCT `S_NM`) SCHOOLCOUNT
FROM `BOCES_AND_N/RC`
WHERE `YR` = 2020
GROUP BY `BOCES_NAME`
;

-- 46: How many schools are a part of each county in 2020? Show the county name and the count of schools.
SELECT `CT_NM`, COUNT (DISTINCT `S_NM`) SCHOOLCOUNT
FROM `BOCES_AND_N/RC`
WHERE `YR` = 2020
GROUP BY `CT_NM`
;

-- 47: For each board of cooperative educational services in 2021, show the average federal and state and local expenditures_per_pupil. Include the board name and average expenditures in the result.
SELECT `BOCES_NAME`, AVG (CAST (`PPEFF` AS FLOAT)) AVGFEDEXP, AVG (CAST (`PPESLF` AS FLOAT)) AVGLOCEXP
FROM `BOCES_AND_N/RC` B
JOIN `EPP` E ON `B`.`ENT_CD` = `E`.`ENT_CD` AND `B`.`YR` = `E`.`YR`
WHERE `B`.`YR` = 2021
GROUP BY `BOCES_NAME`
;

-- 48: How many board of cooperative educational services are there?
SELECT COUNT (DISTINCT `BOCES_NAME`) BOCESCOUNT
FROM `BOCES_AND_N/RC`
;

-- 49: Show the names of the board of cooperative educational services and the number of counties, for boards that have more than one county.
SELECT `BOCES_NAME`, COUNT (DISTINCT `CT_NM`) COUNTYCOUNT
FROM `BOCES_AND_N/RC`
GROUP BY `BOCES_NAME`
HAVING COUNT (DISTINCT `CT_NM`) > 1
;

-- 50: Show the number of teachers, number of inexperienced teaches, and percentage of inexperienced teaches at sheridan prep academy in 2021.
SELECT `NTCH`, `NTI`, `PTI`
FROM `ITP`
WHERE `EN` = 'SHERIDAN PREP ACADEMY' AND `YR` = 2021
;

-- 51: What are the entity codes, names and percentage inexperience teachers, of the five public schools with the highest percentage of inexperienced teachers in 2021?
SELECT `I`.`ENT_CD`, `I`.`EN`, `PTI`
FROM `ITP` I
JOIN `IG` G ON `I`.`ENT_CD` = `G`.`ENT_CD`
WHERE `YR` = 2021 AND `G_NM` = 'public school'
ORDER BY `PTI` DESC LIMIT 5
;

-- 52: What is the average percantage of inexperienced teachers for the five school districts with the highest average? Include the district name in the result.
SELECT `DST_NM`, AVG (`PTI`) TEACHCOUNT
FROM `ITP` I
JOIN `BOCES_AND_N/RC` B ON `I`.`ENT_CD` = `B`.`ENT_CD`
GROUP BY `DST_NM`
ORDER BY AVG (`PTI`) DESC LIMIT 5
;

-- 53: What is the average of the total number of teachers and principals in low-poverty schools statewide?
SELECT AVG (`TPL`) PRINCLOW, AVG (`TOT_TCH_LW`) TEACHLOW
FROM `ITP`
;

-- 54: In 2022, How many students in either the male or the female subgroup at Brocton Middle High School attended an out of state, four-year postsecondary institution?
SELECT SUM (CAST (`OUT_4_YR_CNT` AS INT)) STUDENTCOUNT
FROM `PSENRL`
WHERE `SG_NM` IN ('male', 'female') AND `EN` = 'BROCTON MIDDLE HIGH SCHOOL'
;

-- 55: For the 2022 subgroup 'All Students' at Oneida Senior High School, what is the total graduate count, the percent of graduates who enrolled in a new york state public two-year postsecondary institution, and the percent of graduates who enrolled in a new york state public four-year postsecondary institution?
SELECT `PER_NYS_PUB_2_YR`, `PER_NYS_PUB_4_YR`
FROM `PSENRL`
WHERE `YR` = 2022 AND `EN` = 'ONEIDA SENIOR HIGH SCHOOL' AND `SG_NM` = 'All Students'
;

-- 56: What is the name of the public school district that had the most teachers teaching out of certification in 2021?
SELECT `EN`
FROM `TTOC`
WHERE `YR` = 2021 AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school district')
ORDER BY `NOC` DESC LIMIT 1
;

-- 57: In 2021, what was the number and percentage of teachers out of certification at bolton central school?
SELECT `NOC`, `POC`
FROM `TTOC`
WHERE `EN` = 'BOLTON CENTRAL SCHOOL' AND `YR` = 2021
;

-- 58: Show the county name and total number of teachers teaching out of certification in each county.
SELECT `CT_NM`, SUM (`NOC`) OOCCOUNT
FROM `TTOC` C
JOIN `BOCES_AND_N/RC` B ON `C`.`ENT_CD` = `B`.`ENT_CD`
GROUP BY `CT_NM`
;

-- 59: Show the subgroup name, cohort count, the number of students with a valid score, the number of students scoring at levels 1 through 4 for the male and female subgroups at waverly high school in the 2017 cohort.
SELECT `SG_NM`, `CC`, `T_COH`, `L1_CNT`, `L2_CNT`, `L3CNT`, `L4_CNT`
FROM `TCRE`
WHERE `EN` = 'WAVERLY HIGH SCHOOL' AND `COH` = 2017 AND `SG_NM` IN ('female', 'male') AND `SBJCT` = 'MATH'
;

-- 60: What is the name of the public school entity that had the highest percent of level four regents math exam scores in the 2017 student cohort and in the 'all students' sub group? Exclude score percentage values of 's'.
SELECT `EN`
FROM `TCRE`
WHERE `COH` = 2017 AND `SG_NM` = 'All Students' AND `SBJCT` = 'MATH' AND `L4_CHT` <> 's' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school')
ORDER BY CAST (`L4_CHT` AS INT) DESC LIMIT 1
;

-- 61: How many different elementary school math assessment types are there?
SELECT COUNT (DISTINCT `ASN`) ASSESSMENTCOUNT
FROM `ANNUAL_EM_MATH`
;

-- 62: How many  elementary students in the male sub group were given the Science4 assessment in 2021 at FORTS FERRY SCHOOL?
SELECT `TC`
FROM `ANNUAL_EM_SCIENCE`
WHERE `YR` = 2021 AND `SG_NM` = 'male' AND `ASN` = 'Science4' AND `EN` = 'FORTS FERRY SCHOOL'
;

-- 63: What is the name of the public school entity that had the highest percentage of out-of-state four year postsecondary enrollments in 2022? Exclude percantage values of 's'.
SELECT `EN`
FROM `PSENRL`
WHERE `YR` = 2022 AND `SG_NM` = 'All Students' AND `PO4Y` <> 's' AND `ENT_CD` IN (SELECT `ENT_CD`
FROM `IG`
WHERE `G_NM` = 'public school')
ORDER BY CAST (`PO4Y` AS INT) DESC LIMIT 1
;

