-- 1: How many stations are there?
SELECT COUNT (*) AS STATION_COUNT
FROM `STATIONS`
;

-- 2: How many islands are there?
SELECT COUNT (DISTINCT `ISLAND`)
FROM `LOCATIONS`
;

-- 3: How many sites does each island have?
SELECT `ISLAND`, COUNT (DISTINCT `SITE_ID`) AS SITE_COUNT
FROM `LOCATIONS`
GROUP BY `ISLAND`
;

-- 4: How many events have a half meter density count greater than 8?
SELECT COUNT (*) DENSITYCOUNT
FROM `TBL_DENSITY`
WHERE `HALF_METER` > 8
;

-- 5: Get a count of events by station
SELECT `STATION_ID`, COUNT (*) EVENT_COUNT
FROM `EVENTS`
GROUP BY `STATION_ID`
;

-- 6: How many contacts are there from each organization?
SELECT `ORGANIZATION`, COUNT (*) PERSON_COUNT
FROM `CONTACTS_LOOKUP`
GROUP BY `ORGANIZATION`
;

-- 7: Show all of the zip codes for the city of Hilo.
SELECT DISTINCT `ZIP_CODE`
FROM `CONTACTS_LOOKUP`
WHERE `CITY` = 'Hilo'
;

-- 8: Make a list of events that are repeat samples that were verified by Lauren Smith, and that includes the event id, station id, and the start date,.
SELECT `EVENT_ID`, `STATION_ID`, `START_DATE`
FROM `EVENTS`
WHERE `REPEAT_SAMPLE` = 1 AND `VERIFIED_BY` = 'Lauren Smith'
;

-- 9: how many observations were made in the forest bird habitat?
SELECT COUNT (*) OBSCOUNT
FROM `OBSERVATIONS` O
JOIN `SPECIES_LOOKUP` S ON `O`.`SPECIES_ID` = `S`.`SPECIES_ID`
WHERE `HABITAT` = 'Forest Bird'
;

-- 10: Show a count of observations by species habitat
SELECT `HABITAT`, COUNT (*) OBSCOUNT
FROM `SPECIES_LOOKUP` S
JOIN `OBSERVATIONS` O ON `O`.`SPECIES_ID` = `S`.`SPECIES_ID`
GROUP BY `HABITAT`
;

-- 11: Make a list of event ids for events that have more than 7 observations.
SELECT `E`.`EVENT_ID`
FROM `EVENTS` E
JOIN `OBSERVATIONS` O ON `E`.`EVENT_ID` = `O`.`EVENT_ID`
GROUP BY `E`.`EVENT_ID`
HAVING COUNT (*) > 7
;

-- 12: What is the scientific and common name of the three most frequently observed bird species?
SELECT `SCIENTIFIC_NAME`, `COMMON_NAME`
FROM `OBSERVATIONS` O
JOIN `SPECIES_LOOKUP` S ON `O`.`SPECIES_ID` = `S`.`SPECIES_ID`
GROUP BY `SCIENTIFIC_NAME`, `COMMON_NAME`
ORDER BY COUNT (*) DESC LIMIT 3
;

-- 13: What is the most common understory composition and canopy composition combination of events entered by Caitlin Jensen?
SELECT `CANOPY_COMP`, `UNDERSTORY_COMP`
FROM `HABITATS` H
JOIN `EVENTS` E ON `H`.`EVENT_ID` = `E`.`EVENT_ID`
WHERE `ENTERED_BY` = 'caitlin jensen'
GROUP BY `CANOPY_COMP`, `UNDERSTORY_COMP`
ORDER BY COUNT (*) DESC LIMIT 1
;

-- 14: What are the weather conditions (cloud cover, rain, wind, and gusts) for events entered by Cari Squibb and updated by Seth Judge?
SELECT `CLOUD`, `RAIN`, `WIND`, `GUST`
FROM `EVENTS` E
JOIN `EVENT_DETAILS` ED ON `E`.`EVENT_ID` = `ED`.`EVENT_ID`
WHERE `UPDATED_BY` = 'Seth Judge' AND `ENTERED_BY` = 'Cari Squibb'
;

-- 15: How many observations had more than 15 detections?
SELECT COUNT (*) OBSCOUNT
FROM (SELECT `OBSERVATION_ID`
FROM `DETECTIONS` D
GROUP BY `OBSERVATION_ID`
HAVING COUNT (`DETECTION_ID`) > 15) T
;

-- 16: What is the average detection distance for all detections?
SELECT AVG (`DISTANCE`) AVGDIST
FROM `DETECTIONS`
;

-- 17: What is the common name of the species observed and detected from the farthest distance?
SELECT `COMMON_NAME`
FROM `SPECIES_LOOKUP` S
JOIN `OBSERVATIONS` O ON `S`.`SPECIES_ID` = `O`.`SPECIES_ID`
JOIN `DETECTIONS` T ON `T`.`OBSERVATION_ID` = `O`.`OBSERVATION_ID`
ORDER BY `DISTANCE` DESC LIMIT 1
;

-- 18: what are the common names and alternate names for birds of the family Laridae?
SELECT `COMMON_NAME`, `ALTERNATE_NAME`
FROM `SPECIES_LOOKUP` S
JOIN `SPECIES_ALTERNATE_NAME_CROSSREFERENCE` A ON `S`.`SPECIES_ID` = `A`.`SPECIES_ID`
WHERE `FAMILY` = 'laridae'
;

-- 19: what are all of the different sources of species information?
SELECT DISTINCT `SOURCE`
FROM `SPECIES_LOOKUP`
;

-- 20: What is the station name of the station currently located at UTM coordinates X 272454 Y 2141631
SELECT `STATION`
FROM `STATIONS`
JOIN `STATIONS_LOCATION_UTMS` ON `STATIONS`.`STATION_ID` = `STATIONS_LOCATION_UTMS`.`STATION_ID`
WHERE `COORDINATE_X_FINAL` = 272454 AND `COORDINATE_Y_FINAL` = 2141631
;

-- 21: what is Patrick Hart's position and organization?
SELECT `POSITION_TITLE`, `ORGANIZATION`
FROM `CONTACTS_LOOKUP`
WHERE `FIRST_NAME` = 'Patrick' AND `LAST_NAME` = 'Hart'
;

-- 22: What are the names of the sites on each island?
SELECT DISTINCT `ISLAND`, `SITE_NAME`
FROM `LOCATIONS`
JOIN `SITES` ON `LOCATIONS`.`SITE_ID` = `SITES`.`SITE_ID`
;

-- 23: Which island has the location called Northwest Kahuku?
SELECT `ISLAND`
FROM `LOCATIONS`
WHERE `LOCATION_NAME` = 'Northwest Kahuku'
;

-- 24: what are the family, scientific and common names of all of the bird species that occupy Forest Bird habitats?
SELECT DISTINCT `FAMILY`, `SCIENTIFIC_NAME`, `COMMON_NAME`
FROM `SPECIES_LOOKUP`
WHERE `HABITAT` = 'Forest Bird'
;

-- 25: How many station locations are documented using WGS84 and how many are documented using NAD83 datums?
SELECT DISTINCT `DATUM`, COUNT (*) STATIONCOUNT
FROM `STATIONS_LOCATION_UTMS`
WHERE `DATUM` IN ('WGS84', 'NAD83')
GROUP BY `DATUM`
;

-- 26: How many observations were made on days when there were no clouds in the sky?
SELECT COUNT (*) OBS_COUNT
FROM `OBSERVATIONS` OBS
JOIN `EVENT_DETAILS` DET ON `OBS`.`EVENT_ID` = `DET`.`EVENT_ID`
WHERE `CLOUD` = 0
;

-- 27: how many events occurred on the most windy days?
SELECT COUNT (*) WINDY_DAY_COUNT
FROM `EVENT_DETAILS`
WHERE `WIND` IN (SELECT MAX (`WIND`)
FROM `EVENT_DETAILS`)
;

-- 28: How many stations does each island have?
SELECT `ISLAND`, COUNT (*) AS STATION_COUNT
FROM `LOCATIONS` LOC
JOIN `TRANSECTS` TRANS ON `LOC`.`LOCATION_ID` = `TRANS`.`LOCATION_ID`
JOIN `STATIONS` STA ON `TRANS`.`TRANSECT_ID` = `STA`.`TRANSECT_ID`
GROUP BY `ISLAND`
;

-- 29: Which island has the fewest stations, and how many stations does it have?
SELECT `ISLAND`, COUNT (*) AS STATION_COUNT
FROM `LOCATIONS` LOC
JOIN `TRANSECTS` TRANS ON `LOC`.`LOCATION_ID` = `TRANS`.`LOCATION_ID`
JOIN `STATIONS` STA ON `TRANS`.`TRANSECT_ID` = `STA`.`TRANSECT_ID`
GROUP BY `ISLAND`
ORDER BY `STATION_COUNT` ASC LIMIT 1
;

-- 30: List the distinct family and species code of all bird observed during events logged when it was raining (denoted by the value 1).
SELECT DISTINCT `FAMILY`, `SPECIES_CODE`
FROM `SPECIES_LOOKUP` S
JOIN `OBSERVATIONS` O ON `S`.`SPECIES_ID` = `O`.`SPECIES_ID`
JOIN `EVENTS` E ON `O`.`EVENT_ID` = `E`.`EVENT_ID`
JOIN `EVENT_DETAILS` ED ON `E`.`EVENT_ID` = `ED`.`EVENT_ID`
WHERE `RAIN` = 1
;

-- 31: What species has Patrick Hart observed? List all of them by their scientific and common names. Don't include duplicate rows.
SELECT DISTINCT `SCIENTIFIC_NAME`, `COMMON_NAME`
FROM `SPECIES_LOOKUP` SPC
JOIN `OBSERVATIONS` OBS ON `SPC`.`SPECIES_ID` = `OBS`.`SPECIES_ID`
JOIN `EVENT_CONTACTS_CROSSREFERENCE` XCON ON `XCON`.`EVENT_ID` = `OBS`.`EVENT_ID`
JOIN `CONTACTS_LOOKUP` CON ON `XCON`.`CONTACT_ID` = `CON`.`CONTACT_ID`
WHERE `LAST_NAME` = 'Hart' AND `FIRST_NAME` = 'Patrick'
ORDER BY `SCIENTIFIC_NAME`
;

-- 32: At stations 2 and 3, show the station name and common names of each species observed at each station, and include the total count of observations per species.
SELECT `STATION`, `COMMON_NAME`, COUNT (*) NUMOBSERVATIONS
FROM `STATIONS` T_S
JOIN `EVENTS` T_E ON `T_E`.`STATION_ID` = `T_S`.`STATION_ID`
JOIN `OBSERVATIONS` T_O ON `T_O`.`EVENT_ID` = `T_E`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` T_SP ON `T_O`.`SPECIES_ID` = `T_SP`.`SPECIES_ID`
WHERE `STATION` = '2' OR `STATION` = '3'
GROUP BY `STATION`, `COMMON_NAME`
ORDER BY `STATION`
;

-- 33: How many events does each station have? Show them in the descending order of event counts. Include the station name and the event count in the output.
SELECT `STATION`, COUNT (*) AS EVENT_COUNT
FROM `STATIONS` TS
JOIN `EVENTS` TE ON `TS`.`STATION_ID` = `TE`.`STATION_ID`
GROUP BY `TS`.`STATION`
ORDER BY `EVENT_COUNT` DESC
;

-- 34: What is the northmost station's station name and position?
SELECT `LATITUDE_FINAL`, `LONGITUDE_FINAL`, `STATION`
FROM `STATIONS`
ORDER BY `LATITUDE_FINAL` DESC LIMIT 1
;

-- 35: How many stations has the Hawaii Amakihi been observed at?
SELECT COUNT (DISTINCT `STATIONS`.`STATION_ID`) AS STATION_COUNT
FROM `STATIONS`
JOIN `EVENTS` ON `STATIONS`.`STATION_ID` = `EVENTS`.`STATION_ID`
JOIN `OBSERVATIONS` ON `OBSERVATIONS`.`EVENT_ID` = `EVENTS`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` ON `SPECIES_LOOKUP`.`SPECIES_ID` = `OBSERVATIONS`.`SPECIES_ID`
WHERE `COMMON_NAME` = 'Hawaii Amakihi'
;

-- 36: What percent of stations has the bird with the common name Hawaii Amakihi been observed at?
SELECT 100 * (SUM (`SIGHTED`) / COUNT (DISTINCT `STATION_ID`)) AS PERC_STATIONS
FROM (SELECT DISTINCT `STATIONS`.`STATION_ID`, CASE WHEN `SPECIES_LOOKUP`.`COMMON_NAME` = 'Hawaii Amakihi' THEN 1.0 ELSE 0.0 END AS SIGHTED
FROM `STATIONS`
JOIN `EVENTS` ON `STATIONS`.`STATION_ID` = `EVENTS`.`STATION_ID`
JOIN `OBSERVATIONS` ON `OBSERVATIONS`.`EVENT_ID` = `EVENTS`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` ON `SPECIES_LOOKUP`.`SPECIES_ID` = `OBSERVATIONS`.`SPECIES_ID`) SIGHTINGS
;

-- 37: Show the first name, last name, and number of logged events for members of the national park service.
SELECT `LAST_NAME`, `FIRST_NAME`, COUNT (*) NUM_EVENTS
FROM `CONTACTS_LOOKUP` TLC
JOIN `EVENT_CONTACTS_CROSSREFERENCE` XREC ON `TLC`.`CONTACT_ID` = `XREC`.`CONTACT_ID`
WHERE `ORGANIZATION` = 'National Park Service'
GROUP BY `LAST_NAME`, `FIRST_NAME`, `ORGANIZATION`
ORDER BY `LAST_NAME` DESC
;

-- 38: What is the average canopy height of each species' habitats? Include the common name and scientfic name of each species. Ensure the average has decimal precision.
SELECT `SCIENTIFIC_NAME`, `COMMON_NAME`, AVG (CAST (`CANOPY_HEIGHT` AS FLOAT)) AS AVG_CANOPY_HEIGHT
FROM `HABITATS` HAB
JOIN `EVENTS` EV ON `HAB`.`EVENT_ID` = `EV`.`EVENT_ID`
JOIN `OBSERVATIONS` OBS ON `OBS`.`EVENT_ID` = `EV`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` SPEC ON `SPEC`.`SPECIES_ID` = `OBS`.`SPECIES_ID`
GROUP BY `SCIENTIFIC_NAME`, `COMMON_NAME`
ORDER BY `SCIENTIFIC_NAME`
;

-- 39: Create a list of species sightings at each station. Include the island, site name, location name, transect and transect type, station, the station's latitude, the event id of the observations, the last names of those who observed as well as their notes, the family, scientific name, common name, and alternate name of each bird observed.
SELECT `ISLAND`, `SITE_NAME`, `LOCATION_NAME`, `TRANSECT`, `TRANSECT_TYPE`, `STATION`, `LATITUDE_FINAL`, `TE`.`EVENT_ID`, `LAST_NAME`, `EVENT_NOTES`, `FAMILY`, `SCIENTIFIC_NAME`, `COMMON_NAME`, `ALTERNATE_NAME`
FROM `LOCATIONS` TL
JOIN `SITES` TS ON `TL`.`SITE_ID` = `TS`.`SITE_ID`
JOIN `TRANSECTS` TR ON `TR`.`LOCATION_ID` = `TL`.`LOCATION_ID`
JOIN `STATIONS` ST ON `ST`.`TRANSECT_ID` = `TR`.`TRANSECT_ID`
JOIN `EVENTS` TE ON `TE`.`STATION_ID` = `ST`.`STATION_ID`
JOIN `EVENT_CONTACTS_CROSSREFERENCE` EC ON `EC`.`EVENT_ID` = `TE`.`EVENT_ID`
JOIN `CONTACTS_LOOKUP` CON ON `EC`.`CONTACT_ID` = `CON`.`CONTACT_ID`
JOIN `OBSERVATIONS` OBS ON `TE`.`EVENT_ID` = `OBS`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` SPC ON `OBS`.`SPECIES_ID` = `SPC`.`SPECIES_ID`
JOIN `SPECIES_ALTERNATE_NAME_CROSSREFERENCE` SPC_ALT ON `SPC`.`SPECIES_ID` = `SPC_ALT`.`SPECIES_ID`
;

-- 40: Which island has the most sightings of the bird with the common name Pacific Kingfisher?
SELECT `ISLAND`, COUNT (*) AS KINGFISHER_COUNT
FROM `LOCATIONS` TL
JOIN `TRANSECTS` TR ON `TR`.`LOCATION_ID` = `TL`.`LOCATION_ID`
JOIN `STATIONS` ST ON `ST`.`TRANSECT_ID` = `TR`.`TRANSECT_ID`
JOIN `EVENTS` TE ON `TE`.`STATION_ID` = `ST`.`STATION_ID`
JOIN `EVENT_CONTACTS_CROSSREFERENCE` EC ON `EC`.`EVENT_ID` = `TE`.`EVENT_ID`
JOIN `CONTACTS_LOOKUP` CON ON `EC`.`CONTACT_ID` = `CON`.`CONTACT_ID`
JOIN `OBSERVATIONS` OBS ON `TE`.`EVENT_ID` = `OBS`.`EVENT_ID`
JOIN `SPECIES_LOOKUP` SPC ON `OBS`.`SPECIES_ID` = `SPC`.`SPECIES_ID`
WHERE `COMMON_NAME` = 'Pacific Kingfisher'
GROUP BY `ISLAND`
ORDER BY `KINGFISHER_COUNT` LIMIT 1
;

