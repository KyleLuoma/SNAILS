-- 1: How many different internal reconciliation types are there?
SELECT COUNT (DISTINCT `RECONTYPE`) NUMTYPES
FROM `INT_REC_TABLE`
;

-- 2: Show the payee names, zip, city, street, country, and states for the payees with the user department named 'General'
SELECT `PYENM`, `PEEZIP`, `PYECITY`, `PAYEESTREE`, `P_COUNTRY`, `PYEST`
FROM `DEPTS_TBL` DEPARTMENTS
JOIN `PMT_RESULTS_TBL` PAYMENTRESULTSTABLE ON `DEPARTMENTS`.`CD` = `PAYMENTRESULTSTABLE`.`DEPTM`
WHERE `DEPARTMENTS`.`NM` = 'General'
;

-- 3: What are the account numbers that have checks for payment with more than one line? Include only one entry per account number.
SELECT DISTINCT `ACCTNUM`
FROM `CHKS_FOR_PMT_TBL` O
JOIN `CHKS_FOR_PMT_ROWS` ON `O`.`CHKKEY` = `CHKS_FOR_PMT_ROWS`.`CHKKEY`
GROUP BY `ACCTNUM`, `O`.`CHKKEY`
HAVING COUNT (*) > 1
;

-- 4: What are the witholding tax deduction amounts and percents for checks for payment associated with the account with account number '100-3443-7867'?
SELECT `DEDCTN`, `WTHLDG_TAX_DED_PCT`
FROM `CHKS_FOR_PMT_TBL`
WHERE `ACCTNUM` = '100-3443-7867'
;

-- 5: What is the card code, card name, address, and functional currency transfer amount for the incoming payments created in the year 2012 where the document summary currency code is 'EUR'
SELECT `CRDCODE`, `CRDNM`, `ADDR`, `TRANS_AMT_FC`
FROM `IN_PAYMENT_TBL`
WHERE DATE (`CREAT_DT`) >= DATE ('2012-01-01' AND DATE (`CREAT_DT`) <= DATE ('2012-12-31')) AND `DOCCURR` = 'EUR'
;

-- 6: What is the Withholding tax posted, account number, and functional currency sum for the incoming checks with the country code 'CA'
SELECT `WTHLDG_TAX_PSTD`, `ACCTNUM`, `CHECKSUMFC`
FROM `IN_PAYMENT_TBL`
JOIN `IN_PAY_CHECKS` ON `IN_PAYMENT_TBL`.`DOCNUM` = `IN_PAY_CHECKS`.`DOCNUM`
WHERE `COUNTRYCOD` = 'CA'
;

-- 7: How many incoming invoices document an applied value added tax of more than 700?
SELECT COUNT (*) INVOICECOUNT
FROM `IN_PAY_INV_TABLE`
WHERE `VATAPPLIED` > 700
;

-- 8: For incoming payments processed with credit vouchers, show the average of the sums of the first partial payments.
SELECT AVG (`FIRSTSUM`) FIRSTPMTAVG
FROM `IN_PAYMENT_TBL`
JOIN `IN_PAY_CRED_VOUCHERS` ON `IN_PAYMENT_TBL`.`DOCNUM` = `IN_PAY_CRED_VOUCHERS`.`DOCNUM`
;

-- 9: List the receipt number, card payment internal ID, and card account code for the credit card deposit deposited on 2012-01-31.
SELECT `RCPT_NUM_ABS`, `DEPNUM`, `CRDCODE`
FROM `CC_MGMT_TBL`
WHERE DATE (`DEPOSDATE`) = '2012-01-31'
;

-- 10: For the payment term with the term group code 'Net30', show the number of additional days, number of installments, and whether or not value added tax is applied on the first installment.
SELECT `EXTRDYS`, `INSTNUM`, `VATFIRST`
FROM `PYMNT_TERMS_TBL`
WHERE `PYMNTGROUP` = 'Net30'
;

