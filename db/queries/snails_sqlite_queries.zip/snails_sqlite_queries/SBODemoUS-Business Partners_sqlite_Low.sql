-- 1: Show the group name and count of business partners in each card group
SELECT `GRPNAME`, COUNT (*) PARTNERCOUNT
FROM `CRD_GRPS`
JOIN `BUS_PART_TABLE` ON `CRD_GRPS`.`GROUP_CD` = `BUS_PART_TABLE`.`GROUP_CD`
GROUP BY `GRPNAME`
;

-- 2: Make a contact roster that includes the name, address, cell phone number, and email address of all persons currently in either a CEO or COO position.
SELECT `NM`, `ADDR`, `CELLOLAR`, `EML_ADDR`
FROM `CNTCT_PRSNS_TBL`
WHERE `POSTN` = 'CEO' OR `POSTN` = 'COO'
;

-- 3: What is the commission rate of the sales employee named Bill Levine?
SELECT `COMMSSN`
FROM `SALES_EMP_TBL`
WHERE `SLPNAME` = 'Bill Levine'
;

-- 4: What are the names of sales employees in the high commission group?
SELECT `SLPNAME`
FROM `SALES_EMP_TBL`
JOIN `COMM_GRPS` ON `SALES_EMP_TBL`.`GROUP_CD` = `COMM_GRPS`.`GROUP_CD`
WHERE `GRPNAME` = 'High Commission'
;

-- 5: What are the names, mobile phone numbers, and email addresses of sales employees in the high commission group?
SELECT `SLPNAME`, `MOBL`, `EML`
FROM `SALES_EMP_TBL`
JOIN `COMM_GRPS` ON `SALES_EMP_TBL`.`GROUP_CD` = `COMM_GRPS`.`GROUP_CD`
WHERE `GRPNAME` = 'High Commission'
;

-- 6: Display the payment code and tax code for current business partners whos closing date procedure number is lower than 35
SELECT `PYMCODE`, `TXCODE`
FROM `BUS_PART_TABLE`
JOIN `BUS_PART_ADDRS` ON `BUS_PART_TABLE`.`CRDCODE` = `BUS_PART_ADDRS`.`CRDCODE`
WHERE `CLSNG_DT_PROC_NUM` < 35
;

-- 7: List the activity number, contact time and date, and the details of all activities created in the year 2021
SELECT `CLGCODE`, `CNTCTDATE`, `CNTCTTIME`, `DTLS`
FROM `ACTVTS_TBL`
WHERE DATE (`CREAT_DT`) >= DATE ('2021-01-01' AND DATE (`CREAT_DT`) <= DATE ('2021-12-31'))
;

-- 8: Show the bank details, to include bank code, country, account number, branch, and city, for the business partner with the card name Microchips
SELECT `BP_BNK_ACC`.`BNKCODE`, `BP_BNK_ACC`.`CNTRY`, `ACCT`, `BRNCH`, `BP_BNK_ACC`.`CTY`
FROM `BUS_PART_TABLE`
JOIN `BP_BNK_ACC` ON `BUS_PART_TABLE`.`CRDCODE` = `BUS_PART_TABLE`.`CRDCODE`
WHERE `CRDNM` = 'Microchips'
;

-- 9: what is the account balance of the business partner with the payment method code 'Incoming BT' and a currency type that is either 'EUR' or 'CAN'
SELECT `BAL`
FROM `BUS_PART_TABLE`
WHERE `CURR` IN ('EUR', 'CAN') AND `BUS_PART_TABLE`.`PYMCODE` = 'Incoming BT'
;

-- 10: What is the email address and federal tax ID of the target with the position of CIO that is of target type C?
SELECT `E_MAIL`, `LICTRADNUM`
FROM `TRGT_GRP_DTL`
JOIN `TRGT_GRP_TBL` ON `TRGT_GRP_DTL`.`TGTCODE` = `TRGT_GRP_TBL`.`TGTCODE`
WHERE `POSTN` = 'CIO' AND `TGTTYPE` = 'C'
;

