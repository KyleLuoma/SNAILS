-- 1: Show the account name and number of journal entries for the general ledger account with code '_SYS00000000002'.
SELECT `ACCTNAME`, COUNT (*) ENTRYCOUNT
FROM `GL_ACCTS_TBL` O
JOIN `JRNL_ENTRY_ROWS` J ON `O`.`ACCTCODE` = `J`.`ACCT`
WHERE `ACCT` = '_SYS00000000002'
GROUP BY `ACCTNAME`
;

-- 2: What is the sum of journal entry debits and sum of journal entry credits due in 2021?
SELECT SUM (`DBT`) DEBITSUM, SUM (`CRDT`) CREDITSUM
FROM `JRNL_ENTRY_ROWS`
WHERE DATE (`DUEDT`) >= DATE ('2021-01-01' AND DATE (`DUEDT`) <= DATE ('2021-12-31'))
;

-- 3: Show the account name, the average monthly budget debit, and average monthly budget credit totals for general ledger accounts with the words 'Travel Expense' in their account name.
SELECT `ACCTNAME`, AVG (`DEBLTOTAL`) AS AVGDEB, AVG (`CREDLTOTAL`) AS AVGCRED
FROM `GL_ACCTS_TBL`
JOIN `BGT_ROWS` ON `GL_ACCTS_TBL`.`ACCTCODE` = `BGT_ROWS`.`ACCTCODE`
WHERE `ACCTNAME` LIKE '%Travel Expense%'
GROUP BY `ACCTNAME`
;

-- 4: Show the account name and current total balance of accounts with the category name cash
SELECT `ACCTNAME`, `CURRTOTAL`
FROM `GL_ACCTS_TBL`
JOIN `ACCT_CAT_TBL` ON `GL_ACCTS_TBL`.`CTGRY` = `ACCT_CAT_TBL`.`ABSID`
WHERE `ACCT_CAT_TBL`.`NM` = 'cash'
;

-- 5: For all rows associated with the value added tax transactions that have source object type 18, show the Tax Code, value added tax percent, and the value added tax sum.
SELECT `TXCODE`, `VATPERCENT`, `VATSUM`
FROM `VAT_TRXNS`
JOIN `TX1` ON `VAT_TRXNS`.`ABSENTRY` = `TX1`.`ABSENTRY`
WHERE `SRCOBJABS` = 18
;

-- 6: What year had the highest rate for currency type 'CAN' from data source I?
SELECT STRFTIME ('%Y', `RATEDT`) HIGHYEAR
FROM `CPI_FC_RTS`
WHERE `DATASRC` = 'I'
ORDER BY `RAT` DESC LIMIT 1
;

-- 7: Get a count of recurring postings by year of the next execution
SELECT STRFTIME ('%Y', `NEXTDEU`) NEXTYEAR, COUNT (*) NUMPOSTINGS
FROM `REC_POSTINGS`
GROUP BY STRFTIME ('%Y', `NEXTDEU`)
;

-- 8: Show the names of the financial report categories that have father number 10
SELECT `NM`
FROM `FIN_RPT_CATS`
WHERE `FATHERNUM` = 10
;

-- 9: show the report category name and the three different calculation methods for extended category f financial reports with a cash flow line item ids greater than 30
SELECT `NM`, `CALCMETHOD`, `CALMTHD2`, `CALMTHD3`
FROM `EXTND_CTGRY_FR_FNCL_RPTNG`
JOIN `FIN_RPT_CATS` ON `EXTND_CTGRY_FR_FNCL_RPTNG`.`CATID` = `FIN_RPT_CATS`.`CATID`
WHERE `CSH_FLW_LN_ITM_ID` > 30
;

-- 10: What is the project code and name of the projects valid after 2020?
SELECT `PRJCODE`, `PRJNAME`
FROM `PROJ_CODES`
WHERE DATE (`VLDFROM`) > DATE ('2020-12-31')
;

