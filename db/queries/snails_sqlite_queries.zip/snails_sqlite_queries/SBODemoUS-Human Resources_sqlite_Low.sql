-- 1: What are the first and last names of employees on the Sales team?
SELECT `LSTNAME`, `FIRSTNM`
FROM `EMPL_TABLE` EMPLOYEES
JOIN `TM_MBR_TBL` TEAMMEMBERS ON `EMPLOYEES`.`EMPID` = `TEAMMEMBERS`.`EMPID`
JOIN `EMPL_TEAMS` EMPLTEAMS ON `TEAMMEMBERS`.`TMID` = `EMPLTEAMS`.`TMID`
WHERE `EMPLTEAMS`.`NM` = 'Sales'
;

-- 2: Get a list of all of the holiday start and end dates and remarks for holidays in 2014.
SELECT `STRDATE`, `ENDDT`, `ENTR_RMARKS`
FROM `HLDY_DATES`
WHERE `STRDATE` >= '20140101 00:00:00.000' AND `ENDDT` <= '20141231 23:59:59.000'
;

-- 3: What is the average salary of employees on the purchasing team?
SELECT AVG (`SAL`) AS AVGSALARY
FROM `EMPL_TABLE`
JOIN `TM_MBR_TBL` ON `EMPL_TABLE`.`EMPID` = `TM_MBR_TBL`.`EMPID`
JOIN `EMPL_TEAMS` ON `EMPL_TEAMS`.`TMID` = `TM_MBR_TBL`.`TMID`
WHERE `EMPL_TEAMS`.`NM` = 'Purchasing'
;

-- 4: What is the office phone number, mobile phone number, pager number, and home phone number of the employee named George Keeng?
SELECT `OFFICETEL`, `MBIL`, `PGER`, `HOMETEL`
FROM `EMPL_TABLE`
WHERE `LSTNAME` = 'Keeng' AND `FIRSTNM` = 'George'
;

-- 5: What is the first and last name of the spouse of employee Maria Bridi?
SELECT `FNAMESP`, `SURNAMESP`
FROM `EMPL_TABLE`
WHERE `LSTNAME` = 'Bridi' AND `FIRSTNM` = 'Maria'
;

-- 6: Show the last name, education status, and number of children for employees of type Technician
SELECT `LSTNAME`, `STATUSOFE`, `NCHILDREN`
FROM `EMPL_TABLE`
JOIN `EMP_TYPES` ON `EMP_TYPES`.`TYPID` = `EMPL_TABLE`.`TPE`
WHERE `EMP_TYPES`.`NM` = 'Technician'
;

-- 7: Show the type ID and name of each employee type
SELECT `TYPID`, `NM`
FROM `EMP_TYPES`
;

-- 8: Make an employee health insurance list that includes their employee ID, last name,  insurance company name, insurance code, and type of insurance.
SELECT `EMPID`, `LSTNAME`, `HEAINSNAME`, `HEAINSCODE`, `HEAINSTYPE`
FROM `EMPL_TABLE`
;

-- 9: What is the job title code of the employee with the last name  Chan?
SELECT `JTCODE`
FROM `EMPL_TABLE`
WHERE `LSTNAME` = 'Chan'
;

-- 10: What are the average vacation days in the current year for employees on the sales team?
SELECT AVG (`VACCURYEAR`)
FROM `EMPL_TABLE` EMPLOYEES
JOIN `TM_MBR_TBL` TEAMMEMBERS ON `EMPLOYEES`.`EMPID` = `TEAMMEMBERS`.`EMPID`
JOIN `EMPL_TEAMS` EMPLTEAMS ON `TEAMMEMBERS`.`TMID` = `EMPLTEAMS`.`TMID`
WHERE `EMPLTEAMS`.`NM` = 'Sales'
;

-- 11: Show the team ID of the team that has the employee with the personal fiscal ID 51B.
SELECT `TMID`
FROM `TM_MBR_TBL`
JOIN `EMPL_TABLE` ON `TM_MBR_TBL`.`EMPID` = `EMPL_TABLE`.`EMPID`
WHERE `PRSNL_FISCAL_ID` = '51B'
;

-- 12: Show the municipality key, tax class, and income tax liability for all of the employees of type accountant.
SELECT `MUNKEY`, `TXCLSS`, `INTAXLIABI`
FROM `EMPL_TABLE`
JOIN `EMP_TYPES` ON `EMPL_TABLE`.`TPE` = `EMP_TYPES`.`TYPID`
WHERE `EMP_TYPES`.`NM` = 'Accountant'
;

-- 13: What are the role IDs of employees whos' salaries are less than 5000?
SELECT `RLID`
FROM `EMPL_ROLES_TBL`
JOIN `EMPL_TABLE` ON `EMPL_ROLES_TBL`.`EMPID` = `EMPL_TABLE`.`EMPID`
WHERE `SAL` < 5000
;

-- 14: Show the date of birth, country of birth, home city, home county, and home country for the employees with the job title of accountant
SELECT `BRTHDT`, `BRTHCOUNTR`, `HMCITY`, `HMCNTY`, `HOMECOUNTR`
FROM `EMPL_TABLE`
WHERE `JBTITLE` = 'Accountant'
;

-- 15: Show the professional status, citizenship and passport number  of the employee whos last name is Buyer
SELECT `STATUSOFP`, `CITIZENSHP`, `PASSNO`
FROM `EMPL_TABLE`
WHERE `LSTNAME` = 'Buyer'
;

-- 16: Show the first name, last name, home city, and work city of employees whos costs are higher than 4000.
SELECT `FIRSTNM`, `LSTNAME`, `HMCITY`, `WRKCITY`
FROM `EMPL_TABLE`
WHERE `EMPLCOST` > 4000
;

-- 17: Show the municipality key, home city, home phone number, work city and office phone number of employees on the sales team.
SELECT `MUNKEY`, `HMCITY`, `HOMETEL`, `WRKCITY`, `OFFICETEL`
FROM `EMPL_TABLE` EMPLOYEES
JOIN `TM_MBR_TBL` TEAMMEMBERS ON `EMPLOYEES`.`EMPID` = `TEAMMEMBERS`.`EMPID`
JOIN `EMPL_TEAMS` EMPLTEAMS ON `TEAMMEMBERS`.`TMID` = `EMPLTEAMS`.`TMID`
WHERE `EMPLTEAMS`.`NM` = 'Sales'
;

-- 18: Show the professional status and educational statuses as well as the home and work street numbers of employees on the purchasing team.
SELECT `STATUSOFP`, `STATUSOFE`, `STREETNOW`, `STREETNOH`
FROM `EMPL_TABLE` EMPLOYEES
JOIN `TM_MBR_TBL` TEAMMEMBERS ON `EMPLOYEES`.`EMPID` = `TEAMMEMBERS`.`EMPID`
JOIN `EMPL_TEAMS` EMPLTEAMS ON `TEAMMEMBERS`.`TMID` = `EMPLTEAMS`.`TMID`
WHERE `EMPLTEAMS`.`NM` = 'Purchasing'
;

-- 19: What is the payment method, exemption amount currency, and additional amount currency, for the employee who's tax office name is baltimore?
SELECT `PYMMETH`, `EXEMPTCURR`, `ADDICURR`
FROM `EMPL_TABLE`
WHERE `TAXONAME` = 'baltimore'
;

-- 20: What is the marital status, home street, home block, home zip code, and home state of the employee with the last name Bridi?
SELECT `MARTSTATUS`, `HMESTRT`, `HMBLK`, `HMZIP`, `HMSTATE`
FROM `EMPL_TABLE`
WHERE `LSTNAME` = 'Bridi'
;

