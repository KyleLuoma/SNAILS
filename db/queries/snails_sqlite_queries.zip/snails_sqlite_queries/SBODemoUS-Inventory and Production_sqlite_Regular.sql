-- 1: How many items with the name 'USB Flashdrive 128GB' are on hand, committed, and on order?
SELECT `ONHAND`, `ISCOMMITED`, `ONORDER`
FROM `ITEMS_TABLE`
WHERE `ITEMNAME` = 'USB Flashdrive 128GB'
;

-- 2: What is the number of commited items, the price-per-item, and the total price of the commited items for the item called 'Memory Chip?
SELECT `ISCOMMITED`, `PRICE`, `ISCOMMITED` * `PRICE` AS TOTALPRICE
FROM `ITEMS_TABLE`
JOIN `ITEMS_PRICES` ON `ITEMS_TABLE`.`ITEMCODE` = `ITEMS_PRICES`.`ITEMCODE`
WHERE `ITEMNAME` = 'Memory Chip'
;

-- 3: For the vendor with vendor code V1010, show item names, consignment numbers, and last purchase price for items where the vendor is preferred.
SELECT `ITEMNAME`, `CONSIGNMENT_GOODS_WHSE`, `LAST_PURCHASE_PRICE`
FROM `ITEMS_MULTIPLE_PREFERRED_VENDORS`
JOIN `ITEMS_TABLE` ON `ITEMS_MULTIPLE_PREFERRED_VENDORS`.`ITEMCODE` = `ITEMS_TABLE`.`ITEMCODE`
WHERE `VENDORCODE` = 'V1010'
;

-- 4: For the item named 'Printer Paper A4 White', show the package dimensions including height 1, width 1, length 1, and volume, for the packaging that holds a quantity of 24.
SELECT `HEIGHT1`, `WIDTH_1`, `LENGTH1`, `VOLUME`
FROM `PACKAGE_IN_ITEMS_TABLE`
JOIN `ITEMS_TABLE` ON `PACKAGE_IN_ITEMS_TABLE`.`ITEMCODE` = `ITEMS_TABLE`.`ITEMCODE`
WHERE `ITEMNAME` = 'Printer Paper A4 White' AND `QUANTITY_PER_PACKAGING_UOM` = 24
;

-- 5: What is the useful life, remaining life, and remaining day parameters for the item that uses depreciation area 'GAAP'?
SELECT `USEFULLIFE`, `REMAINLIFE`, `REMAINDAYS`
FROM `ASSET_ITEM_DEPRECIATION_PARAMS`
WHERE `DEPRECIATION_AREA` = 'GAAP'
;

-- 6: What is the volume of the box package type?
SELECT `VOLUME`
FROM `PACKAGE_TYPES`
WHERE `PACKAGE_TYPE` = 'Box'
;

-- 7: What are the barcodes for the item named 'Printer Paper A4 White' with unit of measurement entries that are either 3 or 4?
SELECT `BAR_CODE_CODE`
FROM `ITEMS_TABLE`
JOIN `BAR_CODE_MASTER_DATA` ON `ITEMS_TABLE`.`ITEMCODE` = `BAR_CODE_MASTER_DATA`.`ITEMCODE`
WHERE `ITEMNAME` = 'Printer Paper A4 White' AND `UNIT_OF_MEASURE_ENTRY` IN (3, 4)
;

-- 8: Show the display names, data source, and updated date of bin field configurations that are activated (activated code = 'Y')
SELECT `DISPLAYED_NAME`, `DATASOURCE`, `UPDATEDATE`
FROM `BIN_FIELD_CONFIGURATION`
WHERE `ACTIVATED` = 'Y'
;

-- 9: Display a count of items for each item group. Include the item group name and count of items in the result.
SELECT `ITEMS_GROUP_NAME`, COUNT (*) ITMCT
FROM `ITEMS_TABLE`
JOIN `ITEM_GROUPS_TABLE` ON `ITEMS_TABLE`.`ITEM_GROUP_CODE` = `ITEM_GROUPS_TABLE`.`ITEM_GROUP_CODE`
GROUP BY `ITEMS_GROUP_NAME`
;

-- 10: What is the average volume of items in the 'Items' Item group?
SELECT AVG (`VOLUME`) AVGVOLUME
FROM `ITEMS_TABLE`
JOIN `ITEM_GROUPS_TABLE` ON `ITEMS_TABLE`.`ITEM_GROUP_CODE` = `ITEM_GROUPS_TABLE`.`ITEM_GROUP_CODE`
JOIN `PACKAGE_IN_ITEMS_TABLE` ON `ITEMS_TABLE`.`ITEMCODE` = `PACKAGE_IN_ITEMS_TABLE`.`ITEMCODE`
WHERE `ITEMS_GROUP_NAME` = 'Items'
;

