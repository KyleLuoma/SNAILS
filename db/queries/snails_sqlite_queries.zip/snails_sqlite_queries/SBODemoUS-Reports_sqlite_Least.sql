-- 1: Show the parameter names and parameter parameters for the parameters with the description 'Electronic documents'
SELECT `PNAME`, `PRPM`
FROM `OECM`
JOIN `ECM1` ON `OECM`.`CD` = `ECM1`.`CD`
WHERE `DSCR` = 'Electronic documents'
;

-- 2: Get the field and object type xpaths for the mapping determinations associated with parameters with the description 'PEPPOL'.
SELECT `OXP`, `FXP`
FROM `ECM4`
JOIN `OECM` ON `ECM4`.`CD` = `OECM`.`CD`
WHERE `DSCR` = 'PEPPOL'
;

-- 3: How many queries are there in each category?
SELECT `QCTG`, COUNT (*) QCOUNT
FROM `OUQR`
GROUP BY `QCTG`
;

-- 4: Display the group description, log instance, the updated date, and the created date of the query group with the code 'Group4'
SELECT `AGN`, `LGINST`, `U_DT`, `CRTDT`
FROM `OQAG`
WHERE `AGC` = 'Group4'
;

-- 5: What is the widest document width for documents with a grid size of 10?
SELECT `WD`
FROM `RDOC`
WHERE `G_SIZE` = 10
ORDER BY `WD` DESC LIMIT 1
;

-- 6: What are the type codes and screen fonts for documents that use the email font 'Tahoma'?
SELECT `TY_CD`, `S_FNT`
FROM `RDOC`
WHERE `E_FT` = 'Tahoma'
;

-- 7: Show the document code, and the document type code of the document types with 'Service Call' in the type name
SELECT `D_CD`, `CD`
FROM `RDOC`
JOIN `RTYP` ON `RDOC`.`D_CD` = `RTYP`.`DEFLT_REP`
WHERE `NM` LIKE '%Service Call%'
;

-- 8: Show the document code and document name name, and count of reporting elements for each document with the type code 'WTR1'
SELECT `RDOC`.`D_CD`, `DC_NM`, COUNT (*) ELMTCT
FROM `RDOC`
JOIN `RITM` ON `RDOC`.`D_CD` = `RITM`.`D_CD`
WHERE `TY_CD` = 'WTR1'
GROUP BY `RDOC`.`D_CD`, `DC_NM`
;

-- 9: Show the Action for extension error, and the number of repetetive areas for documents that require conversion font for email (indicated by 'Y' value).
SELECT `EOE`, `NRA`
FROM `RDOC`
WHERE `SIE` = 'Y'
;

-- 10: What are the background, foreground, bold, and border red / green / blue values for the reporting elements with a height less than 5 and greater than 0?
SELECT `BGRD`, `BGGN`, `BGBLE`, `FGRD`, `FGG`, `FGBLUE`, `MKRD`, `MKRB`, `MKGRN`, `BRD`, `B_BL`, `B_GRN`
FROM `RITM`
WHERE `HT` < 5 AND `HT` > 0
;

