-- 1: Show the average potential max sales opportunity amount in local currency for each card group
SELECT `CD_G`, AVG (`MX_SM_L`) AVGMAX
FROM `OOPR`
GROUP BY `CD_G`
;

-- 2: What is the percent profit, gross profit total (local), gross profit total (system) for sales opportunities with the status 'W'?
SELECT `PCT_PF`, `SPL`, `SPS`
FROM `OOPR`
WHERE `STAT` = 'W'
;

-- 3: For each sales opportunity, show sequence number and, carde code, the average percentage rate of all the rows associated with the opportunity
SELECT `OOPR`.`OP_ID`, `CRD_C`, AVG (`CPRCNT`) AVGPERC
FROM `OOPR`
JOIN `OPR1` ON `OOPR`.`OP_ID` = `OPR1`.`OP_ID`
GROUP BY `OOPR`.`OP_ID`, `CRD_C`
;

-- 4: For row-level sales opportunity data, show the weighted amount in both system and local currency for rows with the close date occuring in 2014.
SELECT `WSL`, `WSS`
FROM `OPR1`
WHERE DATE (`CL_DT`) >= DATE ('2014-01-01' AND DATE (`CL_DT`) <= DATE ('2014-12-31'))
;

-- 5: Show the cost center code, name, balance, and dimension code for cost centers that are active (Y value) and valid in 2021.
SELECT `PRCD`, `PNM`, `BAL`, `D_SRC`
FROM `OPRC`
WHERE `ACTV` = 'Y' AND DATE (`VF`) >= DATE ('2021-01-01' AND DATE (`VF`) <= DATE ('2021-12-31'))
;

-- 6: For each card associated with a sales opportunity, Show the carde name, the sum of the real total amount (both local and system), the sum of the real closing gross profit (local and system), and the average closing percentage.
SELECT `CD_NM`, SUM (`RSL`) RSL, SUM (`RSS`) RSS, SUM (`RPS`) REALPROFSYS, SUM (`RPL`) REALPROFLOC, AVG (`CLOPRCNT`)
FROM `OOPR`
GROUP BY `CD_NM`
;

-- 7: What are the open and close dates for sales opportunity rows that have a closing percentage of six or less?
SELECT `OP_D`, `CL_DT`
FROM `OPR1`
WHERE `CPRCNT` <= 6
;

-- 8: Show the newest sales opportunity start date for each opportunity status code
SELECT `STAT`, MAX (`OP_D`) MAXDATE
FROM `OOPR`
GROUP BY `STAT`
;

-- 9: What is the dimension code of the cost center named 'General Center 3'?
SELECT `DM_CD`
FROM `OPRC`
WHERE `PNM` = 'General Center 3'
;

-- 10: Show the sales opportunity average gross profit in local currency by year created
SELECT STRFTIME ('%Y', `CRTDT`) YEARCREATED, AVG (`SPL`) AVGLOCPROFIT
FROM `OOPR`
GROUP BY STRFTIME ('%Y', `CRTDT`)
;

