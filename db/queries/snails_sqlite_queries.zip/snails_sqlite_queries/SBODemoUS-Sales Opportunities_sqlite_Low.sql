-- 1: Show the average potential max sales opportunity amount in local currency for each card group
SELECT `CRDGRP`, AVG (`MAXSUMLOC`) AVGMAX
FROM `OPP_TBL`
GROUP BY `CRDGRP`
;

-- 2: What is the percent profit, gross profit total (local), gross profit total (system) for sales opportunities with the status 'W'?
SELECT `PRCNPROF`, `SUMPROFL`, `SUMPROFS`
FROM `OPP_TBL`
WHERE `STTUS` = 'W'
;

-- 3: For each sales opportunity, show sequence number and, carde code, the average percentage rate of all the rows associated with the opportunity
SELECT `OPP_TBL`.`OPPRID`, `CRDCODE`, AVG (`CLOSEPRCNT`) AVGPERC
FROM `OPP_TBL`
JOIN `OPP_ROWS` ON `OPP_TBL`.`OPPRID` = `OPP_ROWS`.`OPPRID`
GROUP BY `OPP_TBL`.`OPPRID`, `CRDCODE`
;

-- 4: For row-level sales opportunity data, show the weighted amount in both system and local currency for rows with the close date occuring in 2014.
SELECT `WTSUMLOC`, `WTSUMSYS`
FROM `OPP_ROWS`
WHERE DATE (`CLSDT`) >= DATE ('2014-01-01' AND DATE (`CLSDT`) <= DATE ('2014-12-31'))
;

-- 5: Show the cost center code, name, balance, and dimension code for cost centers that are active (Y value) and valid in 2021.
SELECT `PRCCODE`, `PRCNAME`, `BAL`, `DATASRC`
FROM `CST_CNTR_TBL`
WHERE `ACTV` = 'Y' AND DATE (`VLDFROM`) >= DATE ('2021-01-01' AND DATE (`VLDFROM`) <= DATE ('2021-12-31'))
;

-- 6: For each card associated with a sales opportunity, Show the carde name, the sum of the real total amount (both local and system), the sum of the real closing gross profit (local and system), and the average closing percentage.
SELECT `CRDNM`, SUM (`REALSUMLOC`) REALSUMLOC, SUM (`REALSUMSYS`) REALSUMSYS, SUM (`REALPROFS`) REALPROFSYS, SUM (`REALPROFL`) REALPROFLOC, AVG (`CLSNG_PCT`)
FROM `OPP_TBL`
GROUP BY `CRDNM`
;

-- 7: What are the open and close dates for sales opportunity rows that have a closing percentage of six or less?
SELECT `OPNDT`, `CLSDT`
FROM `OPP_ROWS`
WHERE `CLOSEPRCNT` <= 6
;

-- 8: Show the newest sales opportunity start date for each opportunity status code
SELECT `STTUS`, MAX (`OPNDT`) MAXDATE
FROM `OPP_TBL`
GROUP BY `STTUS`
;

-- 9: What is the dimension code of the cost center named 'General Center 3'?
SELECT `DIMCODE`
FROM `CST_CNTR_TBL`
WHERE `PRCNAME` = 'General Center 3'
;

-- 10: Show the sales opportunity average gross profit in local currency by year created
SELECT STRFTIME ('%Y', `CREAT_DT`) YEARCREATED, AVG (`SUMPROFL`) AVGLOCPROFIT
FROM `OPP_TBL`
GROUP BY STRFTIME ('%Y', `CREAT_DT`)
;

