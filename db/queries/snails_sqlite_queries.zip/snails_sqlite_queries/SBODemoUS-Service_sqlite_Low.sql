-- 1: How many service contract items are there for each service contract? Include the contract ID in the result.
SELECT `SVC_CNTRCTS_TBL`.`CNTRCT_ID`, COUNT (*) ITEMCOUNT
FROM `SVC_CNTRCTS_TBL`
JOIN `SVC_CNTRCT_ITEMS_CTR` ON `SVC_CNTRCTS_TBL`.`CNTRCT_ID` = `SVC_CNTRCT_ITEMS_CTR`.`CNTRCT_ID`
GROUP BY `SVC_CNTRCTS_TBL`.`CNTRCT_ID`
;

-- 2: What is the renewal status of the contracts with the customer named 'Maxi-Teq'? Include the contract ID and the status in the result.
SELECT `CNTRCT_ID`, `RNWL`
FROM `SVC_CNTRCTS_TBL`
WHERE `CSTMRNAME` = 'Maxi-Teq'
;

-- 3: For each state in the country US, show a count of entries in the customer equipment card table
SELECT `STA`, COUNT (*) ENTRYCOUNT
FROM `CUST_EQP_CARD`
WHERE `CNTRY` = 'US'
GROUP BY `STA`
;

-- 4: What is the customer equipment item name of the item with code S10000? Include only one result in the output.
SELECT DISTINCT `ITMNM`
FROM `CUST_EQP_CARD`
WHERE `ITMCD` = 'S10000'
;

-- 5: For each queue, show the description, manager, and email address
SELECT `DESCRIPT`, `MNGR`, `EML`
FROM `Q_TABLE`
;

-- 6: How many service calls are there per customer where the priority is medium? (value M) Include the custmer ID and customer name
SELECT `CUSTMR`, `CUSTMRNAME`, COUNT (*) CALLCOUNT
FROM `SVC_CALLS_TBL_SCL`
WHERE `PRTTY` = 'M'
GROUP BY `CUSTMR`, `CUSTMRNAME`
;

-- 7: Show the assigned date, response date, and resolved date of service calls that originated on the web
SELECT `ASNDATE`, `RESPONDATE`, `RESOLONDAT`
FROM `SVC_CALLS_TBL_SCL`
JOIN `SVC_CALL_ORIGINS` ON `SVC_CALLS_TBL_SCL`.`ORGN` = `SVC_CALL_ORIGINS`.`ORGID`
WHERE `SVC_CALL_ORIGINS`.`NM` = 'Web'
;

-- 8: what is the business partner shipping and billing address and email for the customer named 'Aquent Systems'. Display only one row per unique result.
SELECT DISTINCT `BPSHIPADDR`, `BPBILLADDR`, `BPE_MAIL`
FROM `SVC_CALLS_TBL_SCL`
WHERE `CUSTMRNAME` = 'Aquent Systems'
;

-- 9: Show the number of service calls for customer with the 'Silver Warranty' contract template. Include the customer name and count of calls in the result.
SELECT `CSTMRNAME`, COUNT (*) CALLCOUNT
FROM `SVC_CNTRCTS_TBL`
JOIN `SVC_CALLS_TBL_SCL` ON `SVC_CNTRCTS_TBL`.`CSTMRCODE` = `SVC_CALLS_TBL_SCL`.`CUSTMR`
GROUP BY `CSTMRNAME`
;

-- 10: What are the internal serial numbers of the service contract with the customer named microhips and the iten code A00006?
SELECT `INTERNALSN`
FROM `CUST_EQP_CARD`
WHERE `CUSTMRNAME` = 'Microchips' AND `ITMCD` = 'A00006'
;

